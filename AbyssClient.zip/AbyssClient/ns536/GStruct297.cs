﻿using System;
using System.Runtime.InteropServices;
using ns291;
using ns417;
using ns89;

namespace ns536
{
	// Token: 0x02000397 RID: 919
	[Attribute2(4700)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct297
	{
		// Token: 0x04001D12 RID: 7442
		public const int int_0 = 4700;

		// Token: 0x04001D13 RID: 7443
		public GStruct31 gstruct31_0;

		// Token: 0x04001D14 RID: 7444
		public GEnum54 genum54_0;
	}
}
