﻿using System;

namespace ns234
{
	// Token: 0x020001B0 RID: 432
	internal class Class94
	{
		// Token: 0x04000C17 RID: 3095
		internal int int_0 = 60;

		// Token: 0x04000C18 RID: 3096
		internal bool bool_0 = false;

		// Token: 0x04000C19 RID: 3097
		internal bool bool_1 = false;

		// Token: 0x04000C1A RID: 3098
		internal bool bool_2 = false;

		// Token: 0x04000C1B RID: 3099
		internal bool bool_3 = true;

		// Token: 0x04000C1C RID: 3100
		internal bool bool_4 = true;

		// Token: 0x04000C1D RID: 3101
		internal int int_1 = 10;

		// Token: 0x04000C1E RID: 3102
		internal static Class94 class94_0 = new Class94();
	}
}
