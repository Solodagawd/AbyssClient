﻿using System;
using System.Runtime.InteropServices;
using ns118;
using ns417;

namespace ns227
{
	// Token: 0x020001A3 RID: 419
	[Attribute2(4516)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct123
	{
		// Token: 0x04000BB1 RID: 2993
		public const int int_0 = 4516;

		// Token: 0x04000BB2 RID: 2994
		public GStruct43 gstruct43_0;

		// Token: 0x04000BB3 RID: 2995
		public string string_0;

		// Token: 0x04000BB4 RID: 2996
		public string string_1;
	}
}
