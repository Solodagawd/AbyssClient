﻿using System;
using System.Runtime.InteropServices;
using ns291;
using ns417;

namespace ns31
{
	// Token: 0x02000023 RID: 35
	[Attribute2(1112)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct13
	{
		// Token: 0x04000083 RID: 131
		public const int int_0 = 1112;

		// Token: 0x04000084 RID: 132
		public ulong ulong_0;

		// Token: 0x04000085 RID: 133
		public GEnum54 genum54_0;
	}
}
