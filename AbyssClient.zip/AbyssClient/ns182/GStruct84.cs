﻿using System;
using System.Runtime.InteropServices;
using ns118;
using ns417;

namespace ns182
{
	// Token: 0x02000126 RID: 294
	[Attribute2(4521)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct84
	{
		// Token: 0x04000741 RID: 1857
		public const int int_0 = 4521;

		// Token: 0x04000742 RID: 1858
		public GStruct43 gstruct43_0;

		// Token: 0x04000743 RID: 1859
		public string string_0;

		// Token: 0x04000744 RID: 1860
		public uint uint_0;

		// Token: 0x04000745 RID: 1861
		public uint uint_1;

		// Token: 0x04000746 RID: 1862
		public uint uint_2;

		// Token: 0x04000747 RID: 1863
		public uint uint_3;

		// Token: 0x04000748 RID: 1864
		public GStruct43 gstruct43_1;
	}
}
