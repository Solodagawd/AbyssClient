﻿using System;

namespace ns284
{
	// Token: 0x02000248 RID: 584
	public enum GEnum52
	{
		// Token: 0x04000FA1 RID: 4001
		const_0,
		// Token: 0x04000FA2 RID: 4002
		const_1,
		// Token: 0x04000FA3 RID: 4003
		const_2,
		// Token: 0x04000FA4 RID: 4004
		const_3,
		// Token: 0x04000FA5 RID: 4005
		const_4
	}
}
