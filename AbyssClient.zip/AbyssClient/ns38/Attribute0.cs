﻿using System;
using System.Runtime.CompilerServices;
using ns521;

namespace ns38
{
	// Token: 0x0200002A RID: 42
	[CompilerGenerated]
	[Attribute3]
	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct | AttributeTargets.Method | AttributeTargets.Interface | AttributeTargets.Delegate, AllowMultiple = false, Inherited = false)]
	internal sealed class Attribute0 : Attribute
	{
		// Token: 0x0600015A RID: 346 RVA: 0x00005940 File Offset: 0x00003B40
		public Attribute0(byte byte_1)
		{
			this.byte_0 = byte_1;
		}

		// Token: 0x0400009D RID: 157
		public readonly byte byte_0;
	}
}
