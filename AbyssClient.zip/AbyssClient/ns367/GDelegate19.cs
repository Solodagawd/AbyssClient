﻿using System;
using System.Runtime.InteropServices;

namespace ns367
{
	// Token: 0x020002D6 RID: 726
	[UnmanagedFunctionPointer(CallingConvention.StdCall)]
	public delegate GDelegate19();
}
