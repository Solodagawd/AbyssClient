﻿using System;
using System.Runtime.InteropServices;
using ns284;
using ns417;

namespace ns157
{
	// Token: 0x02000106 RID: 262
	[Attribute2(705)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct71
	{
		// Token: 0x04000675 RID: 1653
		public const int int_0 = 705;

		// Token: 0x04000676 RID: 1654
		public GEnum52 genum52_0;
	}
}
