﻿using System;

namespace ns194
{
	// Token: 0x0200013B RID: 315
	public enum GEnum32
	{
		// Token: 0x040007E4 RID: 2020
		const_0,
		// Token: 0x040007E5 RID: 2021
		const_1,
		// Token: 0x040007E6 RID: 2022
		const_2,
		// Token: 0x040007E7 RID: 2023
		const_3,
		// Token: 0x040007E8 RID: 2024
		const_4
	}
}
