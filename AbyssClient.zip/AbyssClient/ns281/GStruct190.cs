﻿using System;
using System.Runtime.InteropServices;
using ns151;
using ns291;
using ns417;

namespace ns281
{
	// Token: 0x02000240 RID: 576
	[Attribute2(1301)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct190
	{
		// Token: 0x04000F55 RID: 3925
		public const int int_0 = 1301;

		// Token: 0x04000F56 RID: 3926
		public GStruct66 gstruct66_0;

		// Token: 0x04000F57 RID: 3927
		public GEnum54 genum54_0;

		// Token: 0x04000F58 RID: 3928
		public int int_1;
	}
}
