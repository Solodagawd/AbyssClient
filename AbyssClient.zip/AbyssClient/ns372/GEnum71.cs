﻿using System;

namespace ns372
{
	// Token: 0x020002DC RID: 732
	public enum GEnum71
	{
		// Token: 0x0400134A RID: 4938
		const_0,
		// Token: 0x0400134B RID: 4939
		const_1,
		// Token: 0x0400134C RID: 4940
		const_2,
		// Token: 0x0400134D RID: 4941
		const_3,
		// Token: 0x0400134E RID: 4942
		const_4,
		// Token: 0x0400134F RID: 4943
		const_5,
		// Token: 0x04001350 RID: 4944
		const_6,
		// Token: 0x04001351 RID: 4945
		const_7,
		// Token: 0x04001352 RID: 4946
		const_8
	}
}
