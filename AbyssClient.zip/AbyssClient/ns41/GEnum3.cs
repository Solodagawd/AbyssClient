﻿using System;

namespace ns41
{
	// Token: 0x0200002D RID: 45
	public enum GEnum3
	{
		// Token: 0x040000AB RID: 171
		const_0,
		// Token: 0x040000AC RID: 172
		const_1,
		// Token: 0x040000AD RID: 173
		const_2,
		// Token: 0x040000AE RID: 174
		const_3,
		// Token: 0x040000AF RID: 175
		const_4,
		// Token: 0x040000B0 RID: 176
		const_5,
		// Token: 0x040000B1 RID: 177
		const_6,
		// Token: 0x040000B2 RID: 178
		const_7,
		// Token: 0x040000B3 RID: 179
		const_8,
		// Token: 0x040000B4 RID: 180
		const_9,
		// Token: 0x040000B5 RID: 181
		const_10,
		// Token: 0x040000B6 RID: 182
		const_11,
		// Token: 0x040000B7 RID: 183
		const_12,
		// Token: 0x040000B8 RID: 184
		const_13
	}
}
