﻿using System;
using System.Runtime.InteropServices;
using ns291;
using ns417;

namespace ns354
{
	// Token: 0x020002BB RID: 699
	[Attribute2(103)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct230
	{
		// Token: 0x04001297 RID: 4759
		public const int int_0 = 103;

		// Token: 0x04001298 RID: 4760
		public GEnum54 genum54_0;
	}
}
