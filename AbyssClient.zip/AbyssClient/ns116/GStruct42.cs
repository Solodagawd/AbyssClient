﻿using System;
using System.Runtime.InteropServices;
using ns291;
using ns417;
using ns54;

namespace ns116
{
	// Token: 0x020000B9 RID: 185
	[Attribute2(1800)]
	[StructLayout(LayoutKind.Sequential, Pack = 4)]
	public struct GStruct42
	{
		// Token: 0x040004BD RID: 1213
		public const int int_0 = 1800;

		// Token: 0x040004BE RID: 1214
		public GEnum54 genum54_0;

		// Token: 0x040004BF RID: 1215
		public GStruct22 gstruct22_0;
	}
}
