﻿using System;
using ns417;

namespace ns23
{
	// Token: 0x0200001B RID: 27
	[Attribute2(4103)]
	public struct GStruct8
	{
		// Token: 0x0400006E RID: 110
		public const int int_0 = 4103;
	}
}
