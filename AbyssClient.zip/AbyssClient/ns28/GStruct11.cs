﻿using System;
using ns417;

namespace ns28
{
	// Token: 0x02000020 RID: 32
	[Attribute2(4102)]
	public struct GStruct11
	{
		// Token: 0x0400007A RID: 122
		public const int int_0 = 4102;
	}
}
