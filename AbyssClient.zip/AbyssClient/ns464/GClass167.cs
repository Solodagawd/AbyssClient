﻿using System;
using ns425;
using ns438;

namespace ns464
{
	// Token: 0x02000317 RID: 791
	public class GClass167 : GClass130
	{
		// Token: 0x060040D9 RID: 16601 RVA: 0x000F672C File Offset: 0x000F492C
		internal void method_2()
		{
			this.method_3();
		}

		// Token: 0x060040DA RID: 16602 RVA: 0x000F6740 File Offset: 0x000F4940
		public override void vmethod_23()
		{
			this.method_2();
		}

		// Token: 0x060040DC RID: 16604 RVA: 0x000F6754 File Offset: 0x000F4954
		internal void method_3()
		{
			this.vmethod_4(new GClass142());
		}
	}
}
