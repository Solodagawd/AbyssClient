﻿using System;

namespace ns111
{
	// Token: 0x02000095 RID: 149
	public static class GClass51
	{
		// Token: 0x0400031D RID: 797
		public const string string_0 = "STEAMAPPLIST_INTERFACE_VERSION001";

		// Token: 0x0400031E RID: 798
		public const string string_1 = "STEAMAPPS_INTERFACE_VERSION008";

		// Token: 0x0400031F RID: 799
		public const string string_2 = "STEAMAPPTICKET_INTERFACE_VERSION001";

		// Token: 0x04000320 RID: 800
		public const string string_3 = "SteamClient017";

		// Token: 0x04000321 RID: 801
		public const string string_4 = "SteamController006";

		// Token: 0x04000322 RID: 802
		public const string string_5 = "SteamFriends015";

		// Token: 0x04000323 RID: 803
		public const string string_6 = "SteamGameCoordinator001";

		// Token: 0x04000324 RID: 804
		public const string string_7 = "SteamGameServer012";

		// Token: 0x04000325 RID: 805
		public const string string_8 = "SteamGameServerStats001";

		// Token: 0x04000326 RID: 806
		public const string string_9 = "STEAMHTMLSURFACE_INTERFACE_VERSION_004";

		// Token: 0x04000327 RID: 807
		public const string string_10 = "STEAMHTTP_INTERFACE_VERSION002";

		// Token: 0x04000328 RID: 808
		public const string string_11 = "STEAMINVENTORY_INTERFACE_V002";

		// Token: 0x04000329 RID: 809
		public const string string_12 = "SteamMatchMaking009";

		// Token: 0x0400032A RID: 810
		public const string string_13 = "SteamMatchMakingServers002";

		// Token: 0x0400032B RID: 811
		public const string string_14 = "STEAMMUSIC_INTERFACE_VERSION001";

		// Token: 0x0400032C RID: 812
		public const string string_15 = "STEAMMUSICREMOTE_INTERFACE_VERSION001";

		// Token: 0x0400032D RID: 813
		public const string string_16 = "SteamNetworking005";

		// Token: 0x0400032E RID: 814
		public const string string_17 = "STEAMPARENTALSETTINGS_INTERFACE_VERSION001";

		// Token: 0x0400032F RID: 815
		public const string string_18 = "STEAMREMOTESTORAGE_INTERFACE_VERSION014";

		// Token: 0x04000330 RID: 816
		public const string string_19 = "STEAMSCREENSHOTS_INTERFACE_VERSION003";

		// Token: 0x04000331 RID: 817
		public const string string_20 = "STEAMUGC_INTERFACE_VERSION010";

		// Token: 0x04000332 RID: 818
		public const string string_21 = "SteamUser019";

		// Token: 0x04000333 RID: 819
		public const string string_22 = "STEAMUSERSTATS_INTERFACE_VERSION011";

		// Token: 0x04000334 RID: 820
		public const string string_23 = "SteamUtils009";

		// Token: 0x04000335 RID: 821
		public const string string_24 = "STEAMVIDEO_INTERFACE_V002";

		// Token: 0x04000336 RID: 822
		public const int int_0 = 240;

		// Token: 0x04000337 RID: 823
		public const int int_1 = 100;

		// Token: 0x04000338 RID: 824
		public const int int_2 = 200;

		// Token: 0x04000339 RID: 825
		public const int int_3 = 300;

		// Token: 0x0400033A RID: 826
		public const int int_4 = 400;

		// Token: 0x0400033B RID: 827
		public const int int_5 = 500;

		// Token: 0x0400033C RID: 828
		public const int int_6 = 600;

		// Token: 0x0400033D RID: 829
		public const int int_7 = 700;

		// Token: 0x0400033E RID: 830
		public const int int_8 = 800;

		// Token: 0x0400033F RID: 831
		public const int int_9 = 900;

		// Token: 0x04000340 RID: 832
		public const int int_10 = 1000;

		// Token: 0x04000341 RID: 833
		public const int int_11 = 1100;

		// Token: 0x04000342 RID: 834
		public const int int_12 = 1200;

		// Token: 0x04000343 RID: 835
		public const int int_13 = 1300;

		// Token: 0x04000344 RID: 836
		public const int int_14 = 1400;

		// Token: 0x04000345 RID: 837
		public const int int_15 = 1500;

		// Token: 0x04000346 RID: 838
		public const int int_16 = 1600;

		// Token: 0x04000347 RID: 839
		public const int int_17 = 1700;

		// Token: 0x04000348 RID: 840
		public const int int_18 = 1800;

		// Token: 0x04000349 RID: 841
		public const int int_19 = 1900;

		// Token: 0x0400034A RID: 842
		public const int int_20 = 2000;

		// Token: 0x0400034B RID: 843
		public const int int_21 = 2100;

		// Token: 0x0400034C RID: 844
		public const int int_22 = 2200;

		// Token: 0x0400034D RID: 845
		public const int int_23 = 2300;

		// Token: 0x0400034E RID: 846
		public const int int_24 = 2400;

		// Token: 0x0400034F RID: 847
		public const int int_25 = 2500;

		// Token: 0x04000350 RID: 848
		public const int int_26 = 2600;

		// Token: 0x04000351 RID: 849
		public const int int_27 = 2700;

		// Token: 0x04000352 RID: 850
		public const int int_28 = 2800;

		// Token: 0x04000353 RID: 851
		public const int int_29 = 2900;

		// Token: 0x04000354 RID: 852
		public const int int_30 = 3000;

		// Token: 0x04000355 RID: 853
		public const int int_31 = 3100;

		// Token: 0x04000356 RID: 854
		public const int int_32 = 3200;

		// Token: 0x04000357 RID: 855
		public const int int_33 = 3300;

		// Token: 0x04000358 RID: 856
		public const int int_34 = 3400;

		// Token: 0x04000359 RID: 857
		public const int int_35 = 3500;

		// Token: 0x0400035A RID: 858
		public const int int_36 = 3600;

		// Token: 0x0400035B RID: 859
		public const int int_37 = 3700;

		// Token: 0x0400035C RID: 860
		public const int int_38 = 3800;

		// Token: 0x0400035D RID: 861
		public const int int_39 = 3900;

		// Token: 0x0400035E RID: 862
		public const int int_40 = 4000;

		// Token: 0x0400035F RID: 863
		public const int int_41 = 4100;

		// Token: 0x04000360 RID: 864
		public const int int_42 = 4200;

		// Token: 0x04000361 RID: 865
		public const int int_43 = 4300;

		// Token: 0x04000362 RID: 866
		public const int int_44 = 4400;

		// Token: 0x04000363 RID: 867
		public const int int_45 = 4500;

		// Token: 0x04000364 RID: 868
		public const int int_46 = 4600;

		// Token: 0x04000365 RID: 869
		public const int int_47 = 4700;

		// Token: 0x04000366 RID: 870
		public const int int_48 = 4800;

		// Token: 0x04000367 RID: 871
		public const int int_49 = 4900;

		// Token: 0x04000368 RID: 872
		public const int int_50 = 5000;

		// Token: 0x04000369 RID: 873
		public const int int_51 = 5100;

		// Token: 0x0400036A RID: 874
		public const int int_52 = 64;

		// Token: 0x0400036B RID: 875
		public const int int_53 = 100;

		// Token: 0x0400036C RID: 876
		public const int int_54 = 50;

		// Token: 0x0400036D RID: 877
		public const int int_55 = 128;

		// Token: 0x0400036E RID: 878
		public const int int_56 = 32;

		// Token: 0x0400036F RID: 879
		public const int int_57 = 8192;

		// Token: 0x04000370 RID: 880
		public const int int_58 = 20;

		// Token: 0x04000371 RID: 881
		public const int int_59 = 64;

		// Token: 0x04000372 RID: 882
		public const int int_60 = 256;

		// Token: 0x04000373 RID: 883
		public const int int_61 = 0;

		// Token: 0x04000374 RID: 884
		public const int int_62 = 1;

		// Token: 0x04000375 RID: 885
		public const int int_63 = 2;

		// Token: 0x04000376 RID: 886
		public const int int_64 = 4;

		// Token: 0x04000377 RID: 887
		public const int int_65 = 8;

		// Token: 0x04000378 RID: 888
		public const int int_66 = 16;

		// Token: 0x04000379 RID: 889
		public const int int_67 = 32;

		// Token: 0x0400037A RID: 890
		public const int int_68 = 0;

		// Token: 0x0400037B RID: 891
		public const int int_69 = 1;

		// Token: 0x0400037C RID: 892
		public const int int_70 = 2;

		// Token: 0x0400037D RID: 893
		public const int int_71 = 104857600;

		// Token: 0x0400037E RID: 894
		public const int int_72 = 129;

		// Token: 0x0400037F RID: 895
		public const int int_73 = 8000;

		// Token: 0x04000380 RID: 896
		public const int int_74 = 8000;

		// Token: 0x04000381 RID: 897
		public const int int_75 = 50;

		// Token: 0x04000382 RID: 898
		public const int int_76 = 1025;

		// Token: 0x04000383 RID: 899
		public const int int_77 = 260;

		// Token: 0x04000384 RID: 900
		public const int int_78 = 256;

		// Token: 0x04000385 RID: 901
		public const int int_79 = 32;

		// Token: 0x04000386 RID: 902
		public const int int_80 = 32;

		// Token: 0x04000387 RID: 903
		public const int int_81 = 255;

		// Token: 0x04000388 RID: 904
		public const int int_82 = 255;

		// Token: 0x04000389 RID: 905
		public const int int_83 = 200;

		// Token: 0x0400038A RID: 906
		public const int int_84 = 50;

		// Token: 0x0400038B RID: 907
		public const int int_85 = 5000;

		// Token: 0x0400038C RID: 908
		public const int int_86 = 128;

		// Token: 0x0400038D RID: 909
		public const int int_87 = 128;

		// Token: 0x0400038E RID: 910
		public const int int_88 = 64;

		// Token: 0x0400038F RID: 911
		public const int int_89 = 32;

		// Token: 0x04000390 RID: 912
		public const int int_90 = 32;

		// Token: 0x04000391 RID: 913
		public const int int_91 = 64;

		// Token: 0x04000392 RID: 914
		public const int int_92 = 64;

		// Token: 0x04000393 RID: 915
		public const int int_93 = 128;

		// Token: 0x04000394 RID: 916
		public const int int_94 = 2048;

		// Token: 0x04000395 RID: 917
		public const int int_95 = -1;

		// Token: 0x04000396 RID: 918
		public const int int_96 = 1048575;

		// Token: 0x04000397 RID: 919
		public const int int_97 = 1;

		// Token: 0x04000398 RID: 920
		public const int int_98 = 2;

		// Token: 0x04000399 RID: 921
		public const int int_99 = 4;

		// Token: 0x0400039A RID: 922
		public const int int_100 = 64;

		// Token: 0x0400039B RID: 923
		public const int int_101 = 32;

		// Token: 0x0400039C RID: 924
		public const int int_102 = 8;

		// Token: 0x0400039D RID: 925
		public const ulong ulong_0 = 18446744073709551615UL;

		// Token: 0x0400039E RID: 926
		public const ulong ulong_1 = 18446744073709551615UL;

		// Token: 0x0400039F RID: 927
		public const ulong ulong_2 = 0UL;

		// Token: 0x040003A0 RID: 928
		public const int int_103 = 0;

		// Token: 0x040003A1 RID: 929
		public const int int_104 = -1;

		// Token: 0x040003A2 RID: 930
		public const ulong ulong_3 = 0UL;

		// Token: 0x040003A3 RID: 931
		public const int int_105 = 0;

		// Token: 0x040003A4 RID: 932
		public const int int_106 = -1;

		// Token: 0x040003A5 RID: 933
		public const int int_107 = 0;

		// Token: 0x040003A6 RID: 934
		public const int int_108 = 16;

		// Token: 0x040003A7 RID: 935
		public const int int_109 = 16;

		// Token: 0x040003A8 RID: 936
		public const int int_110 = 128;

		// Token: 0x040003A9 RID: 937
		public const int int_111 = 8;

		// Token: 0x040003AA RID: 938
		public const ulong ulong_4 = 18446744073709551615UL;

		// Token: 0x040003AB RID: 939
		public const float float_0 = -1f;

		// Token: 0x040003AC RID: 940
		public const float float_1 = 1f;

		// Token: 0x040003AD RID: 941
		public const ushort ushort_0 = 65535;

		// Token: 0x040003AE RID: 942
		public const int int_112 = 0;

		// Token: 0x040003AF RID: 943
		public const byte byte_0 = 255;

		// Token: 0x040003B0 RID: 944
		public const int int_113 = 255;

		// Token: 0x040003B1 RID: 945
		public const int int_114 = 65535;

		// Token: 0x040003B2 RID: 946
		public const int int_115 = 65535;

		// Token: 0x040003B3 RID: 947
		public const int int_116 = 65534;
	}
}
