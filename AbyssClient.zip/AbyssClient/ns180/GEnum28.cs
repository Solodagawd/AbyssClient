﻿using System;

namespace ns180
{
	// Token: 0x02000123 RID: 291
	[Flags]
	public enum GEnum28
	{
		// Token: 0x04000735 RID: 1845
		flag_0 = 0,
		// Token: 0x04000736 RID: 1846
		flag_1 = 1,
		// Token: 0x04000737 RID: 1847
		flag_2 = 2,
		// Token: 0x04000738 RID: 1848
		flag_3 = 4,
		// Token: 0x04000739 RID: 1849
		flag_4 = 8,
		// Token: 0x0400073A RID: 1850
		flag_5 = 16,
		// Token: 0x0400073B RID: 1851
		flag_6 = 128,
		// Token: 0x0400073C RID: 1852
		flag_7 = 256,
		// Token: 0x0400073D RID: 1853
		flag_8 = 512,
		// Token: 0x0400073E RID: 1854
		flag_9 = 1024,
		// Token: 0x0400073F RID: 1855
		flag_10 = 4096,
		// Token: 0x04000740 RID: 1856
		flag_11 = 65535
	}
}
