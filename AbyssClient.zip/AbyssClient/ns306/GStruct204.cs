﻿using System;
using System.Runtime.InteropServices;
using ns417;

namespace ns306
{
	// Token: 0x02000270 RID: 624
	[Attribute2(505)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct204
	{
		// Token: 0x040010EA RID: 4330
		public const int int_0 = 505;

		// Token: 0x040010EB RID: 4331
		public ulong ulong_0;

		// Token: 0x040010EC RID: 4332
		public ulong ulong_1;

		// Token: 0x040010ED RID: 4333
		public byte byte_0;
	}
}
