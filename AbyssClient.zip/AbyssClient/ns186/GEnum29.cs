﻿using System;

namespace ns186
{
	// Token: 0x0200012C RID: 300
	[Flags]
	public enum GEnum29
	{
		// Token: 0x04000784 RID: 1924
		flag_0 = 0,
		// Token: 0x04000785 RID: 1925
		flag_1 = 1,
		// Token: 0x04000786 RID: 1926
		flag_2 = 2,
		// Token: 0x04000787 RID: 1927
		flag_3 = 4,
		// Token: 0x04000788 RID: 1928
		flag_4 = 8,
		// Token: 0x04000789 RID: 1929
		flag_5 = 14
	}
}
