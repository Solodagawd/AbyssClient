﻿using System;

namespace ns396
{
	// Token: 0x02000303 RID: 771
	public enum GEnum75
	{
		// Token: 0x040018E5 RID: 6373
		const_0,
		// Token: 0x040018E6 RID: 6374
		const_1,
		// Token: 0x040018E7 RID: 6375
		const_2,
		// Token: 0x040018E8 RID: 6376
		const_3,
		// Token: 0x040018E9 RID: 6377
		const_4,
		// Token: 0x040018EA RID: 6378
		const_5
	}
}
