﻿using System;
using ns466;
using ns469;

namespace ns467
{
	// Token: 0x020000FF RID: 255
	public class GClass170 : GClass169
	{
		// Token: 0x0600081A RID: 2074 RVA: 0x00021A68 File Offset: 0x0001FC68
		internal void method_8()
		{
			this.method_20();
		}

		// Token: 0x0600081B RID: 2075 RVA: 0x00021A7C File Offset: 0x0001FC7C
		internal void method_9()
		{
			this.method_40();
		}

		// Token: 0x0600081C RID: 2076 RVA: 0x00021A90 File Offset: 0x0001FC90
		internal void method_10(int int_0)
		{
			this.method_16(int_0);
		}

		// Token: 0x0600081D RID: 2077 RVA: 0x00021AA4 File Offset: 0x0001FCA4
		public override void vmethod_11()
		{
			this.method_27();
		}

		// Token: 0x0600081E RID: 2078 RVA: 0x00021AB8 File Offset: 0x0001FCB8
		internal void method_11()
		{
			base.vmethod_10();
		}

		// Token: 0x0600081F RID: 2079 RVA: 0x00021ACC File Offset: 0x0001FCCC
		internal void method_12()
		{
			this.method_11();
		}

		// Token: 0x06000820 RID: 2080 RVA: 0x00021AE0 File Offset: 0x0001FCE0
		public override void vmethod_23()
		{
			this.method_30();
		}

		// Token: 0x06000821 RID: 2081 RVA: 0x00021AF4 File Offset: 0x0001FCF4
		internal void method_13()
		{
			this.method_17();
		}

		// Token: 0x06000822 RID: 2082 RVA: 0x00021B08 File Offset: 0x0001FD08
		internal void method_14()
		{
			this.method_37();
		}

		// Token: 0x06000823 RID: 2083 RVA: 0x00021B1C File Offset: 0x0001FD1C
		public override void vmethod_25()
		{
			this.method_9();
		}

		// Token: 0x06000824 RID: 2084 RVA: 0x00021B30 File Offset: 0x0001FD30
		public override void vmethod_9()
		{
			this.method_29();
		}

		// Token: 0x06000825 RID: 2085 RVA: 0x00021B44 File Offset: 0x0001FD44
		internal void method_15(GClass172 gclass172_1)
		{
			this.method_24(gclass172_1);
		}

		// Token: 0x06000826 RID: 2086 RVA: 0x00021B58 File Offset: 0x0001FD58
		public override void vmethod_24()
		{
			this.method_33();
		}

		// Token: 0x06000827 RID: 2087 RVA: 0x00021B6C File Offset: 0x0001FD6C
		public override void vmethod_15()
		{
			this.method_28();
		}

		// Token: 0x06000828 RID: 2088 RVA: 0x00021B80 File Offset: 0x0001FD80
		internal void method_16(int int_0)
		{
			base.vmethod_8(int_0);
		}

		// Token: 0x06000829 RID: 2089 RVA: 0x00021B94 File Offset: 0x0001FD94
		internal void method_17()
		{
			base.vmethod_22();
		}

		// Token: 0x0600082A RID: 2090 RVA: 0x00021BA8 File Offset: 0x0001FDA8
		internal void method_18()
		{
			base.vmethod_28();
		}

		// Token: 0x0600082B RID: 2091 RVA: 0x00021BBC File Offset: 0x0001FDBC
		public override void vmethod_29()
		{
			this.method_8();
		}

		// Token: 0x0600082C RID: 2092 RVA: 0x00021BD0 File Offset: 0x0001FDD0
		internal void method_19()
		{
			this.method_23();
		}

		// Token: 0x0600082D RID: 2093 RVA: 0x00021BE4 File Offset: 0x0001FDE4
		public virtual void vmethod_33(GClass172 gclass172_1)
		{
			this.method_15(gclass172_1);
		}

		// Token: 0x0600082E RID: 2094 RVA: 0x00021BF8 File Offset: 0x0001FDF8
		public override void vmethod_12()
		{
			this.method_36();
		}

		// Token: 0x0600082F RID: 2095 RVA: 0x00021C0C File Offset: 0x0001FE0C
		public override void vmethod_28()
		{
			this.method_26();
		}

		// Token: 0x06000830 RID: 2096 RVA: 0x00021C20 File Offset: 0x0001FE20
		public override void vmethod_27(int int_0)
		{
			this.method_32(int_0);
		}

		// Token: 0x06000831 RID: 2097 RVA: 0x00021C34 File Offset: 0x0001FE34
		internal void method_20()
		{
			base.vmethod_29();
		}

		// Token: 0x06000832 RID: 2098 RVA: 0x00021C48 File Offset: 0x0001FE48
		internal void method_21(int int_0)
		{
			base.vmethod_27(int_0);
		}

		// Token: 0x06000833 RID: 2099 RVA: 0x00021C5C File Offset: 0x0001FE5C
		public override void vmethod_10()
		{
			this.method_12();
		}

		// Token: 0x06000834 RID: 2100 RVA: 0x00021C70 File Offset: 0x0001FE70
		internal void method_22()
		{
			this.method_34();
		}

		// Token: 0x06000835 RID: 2101 RVA: 0x00021C84 File Offset: 0x0001FE84
		internal void method_23()
		{
			base.vmethod_31();
		}

		// Token: 0x06000836 RID: 2102 RVA: 0x00021C98 File Offset: 0x0001FE98
		internal void method_24(GClass172 gclass172_1)
		{
			if (gclass172_1 == this.gclass172_0)
			{
			}
		}

		// Token: 0x06000837 RID: 2103 RVA: 0x00021CB4 File Offset: 0x0001FEB4
		public override void vmethod_19()
		{
			this.method_14();
		}

		// Token: 0x06000838 RID: 2104 RVA: 0x00021CC8 File Offset: 0x0001FEC8
		internal void method_25()
		{
			base.vmethod_15();
		}

		// Token: 0x06000839 RID: 2105 RVA: 0x00021CDC File Offset: 0x0001FEDC
		internal void method_26()
		{
			this.method_18();
		}

		// Token: 0x0600083A RID: 2106 RVA: 0x00021CF0 File Offset: 0x0001FEF0
		public override void vmethod_22()
		{
			this.method_13();
		}

		// Token: 0x0600083B RID: 2107 RVA: 0x00021D04 File Offset: 0x0001FF04
		internal void method_27()
		{
			this.method_39();
		}

		// Token: 0x0600083C RID: 2108 RVA: 0x00021D18 File Offset: 0x0001FF18
		internal void method_28()
		{
			this.method_25();
		}

		// Token: 0x0600083D RID: 2109 RVA: 0x00021D2C File Offset: 0x0001FF2C
		public virtual GClass172 vmethod_34()
		{
			return new GClass172();
		}

		// Token: 0x0600083E RID: 2110 RVA: 0x00021D40 File Offset: 0x0001FF40
		public override void vmethod_31()
		{
			this.method_19();
		}

		// Token: 0x0600083F RID: 2111 RVA: 0x00021D54 File Offset: 0x0001FF54
		internal void method_29()
		{
			this.method_38();
		}

		// Token: 0x06000840 RID: 2112 RVA: 0x00021D68 File Offset: 0x0001FF68
		internal void method_30()
		{
			this.method_41();
		}

		// Token: 0x06000842 RID: 2114 RVA: 0x00021DA0 File Offset: 0x0001FFA0
		internal void method_31()
		{
			base.vmethod_24();
		}

		// Token: 0x06000843 RID: 2115 RVA: 0x00021DB4 File Offset: 0x0001FFB4
		public override void vmethod_26()
		{
			this.method_22();
		}

		// Token: 0x06000844 RID: 2116 RVA: 0x00021DC8 File Offset: 0x0001FFC8
		internal void method_32(int int_0)
		{
			this.method_21(int_0);
		}

		// Token: 0x06000845 RID: 2117 RVA: 0x00021DDC File Offset: 0x0001FFDC
		internal void method_33()
		{
			this.method_31();
		}

		// Token: 0x06000846 RID: 2118 RVA: 0x00021DF0 File Offset: 0x0001FFF0
		internal void method_34()
		{
			base.vmethod_26();
		}

		// Token: 0x06000847 RID: 2119 RVA: 0x00021E04 File Offset: 0x00020004
		internal void method_35()
		{
			base.vmethod_12();
		}

		// Token: 0x06000848 RID: 2120 RVA: 0x00021E18 File Offset: 0x00020018
		internal void method_36()
		{
			this.method_35();
		}

		// Token: 0x06000849 RID: 2121 RVA: 0x00021E2C File Offset: 0x0002002C
		internal void method_37()
		{
			base.vmethod_19();
		}

		// Token: 0x0600084A RID: 2122 RVA: 0x00021E40 File Offset: 0x00020040
		internal void method_38()
		{
			base.vmethod_9();
		}

		// Token: 0x0600084B RID: 2123 RVA: 0x00021E54 File Offset: 0x00020054
		public override void vmethod_8(int int_0)
		{
			this.method_10(int_0);
		}

		// Token: 0x0600084C RID: 2124 RVA: 0x00021E68 File Offset: 0x00020068
		internal void method_39()
		{
			base.vmethod_11();
		}

		// Token: 0x0600084D RID: 2125 RVA: 0x00021E7C File Offset: 0x0002007C
		internal void method_40()
		{
			base.vmethod_25();
		}

		// Token: 0x0600084E RID: 2126 RVA: 0x00021E90 File Offset: 0x00020090
		internal void method_41()
		{
			base.vmethod_23();
			this.gclass172_0 = this.vmethod_34();
			this.gclass172_0.gclass170_0 = this;
			this.vmethod_32(this.gclass172_0);
		}

		// Token: 0x0400065B RID: 1627
		internal GClass172 gclass172_0 = null;

		// Token: 0x0400065C RID: 1628
		internal bool bool_0 = false;
	}
}
