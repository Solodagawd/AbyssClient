﻿using System;
using ns417;

namespace ns214
{
	// Token: 0x02000186 RID: 390
	[Attribute2(4101)]
	public struct GStruct109
	{
		// Token: 0x04000AE4 RID: 2788
		public const int int_0 = 4101;
	}
}
