﻿using System;
using System.Runtime.InteropServices;
using ns118;
using ns417;

namespace ns324
{
	// Token: 0x02000284 RID: 644
	[Attribute2(4504)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct212
	{
		// Token: 0x040011A6 RID: 4518
		public const int int_0 = 4504;

		// Token: 0x040011A7 RID: 4519
		public GStruct43 gstruct43_0;
	}
}
