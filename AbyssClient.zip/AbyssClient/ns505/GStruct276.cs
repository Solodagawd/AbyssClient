﻿using System;
using System.Runtime.InteropServices;
using ns151;
using ns169;
using ns417;

namespace ns505
{
	// Token: 0x0200036D RID: 877
	[Attribute2(1330)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct276
	{
		// Token: 0x04001BF4 RID: 7156
		public const int int_0 = 1330;

		// Token: 0x04001BF5 RID: 7157
		public GStruct78 gstruct78_0;

		// Token: 0x04001BF6 RID: 7158
		public GStruct66 gstruct66_0;

		// Token: 0x04001BF7 RID: 7159
		public ulong ulong_0;
	}
}
