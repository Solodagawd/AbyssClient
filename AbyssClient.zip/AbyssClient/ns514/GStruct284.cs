﻿using System;
using System.Runtime.InteropServices;
using ns291;
using ns417;
using ns515;

namespace ns514
{
	// Token: 0x0200037A RID: 890
	[Attribute2(3401)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct284
	{
		// Token: 0x04001C45 RID: 7237
		public const int int_0 = 3401;

		// Token: 0x04001C46 RID: 7238
		public GStruct285 gstruct285_0;

		// Token: 0x04001C47 RID: 7239
		public GEnum54 genum54_0;

		// Token: 0x04001C48 RID: 7240
		public uint uint_0;

		// Token: 0x04001C49 RID: 7241
		public uint uint_1;

		// Token: 0x04001C4A RID: 7242
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_0;
	}
}
