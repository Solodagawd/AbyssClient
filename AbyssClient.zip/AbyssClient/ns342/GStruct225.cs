﻿using System;
using System.Runtime.InteropServices;
using ns169;
using ns291;
using ns417;

namespace ns342
{
	// Token: 0x020002AD RID: 685
	[Attribute2(3409)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct225
	{
		// Token: 0x04001264 RID: 4708
		public const int int_0 = 3409;

		// Token: 0x04001265 RID: 4709
		public GStruct78 gstruct78_0;

		// Token: 0x04001266 RID: 4710
		public GEnum54 genum54_0;

		// Token: 0x04001267 RID: 4711
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_0;

		// Token: 0x04001268 RID: 4712
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_1;

		// Token: 0x04001269 RID: 4713
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_2;
	}
}
