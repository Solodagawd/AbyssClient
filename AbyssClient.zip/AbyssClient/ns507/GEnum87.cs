﻿using System;

namespace ns507
{
	// Token: 0x0200036F RID: 879
	public enum GEnum87
	{
		// Token: 0x04001BFB RID: 7163
		const_0,
		// Token: 0x04001BFC RID: 7164
		const_1,
		// Token: 0x04001BFD RID: 7165
		const_2
	}
}
