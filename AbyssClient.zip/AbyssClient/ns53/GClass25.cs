﻿using System;
using System.Collections.Generic;
using ns295;
using ns30;
using ns302;
using ns56;
using ns57;
using ns58;
using ns59;
using ns60;
using ns61;
using ns62;
using ns63;
using ns64;
using ns65;
using UnityEngine;

namespace ns53
{
	// Token: 0x02000045 RID: 69
	public static class GClass25
	{
		// Token: 0x040000F3 RID: 243
		public static Color color_0 = Color.red;

		// Token: 0x040000F4 RID: 244
		public static Color color_1 = Color.white;

		// Token: 0x040000F5 RID: 245
		public static Color color_2 = Color.red;

		// Token: 0x040000F6 RID: 246
		public static Color color_3 = Color.yellow;

		// Token: 0x040000F7 RID: 247
		public static List<GClass30> list_0 = new List<GClass30>();

		// Token: 0x040000F8 RID: 248
		public static List<GClass97> list_1 = new List<GClass97>();

		// Token: 0x040000F9 RID: 249
		public static List<GClass36> list_2 = new List<GClass36>();

		// Token: 0x040000FA RID: 250
		public static List<GClass27> list_3 = new List<GClass27>();

		// Token: 0x040000FB RID: 251
		public static List<GClass33> list_4 = new List<GClass33>();

		// Token: 0x040000FC RID: 252
		public static List<GClass32> list_5 = new List<GClass32>();

		// Token: 0x040000FD RID: 253
		public static List<GClass28> list_6 = new List<GClass28>();

		// Token: 0x040000FE RID: 254
		public static List<GClass35> list_7 = new List<GClass35>();

		// Token: 0x040000FF RID: 255
		public static List<GClass31> list_8 = new List<GClass31>();

		// Token: 0x04000100 RID: 256
		public static List<GClass34> list_9 = new List<GClass34>();

		// Token: 0x04000101 RID: 257
		public static List<GClass29> list_10 = new List<GClass29>();

		// Token: 0x04000102 RID: 258
		public static List<GClass99> list_11 = new List<GClass99>();

		// Token: 0x04000103 RID: 259
		public static List<GClass17> list_12 = new List<GClass17>();
	}
}
