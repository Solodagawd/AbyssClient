﻿using System;

namespace ns166
{
	// Token: 0x02000110 RID: 272
	[Flags]
	public enum GEnum25
	{
		// Token: 0x0400069B RID: 1691
		flag_0 = 4095,
		// Token: 0x0400069C RID: 1692
		flag_1 = 524288,
		// Token: 0x0400069D RID: 1693
		flag_2 = 262144,
		// Token: 0x0400069E RID: 1694
		flag_3 = 131072
	}
}
