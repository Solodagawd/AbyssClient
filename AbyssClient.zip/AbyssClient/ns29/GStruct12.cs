﻿using System;
using System.Runtime.InteropServices;
using ns417;

namespace ns29
{
	// Token: 0x02000021 RID: 33
	[Attribute2(1107)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct12
	{
		// Token: 0x0400007B RID: 123
		public const int int_0 = 1107;

		// Token: 0x0400007C RID: 124
		public byte byte_0;

		// Token: 0x0400007D RID: 125
		public int int_1;
	}
}
