﻿using System;

namespace ns189
{
	// Token: 0x02000130 RID: 304
	public enum GEnum30
	{
		// Token: 0x04000790 RID: 1936
		const_0,
		// Token: 0x04000791 RID: 1937
		const_1,
		// Token: 0x04000792 RID: 1938
		const_2,
		// Token: 0x04000793 RID: 1939
		const_3,
		// Token: 0x04000794 RID: 1940
		const_4,
		// Token: 0x04000795 RID: 1941
		const_5 = 6,
		// Token: 0x04000796 RID: 1942
		const_6,
		// Token: 0x04000797 RID: 1943
		const_7,
		// Token: 0x04000798 RID: 1944
		const_8,
		// Token: 0x04000799 RID: 1945
		const_9,
		// Token: 0x0400079A RID: 1946
		const_10,
		// Token: 0x0400079B RID: 1947
		const_11 = 14
	}
}
