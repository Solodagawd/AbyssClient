﻿using System;
using System.Runtime.InteropServices;
using ns118;
using ns417;

namespace ns218
{
	// Token: 0x02000198 RID: 408
	[Attribute2(4526)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct118
	{
		// Token: 0x04000B8B RID: 2955
		public const int int_0 = 4526;

		// Token: 0x04000B8C RID: 2956
		public GStruct43 gstruct43_0;
	}
}
