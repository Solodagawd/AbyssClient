﻿using System;
using ns417;

namespace ns531
{
	// Token: 0x02000392 RID: 914
	[Attribute2(4106)]
	public struct GStruct292
	{
		// Token: 0x04001D02 RID: 7426
		public const int int_0 = 4106;
	}
}
