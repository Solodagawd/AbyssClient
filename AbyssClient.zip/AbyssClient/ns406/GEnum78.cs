﻿using System;

namespace ns406
{
	// Token: 0x0200030D RID: 781
	public enum GEnum78
	{
		// Token: 0x0400190C RID: 6412
		const_0,
		// Token: 0x0400190D RID: 6413
		const_1
	}
}
