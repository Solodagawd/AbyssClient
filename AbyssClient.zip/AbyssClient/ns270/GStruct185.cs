﻿using System;
using System.Runtime.InteropServices;
using ns358;
using ns417;
using ns54;

namespace ns270
{
	// Token: 0x0200022D RID: 557
	[Attribute2(143)]
	[StructLayout(LayoutKind.Sequential, Pack = 4)]
	public struct GStruct185
	{
		// Token: 0x04000ED2 RID: 3794
		public const int int_0 = 143;

		// Token: 0x04000ED3 RID: 3795
		public GStruct22 gstruct22_0;

		// Token: 0x04000ED4 RID: 3796
		public GEnum69 genum69_0;

		// Token: 0x04000ED5 RID: 3797
		public GStruct22 gstruct22_1;
	}
}
