﻿using System;
using System.Runtime.InteropServices;
using ns169;
using ns291;
using ns417;

namespace ns261
{
	// Token: 0x02000223 RID: 547
	[Attribute2(3417)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct178
	{
		// Token: 0x04000EAE RID: 3758
		public const int int_0 = 3417;

		// Token: 0x04000EAF RID: 3759
		public GEnum54 genum54_0;

		// Token: 0x04000EB0 RID: 3760
		public GStruct78 gstruct78_0;
	}
}
