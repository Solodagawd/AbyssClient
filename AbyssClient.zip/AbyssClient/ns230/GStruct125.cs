﻿using System;
using System.Runtime.InteropServices;
using ns118;
using ns417;

namespace ns230
{
	// Token: 0x020001A8 RID: 424
	[Attribute2(4510)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct125
	{
		// Token: 0x04000BD0 RID: 3024
		public const int int_0 = 4510;

		// Token: 0x04000BD1 RID: 3025
		public GStruct43 gstruct43_0;

		// Token: 0x04000BD2 RID: 3026
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_0;

		// Token: 0x04000BD3 RID: 3027
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_1;
	}
}
