﻿using System;
using ns417;

namespace ns374
{
	// Token: 0x020002DE RID: 734
	[Attribute2(4702)]
	public struct GStruct236
	{
		// Token: 0x04001353 RID: 4947
		public const int int_0 = 4702;
	}
}
