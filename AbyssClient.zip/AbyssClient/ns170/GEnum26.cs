﻿using System;

namespace ns170
{
	// Token: 0x02000114 RID: 276
	public enum GEnum26
	{
		// Token: 0x040006AB RID: 1707
		const_0,
		// Token: 0x040006AC RID: 1708
		const_1,
		// Token: 0x040006AD RID: 1709
		const_2,
		// Token: 0x040006AE RID: 1710
		const_3
	}
}
