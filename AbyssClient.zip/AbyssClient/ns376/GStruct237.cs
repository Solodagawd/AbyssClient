﻿using System;
using System.Runtime.InteropServices;
using ns417;
using ns54;

namespace ns376
{
	// Token: 0x020002E0 RID: 736
	[Attribute2(201)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct237
	{
		// Token: 0x040013F6 RID: 5110
		public const int int_0 = 201;

		// Token: 0x040013F7 RID: 5111
		public GStruct22 gstruct22_0;

		// Token: 0x040013F8 RID: 5112
		public GStruct22 gstruct22_1;
	}
}
