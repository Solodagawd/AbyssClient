﻿using System;

namespace ns279
{
	// Token: 0x0200023E RID: 574
	public enum GEnum51
	{
		// Token: 0x04000F52 RID: 3922
		const_0,
		// Token: 0x04000F53 RID: 3923
		const_1
	}
}
