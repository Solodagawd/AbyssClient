﻿using System;
using System.Runtime.InteropServices;
using ns151;
using ns169;
using ns417;

namespace ns390
{
	// Token: 0x020002F1 RID: 753
	[Attribute2(1322)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct244
	{
		// Token: 0x040018AC RID: 6316
		public const int int_0 = 1322;

		// Token: 0x040018AD RID: 6317
		public GStruct78 gstruct78_0;

		// Token: 0x040018AE RID: 6318
		public GStruct66 gstruct66_0;
	}
}
