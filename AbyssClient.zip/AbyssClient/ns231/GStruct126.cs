﻿using System;
using System.Runtime.InteropServices;
using ns169;
using ns291;
using ns417;

namespace ns231
{
	// Token: 0x020001A9 RID: 425
	[Attribute2(3404)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct126
	{
		// Token: 0x04000BD4 RID: 3028
		public const int int_0 = 3404;

		// Token: 0x04000BD5 RID: 3029
		public GEnum54 genum54_0;

		// Token: 0x04000BD6 RID: 3030
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_0;

		// Token: 0x04000BD7 RID: 3031
		public GStruct78 gstruct78_0;
	}
}
