﻿using System;
using System.Runtime.InteropServices;
using ns169;
using ns291;
using ns417;

namespace ns511
{
	// Token: 0x02000376 RID: 886
	[Attribute2(1320)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct281
	{
		// Token: 0x04001C32 RID: 7218
		public const int int_0 = 1320;

		// Token: 0x04001C33 RID: 7219
		public GEnum54 genum54_0;

		// Token: 0x04001C34 RID: 7220
		public GStruct78 gstruct78_0;

		// Token: 0x04001C35 RID: 7221
		public int int_1;

		// Token: 0x04001C36 RID: 7222
		public int int_2;

		// Token: 0x04001C37 RID: 7223
		public int int_3;

		// Token: 0x04001C38 RID: 7224
		public float float_0;
	}
}
