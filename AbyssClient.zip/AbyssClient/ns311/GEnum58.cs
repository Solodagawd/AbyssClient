﻿using System;

namespace ns311
{
	// Token: 0x02000275 RID: 629
	public enum GEnum58
	{
		// Token: 0x04001111 RID: 4369
		const_0,
		// Token: 0x04001112 RID: 4370
		const_1,
		// Token: 0x04001113 RID: 4371
		const_2,
		// Token: 0x04001114 RID: 4372
		const_3,
		// Token: 0x04001115 RID: 4373
		const_4,
		// Token: 0x04001116 RID: 4374
		const_5,
		// Token: 0x04001117 RID: 4375
		const_6,
		// Token: 0x04001118 RID: 4376
		const_7,
		// Token: 0x04001119 RID: 4377
		const_8,
		// Token: 0x0400111A RID: 4378
		const_9,
		// Token: 0x0400111B RID: 4379
		const_10,
		// Token: 0x0400111C RID: 4380
		const_11,
		// Token: 0x0400111D RID: 4381
		const_12,
		// Token: 0x0400111E RID: 4382
		const_13,
		// Token: 0x0400111F RID: 4383
		const_14,
		// Token: 0x04001120 RID: 4384
		const_15
	}
}
