﻿using System;
using System.Runtime.InteropServices;
using ns417;
using ns54;

namespace ns518
{
	// Token: 0x02000385 RID: 901
	[Attribute2(335)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct288
	{
		// Token: 0x04001CAF RID: 7343
		public const int int_0 = 335;

		// Token: 0x04001CB0 RID: 7344
		public GStruct22 gstruct22_0;

		// Token: 0x04001CB1 RID: 7345
		public int int_1;

		// Token: 0x04001CB2 RID: 7346
		public byte byte_0;
	}
}
