﻿using System;

namespace ns33
{
	// Token: 0x02000025 RID: 37
	public enum GEnum1
	{
		// Token: 0x0400008B RID: 139
		const_0,
		// Token: 0x0400008C RID: 140
		const_1,
		// Token: 0x0400008D RID: 141
		const_2 = 10,
		// Token: 0x0400008E RID: 142
		const_3,
		// Token: 0x0400008F RID: 143
		const_4,
		// Token: 0x04000090 RID: 144
		const_5 = 15,
		// Token: 0x04000091 RID: 145
		const_6 = 21,
		// Token: 0x04000092 RID: 146
		const_7,
		// Token: 0x04000093 RID: 147
		const_8,
		// Token: 0x04000094 RID: 148
		const_9,
		// Token: 0x04000095 RID: 149
		const_10
	}
}
