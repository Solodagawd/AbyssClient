﻿using System;
using System.Runtime.InteropServices;
using ns169;
using ns288;
using ns291;
using ns417;

namespace ns40
{
	// Token: 0x0200002C RID: 44
	[Attribute2(1327)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct18
	{
		// Token: 0x040000A6 RID: 166
		public const int int_0 = 1327;

		// Token: 0x040000A7 RID: 167
		public GEnum54 genum54_0;

		// Token: 0x040000A8 RID: 168
		public GStruct78 gstruct78_0;

		// Token: 0x040000A9 RID: 169
		public GEnum53 genum53_0;
	}
}
