﻿using System;

namespace ns364
{
	// Token: 0x020002C8 RID: 712
	public enum GEnum70
	{
		// Token: 0x040012BF RID: 4799
		const_0,
		// Token: 0x040012C0 RID: 4800
		const_1,
		// Token: 0x040012C1 RID: 4801
		const_2,
		// Token: 0x040012C2 RID: 4802
		const_3,
		// Token: 0x040012C3 RID: 4803
		const_4,
		// Token: 0x040012C4 RID: 4804
		const_5
	}
}
