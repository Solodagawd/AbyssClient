﻿using System;
using System.Runtime.InteropServices;
using ns291;
using ns417;
using ns554;

namespace ns27
{
	// Token: 0x0200001F RID: 31
	[Attribute2(1111)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct10
	{
		// Token: 0x04000077 RID: 119
		public const int int_0 = 1111;

		// Token: 0x04000078 RID: 120
		public GEnum54 genum54_0;

		// Token: 0x04000079 RID: 121
		public GStruct305 gstruct305_0;
	}
}
