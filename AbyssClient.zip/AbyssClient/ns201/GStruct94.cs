﻿using System;
using System.Runtime.InteropServices;
using ns417;

namespace ns201
{
	// Token: 0x02000147 RID: 327
	[Attribute2(4013)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct94
	{
		// Token: 0x040008E1 RID: 2273
		public const int int_0 = 4013;

		// Token: 0x040008E2 RID: 2274
		public int int_1;
	}
}
