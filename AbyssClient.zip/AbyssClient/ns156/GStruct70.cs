﻿using System;
using System.Runtime.InteropServices;
using ns417;
using ns54;

namespace ns156
{
	// Token: 0x02000105 RID: 261
	[Attribute2(1203)]
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public struct GStruct70
	{
		// Token: 0x04000672 RID: 1650
		public const int int_0 = 1203;

		// Token: 0x04000673 RID: 1651
		public GStruct22 gstruct22_0;

		// Token: 0x04000674 RID: 1652
		public byte byte_0;
	}
}
