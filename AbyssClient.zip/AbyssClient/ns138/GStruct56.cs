﻿using System;
using ns417;

namespace ns138
{
	// Token: 0x020000D7 RID: 215
	[Attribute2(4604)]
	public struct GStruct56
	{
		// Token: 0x0400053D RID: 1341
		public const int int_0 = 4604;
	}
}
