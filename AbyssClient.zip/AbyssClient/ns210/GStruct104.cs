﻿using System;
using System.Runtime.InteropServices;
using ns151;
using ns417;

namespace ns210
{
	// Token: 0x0200017C RID: 380
	[Attribute2(3902)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct104
	{
		// Token: 0x04000A9B RID: 2715
		public const int int_0 = 3902;

		// Token: 0x04000A9C RID: 2716
		public GStruct66 gstruct66_0;
	}
}
