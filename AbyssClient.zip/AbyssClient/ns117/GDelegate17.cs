﻿using System;
using System.Runtime.InteropServices;

namespace ns117
{
	// Token: 0x020000BA RID: 186
	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	public delegate GDelegate17();
}
