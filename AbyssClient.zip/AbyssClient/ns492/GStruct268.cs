﻿using System;
using System.Runtime.InteropServices;
using ns151;
using ns169;
using ns417;

namespace ns492
{
	// Token: 0x02000355 RID: 853
	[Attribute2(1321)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct268
	{
		// Token: 0x04001BA3 RID: 7075
		public const int int_0 = 1321;

		// Token: 0x04001BA4 RID: 7076
		public GStruct78 gstruct78_0;

		// Token: 0x04001BA5 RID: 7077
		public GStruct66 gstruct66_0;
	}
}
