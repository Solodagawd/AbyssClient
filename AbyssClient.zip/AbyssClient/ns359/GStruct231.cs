﻿using System;
using System.Runtime.InteropServices;
using ns417;

namespace ns359
{
	// Token: 0x020002C1 RID: 705
	[Attribute2(4110)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct231
	{
		// Token: 0x040012A9 RID: 4777
		public const int int_0 = 4110;

		// Token: 0x040012AA RID: 4778
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_0;
	}
}
