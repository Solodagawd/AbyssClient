﻿using System;
using ns417;

namespace ns392
{
	// Token: 0x020002F5 RID: 757
	[Attribute2(4108)]
	public struct GStruct245
	{
		// Token: 0x040018D6 RID: 6358
		public const int int_0 = 4108;
	}
}
