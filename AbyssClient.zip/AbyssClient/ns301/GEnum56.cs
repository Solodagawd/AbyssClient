﻿using System;

namespace ns301
{
	// Token: 0x02000269 RID: 617
	public enum GEnum56
	{
		// Token: 0x040010C7 RID: 4295
		const_0,
		// Token: 0x040010C8 RID: 4296
		const_1,
		// Token: 0x040010C9 RID: 4297
		const_2,
		// Token: 0x040010CA RID: 4298
		const_3,
		// Token: 0x040010CB RID: 4299
		const_4,
		// Token: 0x040010CC RID: 4300
		const_5,
		// Token: 0x040010CD RID: 4301
		const_6,
		// Token: 0x040010CE RID: 4302
		const_7
	}
}
