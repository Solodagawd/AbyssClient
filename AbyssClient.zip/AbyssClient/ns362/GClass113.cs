﻿using System;
using System.Runtime.InteropServices;

namespace ns362
{
	// Token: 0x020002C4 RID: 708
	public static class GClass113
	{
		// Token: 0x040012B1 RID: 4785
		public const int int_0 = 8;

		// Token: 0x020002C5 RID: 709
		[StructLayout(LayoutKind.Sequential, Pack = 8)]
		private struct Struct23
		{
			// Token: 0x040012B2 RID: 4786
			private readonly uint uint_0;

			// Token: 0x040012B3 RID: 4787
			private readonly ulong ulong_0;

			// Token: 0x040012B4 RID: 4788
			private readonly ushort ushort_0;

			// Token: 0x040012B5 RID: 4789
			private readonly double double_0;
		}
	}
}
