﻿using System;
using System.Runtime.InteropServices;
using ns274;
using ns417;

namespace ns235
{
	// Token: 0x020001B1 RID: 433
	[Attribute2(2103)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct127
	{
		// Token: 0x04000C1F RID: 3103
		public const int int_0 = 2103;

		// Token: 0x04000C20 RID: 3104
		public GStruct188 gstruct188_0;

		// Token: 0x04000C21 RID: 3105
		public ulong ulong_0;

		// Token: 0x04000C22 RID: 3106
		public uint uint_0;

		// Token: 0x04000C23 RID: 3107
		public uint uint_1;
	}
}
