﻿using System;
using System.Runtime.InteropServices;
using ns291;
using ns417;
using ns54;

namespace ns300
{
	// Token: 0x02000268 RID: 616
	[Attribute2(344)]
	[StructLayout(LayoutKind.Sequential, Pack = 4)]
	public struct GStruct200
	{
		// Token: 0x040010C2 RID: 4290
		public const int int_0 = 344;

		// Token: 0x040010C3 RID: 4291
		public GEnum54 genum54_0;

		// Token: 0x040010C4 RID: 4292
		public GStruct22 gstruct22_0;

		// Token: 0x040010C5 RID: 4293
		public int int_1;
	}
}
