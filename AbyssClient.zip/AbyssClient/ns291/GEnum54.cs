﻿using System;

namespace ns291
{
	// Token: 0x02000253 RID: 595
	public enum GEnum54
	{
		// Token: 0x04000FC0 RID: 4032
		const_0 = 1,
		// Token: 0x04000FC1 RID: 4033
		const_1,
		// Token: 0x04000FC2 RID: 4034
		const_2,
		// Token: 0x04000FC3 RID: 4035
		const_3 = 5,
		// Token: 0x04000FC4 RID: 4036
		const_4,
		// Token: 0x04000FC5 RID: 4037
		const_5,
		// Token: 0x04000FC6 RID: 4038
		const_6,
		// Token: 0x04000FC7 RID: 4039
		const_7,
		// Token: 0x04000FC8 RID: 4040
		const_8,
		// Token: 0x04000FC9 RID: 4041
		const_9,
		// Token: 0x04000FCA RID: 4042
		const_10,
		// Token: 0x04000FCB RID: 4043
		const_11,
		// Token: 0x04000FCC RID: 4044
		const_12,
		// Token: 0x04000FCD RID: 4045
		const_13,
		// Token: 0x04000FCE RID: 4046
		const_14,
		// Token: 0x04000FCF RID: 4047
		const_15,
		// Token: 0x04000FD0 RID: 4048
		const_16,
		// Token: 0x04000FD1 RID: 4049
		const_17,
		// Token: 0x04000FD2 RID: 4050
		const_18,
		// Token: 0x04000FD3 RID: 4051
		const_19,
		// Token: 0x04000FD4 RID: 4052
		const_20,
		// Token: 0x04000FD5 RID: 4053
		const_21,
		// Token: 0x04000FD6 RID: 4054
		const_22,
		// Token: 0x04000FD7 RID: 4055
		const_23,
		// Token: 0x04000FD8 RID: 4056
		const_24,
		// Token: 0x04000FD9 RID: 4057
		const_25,
		// Token: 0x04000FDA RID: 4058
		const_26,
		// Token: 0x04000FDB RID: 4059
		const_27,
		// Token: 0x04000FDC RID: 4060
		const_28,
		// Token: 0x04000FDD RID: 4061
		const_29,
		// Token: 0x04000FDE RID: 4062
		const_30,
		// Token: 0x04000FDF RID: 4063
		const_31,
		// Token: 0x04000FE0 RID: 4064
		const_32,
		// Token: 0x04000FE1 RID: 4065
		const_33,
		// Token: 0x04000FE2 RID: 4066
		const_34,
		// Token: 0x04000FE3 RID: 4067
		const_35,
		// Token: 0x04000FE4 RID: 4068
		const_36,
		// Token: 0x04000FE5 RID: 4069
		const_37,
		// Token: 0x04000FE6 RID: 4070
		const_38,
		// Token: 0x04000FE7 RID: 4071
		const_39,
		// Token: 0x04000FE8 RID: 4072
		const_40,
		// Token: 0x04000FE9 RID: 4073
		const_41,
		// Token: 0x04000FEA RID: 4074
		const_42,
		// Token: 0x04000FEB RID: 4075
		const_43,
		// Token: 0x04000FEC RID: 4076
		const_44,
		// Token: 0x04000FED RID: 4077
		const_45,
		// Token: 0x04000FEE RID: 4078
		const_46,
		// Token: 0x04000FEF RID: 4079
		const_47,
		// Token: 0x04000FF0 RID: 4080
		const_48,
		// Token: 0x04000FF1 RID: 4081
		const_49,
		// Token: 0x04000FF2 RID: 4082
		const_50,
		// Token: 0x04000FF3 RID: 4083
		const_51,
		// Token: 0x04000FF4 RID: 4084
		const_52,
		// Token: 0x04000FF5 RID: 4085
		const_53,
		// Token: 0x04000FF6 RID: 4086
		const_54,
		// Token: 0x04000FF7 RID: 4087
		const_55,
		// Token: 0x04000FF8 RID: 4088
		const_56,
		// Token: 0x04000FF9 RID: 4089
		const_57,
		// Token: 0x04000FFA RID: 4090
		const_58,
		// Token: 0x04000FFB RID: 4091
		const_59,
		// Token: 0x04000FFC RID: 4092
		const_60,
		// Token: 0x04000FFD RID: 4093
		const_61,
		// Token: 0x04000FFE RID: 4094
		const_62,
		// Token: 0x04000FFF RID: 4095
		const_63,
		// Token: 0x04001000 RID: 4096
		const_64,
		// Token: 0x04001001 RID: 4097
		const_65,
		// Token: 0x04001002 RID: 4098
		const_66,
		// Token: 0x04001003 RID: 4099
		const_67,
		// Token: 0x04001004 RID: 4100
		const_68,
		// Token: 0x04001005 RID: 4101
		const_69,
		// Token: 0x04001006 RID: 4102
		const_70,
		// Token: 0x04001007 RID: 4103
		const_71,
		// Token: 0x04001008 RID: 4104
		const_72,
		// Token: 0x04001009 RID: 4105
		const_73,
		// Token: 0x0400100A RID: 4106
		const_74,
		// Token: 0x0400100B RID: 4107
		const_75,
		// Token: 0x0400100C RID: 4108
		const_76,
		// Token: 0x0400100D RID: 4109
		const_77,
		// Token: 0x0400100E RID: 4110
		const_78,
		// Token: 0x0400100F RID: 4111
		const_79,
		// Token: 0x04001010 RID: 4112
		const_80,
		// Token: 0x04001011 RID: 4113
		const_81,
		// Token: 0x04001012 RID: 4114
		const_82,
		// Token: 0x04001013 RID: 4115
		const_83,
		// Token: 0x04001014 RID: 4116
		const_84,
		// Token: 0x04001015 RID: 4117
		const_85,
		// Token: 0x04001016 RID: 4118
		const_86,
		// Token: 0x04001017 RID: 4119
		const_87,
		// Token: 0x04001018 RID: 4120
		const_88,
		// Token: 0x04001019 RID: 4121
		const_89,
		// Token: 0x0400101A RID: 4122
		const_90,
		// Token: 0x0400101B RID: 4123
		const_91,
		// Token: 0x0400101C RID: 4124
		const_92,
		// Token: 0x0400101D RID: 4125
		const_93,
		// Token: 0x0400101E RID: 4126
		const_94,
		// Token: 0x0400101F RID: 4127
		const_95,
		// Token: 0x04001020 RID: 4128
		const_96,
		// Token: 0x04001021 RID: 4129
		const_97,
		// Token: 0x04001022 RID: 4130
		const_98,
		// Token: 0x04001023 RID: 4131
		const_99,
		// Token: 0x04001024 RID: 4132
		const_100,
		// Token: 0x04001025 RID: 4133
		const_101,
		// Token: 0x04001026 RID: 4134
		const_102,
		// Token: 0x04001027 RID: 4135
		const_103,
		// Token: 0x04001028 RID: 4136
		const_104,
		// Token: 0x04001029 RID: 4137
		const_105,
		// Token: 0x0400102A RID: 4138
		const_106,
		// Token: 0x0400102B RID: 4139
		const_107,
		// Token: 0x0400102C RID: 4140
		const_108,
		// Token: 0x0400102D RID: 4141
		const_109,
		// Token: 0x0400102E RID: 4142
		const_110
	}
}
