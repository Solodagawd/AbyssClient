﻿using System;
using System.Runtime.InteropServices;
using ns151;
using ns417;

namespace ns296
{
	// Token: 0x02000264 RID: 612
	[Attribute2(1005)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct198
	{
		// Token: 0x040010B4 RID: 4276
		public const int int_0 = 1005;

		// Token: 0x040010B5 RID: 4277
		public GStruct66 gstruct66_0;
	}
}
