﻿using System;
using System.Runtime.InteropServices;
using ns291;
using ns417;

namespace ns337
{
	// Token: 0x020002A5 RID: 677
	[Attribute2(207)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct222
	{
		// Token: 0x04001236 RID: 4662
		public const int int_0 = 207;

		// Token: 0x04001237 RID: 4663
		public GEnum54 genum54_0;

		// Token: 0x04001238 RID: 4664
		public int int_1;

		// Token: 0x04001239 RID: 4665
		public uint uint_0;

		// Token: 0x0400123A RID: 4666
		public uint uint_1;
	}
}
