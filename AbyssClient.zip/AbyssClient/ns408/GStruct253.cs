﻿using System;
using ns417;

namespace ns408
{
	// Token: 0x0200030F RID: 783
	[Attribute2(4104)]
	public struct GStruct253
	{
		// Token: 0x04001913 RID: 6419
		public const int int_0 = 4104;
	}
}
