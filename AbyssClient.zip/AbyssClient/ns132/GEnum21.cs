﻿using System;

namespace ns132
{
	// Token: 0x020000CB RID: 203
	public enum GEnum21
	{
		// Token: 0x04000505 RID: 1285
		const_0,
		// Token: 0x04000506 RID: 1286
		const_1
	}
}
