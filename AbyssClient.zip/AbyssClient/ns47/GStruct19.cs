﻿using System;
using System.Runtime.InteropServices;
using ns169;
using ns291;
using ns417;

namespace ns47
{
	// Token: 0x0200003F RID: 63
	[Attribute2(1309)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct19
	{
		// Token: 0x040000DC RID: 220
		public const int int_0 = 1309;

		// Token: 0x040000DD RID: 221
		public GEnum54 genum54_0;

		// Token: 0x040000DE RID: 222
		public GStruct78 gstruct78_0;

		// Token: 0x040000DF RID: 223
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_0;
	}
}
