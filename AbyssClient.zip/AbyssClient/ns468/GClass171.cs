﻿using System;
using ns467;
using ns469;
using ns470;
using ns472;

namespace ns468
{
	// Token: 0x020000CA RID: 202
	public class GClass171 : GClass170
	{
		// Token: 0x060005F9 RID: 1529 RVA: 0x00019BA4 File Offset: 0x00017DA4
		public override void vmethod_24()
		{
			this.method_55();
		}

		// Token: 0x060005FA RID: 1530 RVA: 0x00019BB8 File Offset: 0x00017DB8
		public override void vmethod_29()
		{
			this.method_46();
		}

		// Token: 0x060005FB RID: 1531 RVA: 0x00019BCC File Offset: 0x00017DCC
		internal void method_42()
		{
			this.method_73();
		}

		// Token: 0x060005FC RID: 1532 RVA: 0x00019BE0 File Offset: 0x00017DE0
		internal void method_43()
		{
			base.vmethod_24();
		}

		// Token: 0x060005FD RID: 1533 RVA: 0x00019BF4 File Offset: 0x00017DF4
		internal void method_44()
		{
			base.vmethod_26();
		}

		// Token: 0x060005FE RID: 1534 RVA: 0x00019C08 File Offset: 0x00017E08
		internal void method_45(int int_0)
		{
			base.vmethod_8(int_0);
		}

		// Token: 0x060005FF RID: 1535 RVA: 0x00019C1C File Offset: 0x00017E1C
		public override void vmethod_26()
		{
			this.method_66();
		}

		// Token: 0x06000600 RID: 1536 RVA: 0x00019C30 File Offset: 0x00017E30
		internal void method_46()
		{
			this.method_47();
		}

		// Token: 0x06000601 RID: 1537 RVA: 0x00019C44 File Offset: 0x00017E44
		internal void method_47()
		{
			base.vmethod_29();
			this.bool_0 = true;
		}

		// Token: 0x06000602 RID: 1538 RVA: 0x00019C60 File Offset: 0x00017E60
		public override void vmethod_11()
		{
			this.method_67();
		}

		// Token: 0x06000603 RID: 1539 RVA: 0x00019C74 File Offset: 0x00017E74
		internal void method_48()
		{
			base.vmethod_25();
		}

		// Token: 0x06000604 RID: 1540 RVA: 0x00019C88 File Offset: 0x00017E88
		internal void method_49(GClass172 gclass172_1)
		{
			this.method_58(gclass172_1);
		}

		// Token: 0x06000605 RID: 1541 RVA: 0x00019C9C File Offset: 0x00017E9C
		internal void method_50()
		{
			this.method_48();
		}

		// Token: 0x06000606 RID: 1542 RVA: 0x00019CB0 File Offset: 0x00017EB0
		internal void method_51()
		{
			base.vmethod_22();
		}

		// Token: 0x06000607 RID: 1543 RVA: 0x00019CC4 File Offset: 0x00017EC4
		internal void method_52()
		{
			this.method_62();
		}

		// Token: 0x06000608 RID: 1544 RVA: 0x00019CD8 File Offset: 0x00017ED8
		internal void method_53()
		{
			this.method_75();
		}

		// Token: 0x06000609 RID: 1545 RVA: 0x00019CEC File Offset: 0x00017EEC
		public override void vmethod_10()
		{
			this.method_64();
		}

		// Token: 0x0600060A RID: 1546 RVA: 0x00019D00 File Offset: 0x00017F00
		public override void vmethod_12()
		{
			this.method_57();
		}

		// Token: 0x0600060B RID: 1547 RVA: 0x00019D14 File Offset: 0x00017F14
		public override void vmethod_8(int int_0)
		{
			this.method_54(int_0);
		}

		// Token: 0x0600060C RID: 1548 RVA: 0x00019D28 File Offset: 0x00017F28
		internal void method_54(int int_0)
		{
			this.method_45(int_0);
		}

		// Token: 0x0600060D RID: 1549 RVA: 0x00019D3C File Offset: 0x00017F3C
		internal void method_55()
		{
			this.method_43();
		}

		// Token: 0x0600060E RID: 1550 RVA: 0x00019D50 File Offset: 0x00017F50
		internal void method_56()
		{
			this.method_68();
		}

		// Token: 0x0600060F RID: 1551 RVA: 0x00019D64 File Offset: 0x00017F64
		internal void method_57()
		{
			this.method_59();
		}

		// Token: 0x06000610 RID: 1552 RVA: 0x00019D78 File Offset: 0x00017F78
		internal void method_58(GClass172 gclass172_1)
		{
			base.vmethod_33(gclass172_1);
			if (gclass172_1 == this.gclass172_0)
			{
			}
		}

		// Token: 0x06000611 RID: 1553 RVA: 0x00019D9C File Offset: 0x00017F9C
		internal void method_59()
		{
			base.vmethod_12();
		}

		// Token: 0x06000612 RID: 1554 RVA: 0x00019DB0 File Offset: 0x00017FB0
		internal void method_60()
		{
			this.method_51();
		}

		// Token: 0x06000613 RID: 1555 RVA: 0x00019DC4 File Offset: 0x00017FC4
		public override void vmethod_15()
		{
			this.method_56();
		}

		// Token: 0x06000614 RID: 1556 RVA: 0x00019DD8 File Offset: 0x00017FD8
		public override GClass172 vmethod_34()
		{
			return new GClass173();
		}

		// Token: 0x06000615 RID: 1557 RVA: 0x00019DEC File Offset: 0x00017FEC
		internal void method_61(int int_0)
		{
			base.vmethod_27(int_0);
		}

		// Token: 0x06000617 RID: 1559 RVA: 0x00019E24 File Offset: 0x00018024
		internal void method_62()
		{
			base.vmethod_19();
		}

		// Token: 0x06000618 RID: 1560 RVA: 0x00019E38 File Offset: 0x00018038
		internal void method_63()
		{
			this.method_74();
		}

		// Token: 0x06000619 RID: 1561 RVA: 0x00019E4C File Offset: 0x0001804C
		internal void method_64()
		{
			this.method_65();
		}

		// Token: 0x0600061A RID: 1562 RVA: 0x00019E60 File Offset: 0x00018060
		internal void method_65()
		{
			base.vmethod_10();
		}

		// Token: 0x0600061B RID: 1563 RVA: 0x00019E74 File Offset: 0x00018074
		public override void vmethod_19()
		{
			this.method_52();
		}

		// Token: 0x0600061C RID: 1564 RVA: 0x00019E88 File Offset: 0x00018088
		public override void vmethod_28()
		{
			this.method_70();
		}

		// Token: 0x0600061D RID: 1565 RVA: 0x00019E9C File Offset: 0x0001809C
		internal void method_66()
		{
			this.method_44();
		}

		// Token: 0x0600061E RID: 1566 RVA: 0x00019EB0 File Offset: 0x000180B0
		internal void method_67()
		{
			this.method_71();
		}

		// Token: 0x0600061F RID: 1567 RVA: 0x00019EC4 File Offset: 0x000180C4
		public override void vmethod_23()
		{
			this.method_53();
		}

		// Token: 0x06000620 RID: 1568 RVA: 0x00019ED8 File Offset: 0x000180D8
		internal void method_68()
		{
			base.vmethod_15();
		}

		// Token: 0x06000621 RID: 1569 RVA: 0x00019EEC File Offset: 0x000180EC
		public override void vmethod_31()
		{
			this.method_42();
		}

		// Token: 0x06000622 RID: 1570 RVA: 0x00019F00 File Offset: 0x00018100
		public override void vmethod_33(GClass172 gclass172_1)
		{
			this.method_49(gclass172_1);
		}

		// Token: 0x06000623 RID: 1571 RVA: 0x00019F14 File Offset: 0x00018114
		internal void method_69(int int_0)
		{
			this.method_61(int_0);
		}

		// Token: 0x06000624 RID: 1572 RVA: 0x00019F28 File Offset: 0x00018128
		internal void method_70()
		{
			this.method_72();
		}

		// Token: 0x06000625 RID: 1573 RVA: 0x00019F3C File Offset: 0x0001813C
		public override void vmethod_22()
		{
			this.method_60();
		}

		// Token: 0x06000626 RID: 1574 RVA: 0x00019F50 File Offset: 0x00018150
		public override void vmethod_9()
		{
			this.method_63();
		}

		// Token: 0x06000627 RID: 1575 RVA: 0x00019F64 File Offset: 0x00018164
		internal void method_71()
		{
			base.vmethod_11();
		}

		// Token: 0x06000628 RID: 1576 RVA: 0x00019F78 File Offset: 0x00018178
		internal void method_72()
		{
			base.vmethod_28();
		}

		// Token: 0x06000629 RID: 1577 RVA: 0x00019F8C File Offset: 0x0001818C
		internal void method_73()
		{
			base.vmethod_31();
		}

		// Token: 0x0600062A RID: 1578 RVA: 0x00019FA0 File Offset: 0x000181A0
		internal void method_74()
		{
			base.vmethod_9();
		}

		// Token: 0x0600062B RID: 1579 RVA: 0x00019FB4 File Offset: 0x000181B4
		public override void vmethod_25()
		{
			this.method_50();
		}

		// Token: 0x0600062C RID: 1580 RVA: 0x00019FC8 File Offset: 0x000181C8
		public override void vmethod_27(int int_0)
		{
			this.method_69(int_0);
		}

		// Token: 0x0600062D RID: 1581 RVA: 0x00019FDC File Offset: 0x000181DC
		internal void method_75()
		{
			base.vmethod_23();
			try
			{
				this.gclass173_0 = (GClass173)this.gclass172_0;
			}
			catch
			{
			}
			this.gclass175_0 = new GClass175
			{
				gclass173_0 = this.gclass173_0
			};
			this.vmethod_32(this.gclass175_0);
		}

		// Token: 0x04000502 RID: 1282
		public GClass175 gclass175_0 = null;

		// Token: 0x04000503 RID: 1283
		public GClass173 gclass173_0 = null;
	}
}
