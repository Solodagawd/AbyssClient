﻿using System;

namespace ns51
{
	// Token: 0x02000043 RID: 67
	internal static class Class4
	{
		// Token: 0x17000003 RID: 3
		// (get) Token: 0x0600023C RID: 572 RVA: 0x00007424 File Offset: 0x00005624
		public static string String_0
		{
			get
			{
				return Class4.smethod_0();
			}
		}

		// Token: 0x0600023D RID: 573 RVA: 0x00007438 File Offset: 0x00005638
		internal static string smethod_0()
		{
			return Class4.smethod_1();
		}

		// Token: 0x0600023F RID: 575 RVA: 0x0000744C File Offset: 0x0000564C
		internal static string smethod_1()
		{
			return "https://api.emmvrc.com:443";
		}
	}
}
