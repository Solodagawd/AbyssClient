﻿using System;
using System.Runtime.InteropServices;
using ns417;

namespace ns321
{
	// Token: 0x02000280 RID: 640
	[Attribute2(4114)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct210
	{
		// Token: 0x04001192 RID: 4498
		public const int int_0 = 4114;

		// Token: 0x04001193 RID: 4499
		public int int_1;
	}
}
