﻿using System;

namespace ns548
{
	// Token: 0x020003A5 RID: 933
	public enum GEnum94
	{
		// Token: 0x04001D7F RID: 7551
		const_0,
		// Token: 0x04001D80 RID: 7552
		const_1,
		// Token: 0x04001D81 RID: 7553
		const_2
	}
}
