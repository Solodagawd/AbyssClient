﻿using System;

namespace ns219
{
	// Token: 0x02000199 RID: 409
	public static class GClass77
	{
		// Token: 0x04000B8D RID: 2957
		public const string string_0 = "12.0.0";

		// Token: 0x04000B8E RID: 2958
		public const string string_1 = "1.42";

		// Token: 0x04000B8F RID: 2959
		public const string string_2 = "04.28.51.07";

		// Token: 0x04000B90 RID: 2960
		public const int int_0 = 227616;

		// Token: 0x04000B91 RID: 2961
		public const int int_1 = 250656;
	}
}
