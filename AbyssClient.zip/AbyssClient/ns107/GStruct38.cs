﻿using System;
using System.Runtime.InteropServices;
using ns151;
using ns417;

namespace ns107
{
	// Token: 0x02000091 RID: 145
	[Attribute2(3901)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct38
	{
		// Token: 0x04000314 RID: 788
		public const int int_0 = 3901;

		// Token: 0x04000315 RID: 789
		public GStruct66 gstruct66_0;
	}
}
