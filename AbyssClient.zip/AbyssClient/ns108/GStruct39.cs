﻿using System;
using System.Runtime.InteropServices;
using ns169;
using ns291;
using ns417;

namespace ns108
{
	// Token: 0x02000092 RID: 146
	[Attribute2(1315)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct39
	{
		// Token: 0x04000316 RID: 790
		public const int int_0 = 1315;

		// Token: 0x04000317 RID: 791
		public GEnum54 genum54_0;

		// Token: 0x04000318 RID: 792
		public GStruct78 gstruct78_0;
	}
}
