﻿using System;
using System.Runtime.InteropServices;
using ns291;
using ns417;

namespace ns193
{
	// Token: 0x0200013A RID: 314
	[Attribute2(1102)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct89
	{
		// Token: 0x040007E0 RID: 2016
		public const int int_0 = 1102;

		// Token: 0x040007E1 RID: 2017
		public ulong ulong_0;

		// Token: 0x040007E2 RID: 2018
		public GEnum54 genum54_0;
	}
}
