﻿using System;

namespace ns525
{
	// Token: 0x0200038C RID: 908
	public struct GStruct289
	{
		// Token: 0x04001CD7 RID: 7383
		public uint uint_0;

		// Token: 0x04001CD8 RID: 7384
		public byte byte_0;
	}
}
