﻿using System;
using System.Runtime.InteropServices;
using ns417;

namespace ns37
{
	// Token: 0x02000029 RID: 41
	[Attribute2(115)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct17
	{
		// Token: 0x0400009B RID: 155
		public const int int_0 = 115;

		// Token: 0x0400009C RID: 156
		public byte byte_0;
	}
}
