﻿using System;
using System.Runtime.InteropServices;
using ns291;
using ns417;
using ns54;

namespace ns535
{
	// Token: 0x02000396 RID: 918
	[Attribute2(1801)]
	[StructLayout(LayoutKind.Sequential, Pack = 4)]
	public struct GStruct296
	{
		// Token: 0x04001D0F RID: 7439
		public const int int_0 = 1801;

		// Token: 0x04001D10 RID: 7440
		public GEnum54 genum54_0;

		// Token: 0x04001D11 RID: 7441
		public GStruct22 gstruct22_0;
	}
}
