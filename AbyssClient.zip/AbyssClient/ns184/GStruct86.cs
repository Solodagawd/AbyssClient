﻿using System;
using System.Runtime.InteropServices;
using ns151;
using ns169;
using ns291;
using ns417;

namespace ns184
{
	// Token: 0x02000128 RID: 296
	[Attribute2(3406)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct86
	{
		// Token: 0x0400074B RID: 1867
		public const int int_0 = 3406;

		// Token: 0x0400074C RID: 1868
		public GStruct66 gstruct66_0;

		// Token: 0x0400074D RID: 1869
		public GStruct78 gstruct78_0;

		// Token: 0x0400074E RID: 1870
		public GEnum54 genum54_0;
	}
}
