﻿using System;
using ns417;

namespace ns411
{
	// Token: 0x02000315 RID: 789
	[Attribute2(5001)]
	public struct GStruct254
	{
		// Token: 0x04001930 RID: 6448
		public const int int_0 = 5001;
	}
}
