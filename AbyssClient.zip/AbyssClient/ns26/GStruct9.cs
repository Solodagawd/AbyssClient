﻿using System;
using System.Runtime.InteropServices;

namespace ns26
{
	// Token: 0x0200001E RID: 30
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct9
	{
		// Token: 0x0400006F RID: 111
		public byte byte_0;

		// Token: 0x04000070 RID: 112
		public byte byte_1;

		// Token: 0x04000071 RID: 113
		public byte byte_2;

		// Token: 0x04000072 RID: 114
		public byte byte_3;

		// Token: 0x04000073 RID: 115
		public int int_0;

		// Token: 0x04000074 RID: 116
		public int int_1;

		// Token: 0x04000075 RID: 117
		public uint uint_0;

		// Token: 0x04000076 RID: 118
		public ushort ushort_0;
	}
}
