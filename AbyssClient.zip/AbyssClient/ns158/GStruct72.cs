﻿using System;
using System.Runtime.InteropServices;
using ns169;
using ns291;
using ns417;

namespace ns158
{
	// Token: 0x02000107 RID: 263
	[Attribute2(1316)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct72
	{
		// Token: 0x04000677 RID: 1655
		public const int int_0 = 1316;

		// Token: 0x04000678 RID: 1656
		public GEnum54 genum54_0;

		// Token: 0x04000679 RID: 1657
		public GStruct78 gstruct78_0;

		// Token: 0x0400067A RID: 1658
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_0;
	}
}
