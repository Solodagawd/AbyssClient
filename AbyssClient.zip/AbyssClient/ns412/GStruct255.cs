﻿using System;
using System.Runtime.InteropServices;
using ns118;
using ns417;

namespace ns412
{
	// Token: 0x02000316 RID: 790
	[Attribute2(4507)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct255
	{
		// Token: 0x04001931 RID: 6449
		public const int int_0 = 4507;

		// Token: 0x04001932 RID: 6450
		public GStruct43 gstruct43_0;

		// Token: 0x04001933 RID: 6451
		public string string_0;
	}
}
