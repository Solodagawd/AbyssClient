﻿using System;
using Mono.CSharp;

namespace ns399
{
	// Token: 0x02000306 RID: 774
	public class GClass122 : InteractiveBase
	{
	}
}
