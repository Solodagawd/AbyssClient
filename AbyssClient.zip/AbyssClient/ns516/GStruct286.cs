﻿using System;
using System.Runtime.InteropServices;
using ns118;
using ns417;

namespace ns516
{
	// Token: 0x02000383 RID: 899
	[Attribute2(4513)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct286
	{
		// Token: 0x04001CA4 RID: 7332
		public const int int_0 = 4513;

		// Token: 0x04001CA5 RID: 7333
		public GStruct43 gstruct43_0;

		// Token: 0x04001CA6 RID: 7334
		public uint uint_0;

		// Token: 0x04001CA7 RID: 7335
		public uint uint_1;

		// Token: 0x04001CA8 RID: 7336
		public string string_0;

		// Token: 0x04001CA9 RID: 7337
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_0;

		// Token: 0x04001CAA RID: 7338
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_1;
	}
}
