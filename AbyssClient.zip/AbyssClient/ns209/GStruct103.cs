﻿using System;
using System.Runtime.InteropServices;
using ns417;
using ns89;

namespace ns209
{
	// Token: 0x02000177 RID: 375
	[Attribute2(4701)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct103
	{
		// Token: 0x04000A8A RID: 2698
		public const int int_0 = 4701;

		// Token: 0x04000A8B RID: 2699
		public GStruct31 gstruct31_0;
	}
}
