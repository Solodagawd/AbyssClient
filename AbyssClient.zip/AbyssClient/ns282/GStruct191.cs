﻿using System;
using ns417;

namespace ns282
{
	// Token: 0x02000241 RID: 577
	[Attribute2(101)]
	public struct GStruct191
	{
		// Token: 0x04000F59 RID: 3929
		public const int int_0 = 101;
	}
}
