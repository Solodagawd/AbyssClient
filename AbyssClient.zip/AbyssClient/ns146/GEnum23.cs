﻿using System;

namespace ns146
{
	// Token: 0x020000DF RID: 223
	public enum GEnum23
	{
		// Token: 0x0400055A RID: 1370
		const_0,
		// Token: 0x0400055B RID: 1371
		const_1,
		// Token: 0x0400055C RID: 1372
		const_2,
		// Token: 0x0400055D RID: 1373
		const_3,
		// Token: 0x0400055E RID: 1374
		const_4,
		// Token: 0x0400055F RID: 1375
		const_5,
		// Token: 0x04000560 RID: 1376
		const_6,
		// Token: 0x04000561 RID: 1377
		const_7,
		// Token: 0x04000562 RID: 1378
		const_8,
		// Token: 0x04000563 RID: 1379
		const_9,
		// Token: 0x04000564 RID: 1380
		const_10,
		// Token: 0x04000565 RID: 1381
		const_11,
		// Token: 0x04000566 RID: 1382
		const_12,
		// Token: 0x04000567 RID: 1383
		const_13,
		// Token: 0x04000568 RID: 1384
		const_14,
		// Token: 0x04000569 RID: 1385
		const_15,
		// Token: 0x0400056A RID: 1386
		const_16,
		// Token: 0x0400056B RID: 1387
		const_17,
		// Token: 0x0400056C RID: 1388
		const_18,
		// Token: 0x0400056D RID: 1389
		const_19,
		// Token: 0x0400056E RID: 1390
		const_20,
		// Token: 0x0400056F RID: 1391
		const_21,
		// Token: 0x04000570 RID: 1392
		const_22,
		// Token: 0x04000571 RID: 1393
		const_23,
		// Token: 0x04000572 RID: 1394
		const_24,
		// Token: 0x04000573 RID: 1395
		const_25,
		// Token: 0x04000574 RID: 1396
		const_26,
		// Token: 0x04000575 RID: 1397
		const_27,
		// Token: 0x04000576 RID: 1398
		const_28,
		// Token: 0x04000577 RID: 1399
		const_29,
		// Token: 0x04000578 RID: 1400
		const_30,
		// Token: 0x04000579 RID: 1401
		const_31,
		// Token: 0x0400057A RID: 1402
		const_32,
		// Token: 0x0400057B RID: 1403
		const_33,
		// Token: 0x0400057C RID: 1404
		const_34,
		// Token: 0x0400057D RID: 1405
		const_35,
		// Token: 0x0400057E RID: 1406
		const_36,
		// Token: 0x0400057F RID: 1407
		const_37,
		// Token: 0x04000580 RID: 1408
		const_38,
		// Token: 0x04000581 RID: 1409
		const_39,
		// Token: 0x04000582 RID: 1410
		const_40,
		// Token: 0x04000583 RID: 1411
		const_41
	}
}
