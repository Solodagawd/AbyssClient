﻿using System;
using System.Runtime.InteropServices;
using ns151;
using ns291;
using ns417;

namespace ns145
{
	// Token: 0x020000DE RID: 222
	[Attribute2(1302)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct62
	{
		// Token: 0x04000555 RID: 1365
		public const int int_0 = 1302;

		// Token: 0x04000556 RID: 1366
		public GStruct66 gstruct66_0;

		// Token: 0x04000557 RID: 1367
		public GEnum54 genum54_0;

		// Token: 0x04000558 RID: 1368
		public int int_1;
	}
}
