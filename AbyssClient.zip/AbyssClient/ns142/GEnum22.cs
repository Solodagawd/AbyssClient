﻿using System;

namespace ns142
{
	// Token: 0x020000DB RID: 219
	public enum GEnum22
	{
		// Token: 0x04000549 RID: 1353
		const_0,
		// Token: 0x0400054A RID: 1354
		const_1
	}
}
