﻿using System;
using ns417;

namespace ns389
{
	// Token: 0x020002F0 RID: 752
	[Attribute2(2302)]
	public struct GStruct243
	{
		// Token: 0x040018AB RID: 6315
		public const int int_0 = 2302;
	}
}
