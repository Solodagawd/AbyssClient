﻿using System;
using System.Runtime.InteropServices;
using ns417;

namespace ns512
{
	// Token: 0x02000378 RID: 888
	[Attribute2(510)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct282
	{
		// Token: 0x04001C3D RID: 7229
		public const int int_0 = 510;

		// Token: 0x04001C3E RID: 7230
		public uint uint_0;
	}
}
