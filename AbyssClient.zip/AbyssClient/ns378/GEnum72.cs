﻿using System;

namespace ns378
{
	// Token: 0x020002E2 RID: 738
	[Flags]
	public enum GEnum72
	{
		// Token: 0x040013FA RID: 5114
		flag_0 = 1,
		// Token: 0x040013FB RID: 5115
		flag_1 = 2,
		// Token: 0x040013FC RID: 5116
		flag_2 = 4,
		// Token: 0x040013FD RID: 5117
		flag_3 = 8,
		// Token: 0x040013FE RID: 5118
		flag_4 = 16,
		// Token: 0x040013FF RID: 5119
		flag_5 = 32,
		// Token: 0x04001400 RID: 5120
		flag_6 = 64,
		// Token: 0x04001401 RID: 5121
		flag_7 = 128,
		// Token: 0x04001402 RID: 5122
		flag_8 = 256,
		// Token: 0x04001403 RID: 5123
		flag_9 = 512,
		// Token: 0x04001404 RID: 5124
		flag_10 = 1024,
		// Token: 0x04001405 RID: 5125
		flag_11 = 2048,
		// Token: 0x04001406 RID: 5126
		flag_12 = 4096,
		// Token: 0x04001407 RID: 5127
		flag_13 = 8192
	}
}
