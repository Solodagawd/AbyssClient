﻿using System;
using System.Runtime.InteropServices;
using ns169;
using ns291;
using ns417;
using ns551;

namespace ns162
{
	// Token: 0x0200010B RID: 267
	[Attribute2(1325)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct75
	{
		// Token: 0x04000693 RID: 1683
		public const int int_0 = 1325;

		// Token: 0x04000694 RID: 1684
		public GEnum54 genum54_0;

		// Token: 0x04000695 RID: 1685
		public GStruct78 gstruct78_0;

		// Token: 0x04000696 RID: 1686
		public GEnum95 genum95_0;
	}
}
