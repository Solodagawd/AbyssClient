﻿using System;

namespace ns312
{
	// Token: 0x02000276 RID: 630
	public enum GEnum59
	{
		// Token: 0x04001122 RID: 4386
		const_0,
		// Token: 0x04001123 RID: 4387
		const_1,
		// Token: 0x04001124 RID: 4388
		const_2,
		// Token: 0x04001125 RID: 4389
		const_3,
		// Token: 0x04001126 RID: 4390
		const_4,
		// Token: 0x04001127 RID: 4391
		const_5 = 255
	}
}
