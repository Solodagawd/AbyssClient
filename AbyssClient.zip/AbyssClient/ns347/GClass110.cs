﻿using System;

namespace ns347
{
	// Token: 0x020002B4 RID: 692
	public static class GClass110
	{
		// Token: 0x06002003 RID: 8195 RVA: 0x000A4D44 File Offset: 0x000A2F44
		internal static void smethod_0()
		{
			GClass110.smethod_6();
		}

		// Token: 0x06002004 RID: 8196 RVA: 0x000A4D58 File Offset: 0x000A2F58
		internal static void smethod_1()
		{
			GClass110.smethod_2();
		}

		// Token: 0x06002005 RID: 8197 RVA: 0x000A4D6C File Offset: 0x000A2F6C
		internal static void smethod_2()
		{
			GClass110.smethod_12();
		}

		// Token: 0x06002006 RID: 8198 RVA: 0x000A4D80 File Offset: 0x000A2F80
		internal static void smethod_3()
		{
			GClass110.smethod_4();
		}

		// Token: 0x06002007 RID: 8199 RVA: 0x000A4D94 File Offset: 0x000A2F94
		internal static void smethod_4()
		{
			GClass110.smethod_13();
		}

		// Token: 0x06002008 RID: 8200 RVA: 0x000A4DA8 File Offset: 0x000A2FA8
		internal static void smethod_5()
		{
			GClass110.smethod_7();
		}

		// Token: 0x06002009 RID: 8201 RVA: 0x000A4DBC File Offset: 0x000A2FBC
		internal static void smethod_6()
		{
			GClass110.smethod_9();
		}

		// Token: 0x0600200A RID: 8202 RVA: 0x000A4DD0 File Offset: 0x000A2FD0
		internal static void smethod_7()
		{
			GClass110.smethod_1();
		}

		// Token: 0x0600200B RID: 8203 RVA: 0x000A4DE4 File Offset: 0x000A2FE4
		internal static void smethod_8()
		{
			GClass110.smethod_3();
		}

		// Token: 0x0600200C RID: 8204 RVA: 0x000A4DF8 File Offset: 0x000A2FF8
		internal static void smethod_9()
		{
			GClass110.smethod_8();
		}

		// Token: 0x0600200D RID: 8205 RVA: 0x000A4E0C File Offset: 0x000A300C
		internal static void smethod_10()
		{
			GClass110.smethod_11();
		}

		// Token: 0x0600200E RID: 8206 RVA: 0x000A4E20 File Offset: 0x000A3020
		internal static void smethod_11()
		{
			GClass110.smethod_0();
		}

		// Token: 0x0600200F RID: 8207 RVA: 0x000A4E34 File Offset: 0x000A3034
		internal static void smethod_12()
		{
			GClass110.smethod_14();
		}

		// Token: 0x06002010 RID: 8208 RVA: 0x000A4E48 File Offset: 0x000A3048
		internal static void smethod_13()
		{
			GClass110.smethod_5();
		}

		// Token: 0x06002011 RID: 8209 RVA: 0x000A4E5C File Offset: 0x000A305C
		internal static void smethod_14()
		{
			GClass110.smethod_10();
		}
	}
}
