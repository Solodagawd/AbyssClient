﻿using System;

namespace ns498
{
	// Token: 0x02000361 RID: 865
	[Flags]
	public enum GEnum85
	{
		// Token: 0x04001BD4 RID: 7124
		flag_0 = 1,
		// Token: 0x04001BD5 RID: 7125
		flag_1 = 256,
		// Token: 0x04001BD6 RID: 7126
		flag_2 = 512
	}
}
