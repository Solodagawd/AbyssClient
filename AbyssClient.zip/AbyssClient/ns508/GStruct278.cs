﻿using System;
using System.Runtime.InteropServices;
using ns291;
using ns417;

namespace ns508
{
	// Token: 0x02000373 RID: 883
	[Attribute2(1331)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct278
	{
		// Token: 0x04001C2B RID: 7211
		public const int int_0 = 1331;

		// Token: 0x04001C2C RID: 7212
		public GEnum54 genum54_0;
	}
}
