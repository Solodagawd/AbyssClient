﻿using System;
using System.Runtime.InteropServices;
using ns417;
using ns54;

namespace ns228
{
	// Token: 0x020001A6 RID: 422
	[Attribute2(1108)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct124
	{
		// Token: 0x04000BBC RID: 3004
		public const int int_0 = 1108;

		// Token: 0x04000BBD RID: 3005
		public GStruct22 gstruct22_0;
	}
}
