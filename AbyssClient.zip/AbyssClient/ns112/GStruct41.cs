﻿using System;
using System.Runtime.InteropServices;
using ns291;
using ns417;

namespace ns112
{
	// Token: 0x02000096 RID: 150
	[Attribute2(3410)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct41
	{
		// Token: 0x040003B4 RID: 948
		public const int int_0 = 3410;

		// Token: 0x040003B5 RID: 949
		public GEnum54 genum54_0;
	}
}
