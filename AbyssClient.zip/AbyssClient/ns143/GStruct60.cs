﻿using System;
using System.Runtime.InteropServices;
using ns417;

namespace ns143
{
	// Token: 0x020000DC RID: 220
	[Attribute2(113)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct60
	{
		// Token: 0x0400054B RID: 1355
		public const int int_0 = 113;

		// Token: 0x0400054C RID: 1356
		public uint uint_0;

		// Token: 0x0400054D RID: 1357
		public uint uint_1;

		// Token: 0x0400054E RID: 1358
		public ushort ushort_0;

		// Token: 0x0400054F RID: 1359
		public ushort ushort_1;

		// Token: 0x04000550 RID: 1360
		public uint uint_2;
	}
}
