﻿using System;

namespace ns527
{
	// Token: 0x0200038E RID: 910
	public enum GEnum89
	{
		// Token: 0x04001CDD RID: 7389
		const_0 = -1,
		// Token: 0x04001CDE RID: 7390
		const_1,
		// Token: 0x04001CDF RID: 7391
		const_2,
		// Token: 0x04001CE0 RID: 7392
		const_3,
		// Token: 0x04001CE1 RID: 7393
		const_4,
		// Token: 0x04001CE2 RID: 7394
		const_5 = 20,
		// Token: 0x04001CE3 RID: 7395
		const_6,
		// Token: 0x04001CE4 RID: 7396
		const_7,
		// Token: 0x04001CE5 RID: 7397
		const_8,
		// Token: 0x04001CE6 RID: 7398
		const_9 = 40,
		// Token: 0x04001CE7 RID: 7399
		const_10 = 50,
		// Token: 0x04001CE8 RID: 7400
		const_11,
		// Token: 0x04001CE9 RID: 7401
		const_12 = 60,
		// Token: 0x04001CEA RID: 7402
		const_13,
		// Token: 0x04001CEB RID: 7403
		const_14 = 70,
		// Token: 0x04001CEC RID: 7404
		const_15,
		// Token: 0x04001CED RID: 7405
		const_16 = 80,
		// Token: 0x04001CEE RID: 7406
		const_17,
		// Token: 0x04001CEF RID: 7407
		const_18 = 90,
		// Token: 0x04001CF0 RID: 7408
		const_19,
		// Token: 0x04001CF1 RID: 7409
		const_20 = 100,
		// Token: 0x04001CF2 RID: 7410
		const_21
	}
}
