﻿using System;
using System.Runtime.InteropServices;
using ns417;
using ns496;

namespace ns2
{
	// Token: 0x02000003 RID: 3
	[Attribute2(1008)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct0
	{
		// Token: 0x04000016 RID: 22
		public const int int_0 = 1008;

		// Token: 0x04000017 RID: 23
		public GEnum84 genum84_0;

		// Token: 0x04000018 RID: 24
		public uint uint_0;
	}
}
