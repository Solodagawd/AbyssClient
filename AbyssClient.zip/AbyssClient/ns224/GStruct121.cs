﻿using System;
using System.Runtime.InteropServices;
using ns417;

namespace ns224
{
	// Token: 0x0200019E RID: 414
	[Attribute2(4012)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct121
	{
		// Token: 0x04000BA7 RID: 2983
		public const int int_0 = 4012;

		// Token: 0x04000BA8 RID: 2984
		public int int_1;
	}
}
