﻿using System;
using System.Runtime.InteropServices;
using ns151;
using ns169;
using ns417;

namespace ns303
{
	// Token: 0x0200026D RID: 621
	[Attribute2(3405)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct201
	{
		// Token: 0x040010DA RID: 4314
		public const int int_0 = 3405;

		// Token: 0x040010DB RID: 4315
		public GStruct66 gstruct66_0;

		// Token: 0x040010DC RID: 4316
		public GStruct78 gstruct78_0;
	}
}
