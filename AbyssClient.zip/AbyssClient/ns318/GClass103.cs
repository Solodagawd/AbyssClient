﻿using System;

namespace ns318
{
	// Token: 0x0200027C RID: 636
	public class GClass103
	{
		// Token: 0x04001157 RID: 4439
		public bool bool_0;
	}
}
