﻿using System;
using System.Runtime.InteropServices;
using ns417;

namespace ns141
{
	// Token: 0x020000DA RID: 218
	[Attribute2(503)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct59
	{
		// Token: 0x04000544 RID: 1348
		public const int int_0 = 503;

		// Token: 0x04000545 RID: 1349
		public ulong ulong_0;

		// Token: 0x04000546 RID: 1350
		public ulong ulong_1;

		// Token: 0x04000547 RID: 1351
		public ulong ulong_2;
	}
}
