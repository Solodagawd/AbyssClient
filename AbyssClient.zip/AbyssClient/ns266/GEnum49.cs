﻿using System;

namespace ns266
{
	// Token: 0x02000229 RID: 553
	public enum GEnum49
	{
		// Token: 0x04000EC9 RID: 3785
		const_0,
		// Token: 0x04000ECA RID: 3786
		const_1,
		// Token: 0x04000ECB RID: 3787
		const_2,
		// Token: 0x04000ECC RID: 3788
		const_3
	}
}
