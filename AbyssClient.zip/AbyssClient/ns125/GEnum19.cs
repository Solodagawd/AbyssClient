﻿using System;

namespace ns125
{
	// Token: 0x020000C2 RID: 194
	[Flags]
	public enum GEnum19
	{
		// Token: 0x040004D7 RID: 1239
		flag_0 = 0,
		// Token: 0x040004D8 RID: 1240
		flag_1 = 1,
		// Token: 0x040004D9 RID: 1241
		flag_2 = 2,
		// Token: 0x040004DA RID: 1242
		flag_3 = 4
	}
}
