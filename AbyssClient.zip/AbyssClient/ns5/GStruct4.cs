﻿using System;
using System.Runtime.InteropServices;
using ns417;
using ns54;

namespace ns5
{
	// Token: 0x0200000C RID: 12
	[Attribute2(343)]
	[StructLayout(LayoutKind.Sequential, Pack = 4)]
	public struct GStruct4
	{
		// Token: 0x0400004A RID: 74
		public const int int_0 = 343;

		// Token: 0x0400004B RID: 75
		public GStruct22 gstruct22_0;

		// Token: 0x0400004C RID: 76
		public int int_1;
	}
}
