﻿using System;
using System.Runtime.InteropServices;
using ns417;

namespace ns154
{
	// Token: 0x02000103 RID: 259
	[Attribute2(1329)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct68
	{
		// Token: 0x0400066C RID: 1644
		public const int int_0 = 1329;

		// Token: 0x0400066D RID: 1645
		public double double_0;

		// Token: 0x0400066E RID: 1646
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_0;
	}
}
