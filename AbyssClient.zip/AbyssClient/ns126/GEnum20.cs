﻿using System;

namespace ns126
{
	// Token: 0x020000C3 RID: 195
	[Flags]
	public enum GEnum20
	{
		// Token: 0x040004DC RID: 1244
		flag_0 = 0,
		// Token: 0x040004DD RID: 1245
		flag_1 = 1,
		// Token: 0x040004DE RID: 1246
		flag_2 = 2,
		// Token: 0x040004DF RID: 1247
		flag_3 = 4,
		// Token: 0x040004E0 RID: 1248
		flag_4 = 8,
		// Token: 0x040004E1 RID: 1249
		flag_5 = 16,
		// Token: 0x040004E2 RID: 1250
		flag_6 = 32,
		// Token: 0x040004E3 RID: 1251
		flag_7 = 64,
		// Token: 0x040004E4 RID: 1252
		flag_8 = 128,
		// Token: 0x040004E5 RID: 1253
		flag_9 = 256,
		// Token: 0x040004E6 RID: 1254
		flag_10 = 512,
		// Token: 0x040004E7 RID: 1255
		flag_11 = 1024,
		// Token: 0x040004E8 RID: 1256
		flag_12 = 2048,
		// Token: 0x040004E9 RID: 1257
		flag_13 = 4096,
		// Token: 0x040004EA RID: 1258
		flag_14 = 8192,
		// Token: 0x040004EB RID: 1259
		flag_15 = 16384,
		// Token: 0x040004EC RID: 1260
		flag_16 = 32768,
		// Token: 0x040004ED RID: 1261
		flag_17 = 65536,
		// Token: 0x040004EE RID: 1262
		flag_18 = 131072,
		// Token: 0x040004EF RID: 1263
		flag_19 = 262144
	}
}
