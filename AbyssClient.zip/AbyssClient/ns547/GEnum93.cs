﻿using System;

namespace ns547
{
	// Token: 0x020003A4 RID: 932
	public enum GEnum93
	{
		// Token: 0x04001D6B RID: 7531
		const_0,
		// Token: 0x04001D6C RID: 7532
		const_1,
		// Token: 0x04001D6D RID: 7533
		const_2,
		// Token: 0x04001D6E RID: 7534
		const_3,
		// Token: 0x04001D6F RID: 7535
		const_4,
		// Token: 0x04001D70 RID: 7536
		const_5,
		// Token: 0x04001D71 RID: 7537
		const_6,
		// Token: 0x04001D72 RID: 7538
		const_7,
		// Token: 0x04001D73 RID: 7539
		const_8,
		// Token: 0x04001D74 RID: 7540
		const_9,
		// Token: 0x04001D75 RID: 7541
		const_10,
		// Token: 0x04001D76 RID: 7542
		const_11,
		// Token: 0x04001D77 RID: 7543
		const_12,
		// Token: 0x04001D78 RID: 7544
		const_13,
		// Token: 0x04001D79 RID: 7545
		const_14,
		// Token: 0x04001D7A RID: 7546
		const_15,
		// Token: 0x04001D7B RID: 7547
		const_16,
		// Token: 0x04001D7C RID: 7548
		const_17,
		// Token: 0x04001D7D RID: 7549
		const_18
	}
}
