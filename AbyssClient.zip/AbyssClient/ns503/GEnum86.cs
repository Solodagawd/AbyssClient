﻿using System;

namespace ns503
{
	// Token: 0x0200036B RID: 875
	public enum GEnum86
	{
		// Token: 0x04001BEC RID: 7148
		const_0,
		// Token: 0x04001BED RID: 7149
		const_1,
		// Token: 0x04001BEE RID: 7150
		const_2
	}
}
