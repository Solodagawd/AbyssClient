﻿using System;
using System.Runtime.InteropServices;
using ns311;
using ns417;
using ns54;

namespace ns305
{
	// Token: 0x0200026F RID: 623
	[Attribute2(203)]
	[StructLayout(LayoutKind.Sequential, Pack = 4)]
	public struct GStruct203
	{
		// Token: 0x040010E7 RID: 4327
		public const int int_0 = 203;

		// Token: 0x040010E8 RID: 4328
		public GStruct22 gstruct22_0;

		// Token: 0x040010E9 RID: 4329
		public GEnum58 genum58_0;
	}
}
