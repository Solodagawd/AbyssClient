﻿using System;
using System.Runtime.InteropServices;
using ns417;

namespace ns407
{
	// Token: 0x0200030E RID: 782
	[Attribute2(504)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct252
	{
		// Token: 0x0400190E RID: 6414
		public const int int_0 = 504;

		// Token: 0x0400190F RID: 6415
		public ulong ulong_0;

		// Token: 0x04001910 RID: 6416
		public uint uint_0;

		// Token: 0x04001911 RID: 6417
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_0;

		// Token: 0x04001912 RID: 6418
		public uint uint_1;
	}
}
