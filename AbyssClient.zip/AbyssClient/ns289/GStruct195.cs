﻿using System;
using System.Runtime.InteropServices;
using ns417;

namespace ns289
{
	// Token: 0x02000251 RID: 593
	[Attribute2(507)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct195
	{
		// Token: 0x04000FB6 RID: 4022
		public const int int_0 = 507;

		// Token: 0x04000FB7 RID: 4023
		public ulong ulong_0;

		// Token: 0x04000FB8 RID: 4024
		public ulong ulong_1;

		// Token: 0x04000FB9 RID: 4025
		public byte byte_0;

		// Token: 0x04000FBA RID: 4026
		public uint uint_0;
	}
}
