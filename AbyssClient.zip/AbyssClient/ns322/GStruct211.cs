﻿using System;
using System.Runtime.InteropServices;
using ns331;
using ns417;

namespace ns322
{
	// Token: 0x02000281 RID: 641
	[Attribute2(502)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct211
	{
		// Token: 0x04001194 RID: 4500
		public const int int_0 = 502;

		// Token: 0x04001195 RID: 4501
		public uint uint_0;

		// Token: 0x04001196 RID: 4502
		public uint uint_1;

		// Token: 0x04001197 RID: 4503
		public uint uint_2;

		// Token: 0x04001198 RID: 4504
		public uint uint_3;

		// Token: 0x04001199 RID: 4505
		public uint uint_4;

		// Token: 0x0400119A RID: 4506
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_0;

		// Token: 0x0400119B RID: 4507
		public GStruct216 gstruct216_0;
	}
}
