﻿using System;
using System.Runtime.InteropServices;

namespace ns304
{
	// Token: 0x0200026E RID: 622
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct202
	{
		// Token: 0x040010DD RID: 4317
		public float float_0;

		// Token: 0x040010DE RID: 4318
		public float float_1;

		// Token: 0x040010DF RID: 4319
		public float float_2;

		// Token: 0x040010E0 RID: 4320
		public float float_3;

		// Token: 0x040010E1 RID: 4321
		public float float_4;

		// Token: 0x040010E2 RID: 4322
		public float float_5;

		// Token: 0x040010E3 RID: 4323
		public float float_6;

		// Token: 0x040010E4 RID: 4324
		public float float_7;

		// Token: 0x040010E5 RID: 4325
		public float float_8;

		// Token: 0x040010E6 RID: 4326
		public float float_9;
	}
}
