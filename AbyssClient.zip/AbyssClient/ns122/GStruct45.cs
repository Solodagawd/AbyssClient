﻿using System;
using ns417;

namespace ns122
{
	// Token: 0x020000BF RID: 191
	[Attribute2(4001)]
	public struct GStruct45
	{
		// Token: 0x040004CD RID: 1229
		public const int int_0 = 4001;
	}
}
