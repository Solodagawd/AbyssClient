﻿using System;
using System.Runtime.InteropServices;
using ns333;
using ns54;

namespace ns225
{
	// Token: 0x0200019F RID: 415
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct122
	{
		// Token: 0x04000BA9 RID: 2985
		public GStruct217 gstruct217_0;

		// Token: 0x04000BAA RID: 2986
		public uint uint_0;

		// Token: 0x04000BAB RID: 2987
		public ushort ushort_0;

		// Token: 0x04000BAC RID: 2988
		public ushort ushort_1;

		// Token: 0x04000BAD RID: 2989
		public GStruct22 gstruct22_0;
	}
}
