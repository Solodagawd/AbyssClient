﻿using System;

namespace ns120
{
	// Token: 0x020000BD RID: 189
	public enum GEnum18
	{
		// Token: 0x040004C5 RID: 1221
		const_0,
		// Token: 0x040004C6 RID: 1222
		const_1,
		// Token: 0x040004C7 RID: 1223
		const_2,
		// Token: 0x040004C8 RID: 1224
		const_3,
		// Token: 0x040004C9 RID: 1225
		const_4,
		// Token: 0x040004CA RID: 1226
		const_5,
		// Token: 0x040004CB RID: 1227
		const_6,
		// Token: 0x040004CC RID: 1228
		const_7
	}
}
