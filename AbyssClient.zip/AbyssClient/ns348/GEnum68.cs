﻿using System;

namespace ns348
{
	// Token: 0x020002B5 RID: 693
	public enum GEnum68
	{
		// Token: 0x0400128A RID: 4746
		const_0,
		// Token: 0x0400128B RID: 4747
		const_1,
		// Token: 0x0400128C RID: 4748
		const_2,
		// Token: 0x0400128D RID: 4749
		const_3
	}
}
