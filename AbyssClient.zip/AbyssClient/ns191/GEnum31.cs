﻿using System;

namespace ns191
{
	// Token: 0x02000137 RID: 311
	public enum GEnum31
	{
		// Token: 0x040007D8 RID: 2008
		const_0,
		// Token: 0x040007D9 RID: 2009
		const_1,
		// Token: 0x040007DA RID: 2010
		const_2,
		// Token: 0x040007DB RID: 2011
		const_3,
		// Token: 0x040007DC RID: 2012
		const_4,
		// Token: 0x040007DD RID: 2013
		const_5,
		// Token: 0x040007DE RID: 2014
		const_6
	}
}
