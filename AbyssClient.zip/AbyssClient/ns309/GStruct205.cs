﻿using System;
using System.Runtime.InteropServices;

namespace ns309
{
	// Token: 0x02000273 RID: 627
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct205
	{
		// Token: 0x0400110B RID: 4363
		public IntPtr intptr_0;

		// Token: 0x0400110C RID: 4364
		public int int_0;
	}
}
