﻿using System;
using System.Runtime.InteropServices;
using ns417;

namespace ns183
{
	// Token: 0x02000127 RID: 295
	[Attribute2(341)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct85
	{
		// Token: 0x04000749 RID: 1865
		public const int int_0 = 341;

		// Token: 0x0400074A RID: 1866
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_0;
	}
}
