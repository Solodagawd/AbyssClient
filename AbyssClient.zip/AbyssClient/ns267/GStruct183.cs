﻿using System;
using System.Runtime.InteropServices;
using ns417;

namespace ns267
{
	// Token: 0x0200022A RID: 554
	[Attribute2(331)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct183
	{
		// Token: 0x04000ECD RID: 3789
		public const int int_0 = 331;

		// Token: 0x04000ECE RID: 3790
		public byte byte_0;
	}
}
