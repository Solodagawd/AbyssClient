﻿using System;
using System.Runtime.InteropServices;
using ns169;
using ns291;
using ns417;

namespace ns187
{
	// Token: 0x0200012E RID: 302
	[Attribute2(1311)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct87
	{
		// Token: 0x0400078C RID: 1932
		public const int int_0 = 1311;

		// Token: 0x0400078D RID: 1933
		public GEnum54 genum54_0;

		// Token: 0x0400078E RID: 1934
		public GStruct78 gstruct78_0;
	}
}
