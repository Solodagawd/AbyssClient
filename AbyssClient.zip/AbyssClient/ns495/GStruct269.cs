﻿using System;
using System.Runtime.InteropServices;
using ns169;
using ns291;
using ns417;

namespace ns495
{
	// Token: 0x02000359 RID: 857
	[Attribute2(3407)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct269
	{
		// Token: 0x04001BA7 RID: 7079
		public const int int_0 = 3407;

		// Token: 0x04001BA8 RID: 7080
		public GStruct78 gstruct78_0;

		// Token: 0x04001BA9 RID: 7081
		public GEnum54 genum54_0;

		// Token: 0x04001BAA RID: 7082
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_0;
	}
}
