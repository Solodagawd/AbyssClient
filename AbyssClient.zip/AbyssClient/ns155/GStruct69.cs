﻿using System;
using System.Runtime.InteropServices;
using ns169;
using ns291;
using ns417;

namespace ns155
{
	// Token: 0x02000104 RID: 260
	[Attribute2(1324)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct69
	{
		// Token: 0x0400066F RID: 1647
		public const int int_0 = 1324;

		// Token: 0x04000670 RID: 1648
		public GEnum54 genum54_0;

		// Token: 0x04000671 RID: 1649
		public GStruct78 gstruct78_0;
	}
}
