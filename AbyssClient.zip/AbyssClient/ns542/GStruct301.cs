﻿using System;
using System.Runtime.InteropServices;
using ns417;
using ns54;

namespace ns542
{
	// Token: 0x0200039E RID: 926
	[Attribute2(1202)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct301
	{
		// Token: 0x04001D42 RID: 7490
		public const int int_0 = 1202;

		// Token: 0x04001D43 RID: 7491
		public GStruct22 gstruct22_0;
	}
}
