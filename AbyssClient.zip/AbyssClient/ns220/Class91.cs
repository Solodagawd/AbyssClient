﻿using System;
using System.Runtime.InteropServices;

namespace ns220
{
	// Token: 0x0200019A RID: 410
	[StructLayout(LayoutKind.Sequential)]
	internal class Class91
	{
		// Token: 0x04000B92 RID: 2962
		public const byte byte_0 = 1;

		// Token: 0x04000B93 RID: 2963
		public const byte byte_1 = 2;

		// Token: 0x04000B94 RID: 2964
		public IntPtr intptr_0;

		// Token: 0x04000B95 RID: 2965
		public byte byte_2;

		// Token: 0x04000B96 RID: 2966
		public int int_0;
	}
}
