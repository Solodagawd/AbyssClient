﻿using System;
using System.Runtime.InteropServices;
using ns118;
using ns417;

namespace ns147
{
	// Token: 0x020000E0 RID: 224
	[Attribute2(4508)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct63
	{
		// Token: 0x04000584 RID: 1412
		public const int int_0 = 4508;

		// Token: 0x04000585 RID: 1413
		public GStruct43 gstruct43_0;

		// Token: 0x04000586 RID: 1414
		public string string_0;
	}
}
