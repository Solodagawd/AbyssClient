﻿using System;
using System.Runtime.InteropServices;
using ns417;

namespace ns272
{
	// Token: 0x0200022F RID: 559
	[Attribute2(512)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct187
	{
		// Token: 0x04000ED9 RID: 3801
		public const int int_0 = 512;

		// Token: 0x04000EDA RID: 3802
		public ulong ulong_0;

		// Token: 0x04000EDB RID: 3803
		public ulong ulong_1;

		// Token: 0x04000EDC RID: 3804
		public byte byte_0;
	}
}
