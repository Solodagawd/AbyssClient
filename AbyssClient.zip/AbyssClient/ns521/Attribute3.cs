﻿using System;
using System.Runtime.CompilerServices;

namespace ns521
{
	// Token: 0x02000388 RID: 904
	[CompilerGenerated]
	[Attribute3]
	internal sealed class Attribute3 : Attribute
	{
	}
}
