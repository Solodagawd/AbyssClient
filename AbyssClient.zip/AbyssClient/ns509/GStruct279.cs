﻿using System;
using System.Runtime.InteropServices;
using ns151;
using ns291;
using ns417;

namespace ns509
{
	// Token: 0x02000374 RID: 884
	[Attribute2(4624)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct279
	{
		// Token: 0x04001C2D RID: 7213
		public const int int_0 = 4624;

		// Token: 0x04001C2E RID: 7214
		public GEnum54 genum54_0;

		// Token: 0x04001C2F RID: 7215
		public GStruct66 gstruct66_0;
	}
}
