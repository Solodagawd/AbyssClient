﻿using System;

namespace ns391
{
	// Token: 0x020002F4 RID: 756
	public enum GEnum74
	{
		// Token: 0x040018C5 RID: 6341
		const_0,
		// Token: 0x040018C6 RID: 6342
		const_1,
		// Token: 0x040018C7 RID: 6343
		const_2,
		// Token: 0x040018C8 RID: 6344
		const_3,
		// Token: 0x040018C9 RID: 6345
		const_4,
		// Token: 0x040018CA RID: 6346
		const_5,
		// Token: 0x040018CB RID: 6347
		const_6,
		// Token: 0x040018CC RID: 6348
		const_7,
		// Token: 0x040018CD RID: 6349
		const_8,
		// Token: 0x040018CE RID: 6350
		const_9,
		// Token: 0x040018CF RID: 6351
		const_10,
		// Token: 0x040018D0 RID: 6352
		const_11,
		// Token: 0x040018D1 RID: 6353
		const_12,
		// Token: 0x040018D2 RID: 6354
		const_13,
		// Token: 0x040018D3 RID: 6355
		const_14,
		// Token: 0x040018D4 RID: 6356
		const_15,
		// Token: 0x040018D5 RID: 6357
		const_16 = 1000
	}
}
