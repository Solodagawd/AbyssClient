﻿using System;
using System.Runtime.InteropServices;
using ns417;

namespace ns534
{
	// Token: 0x02000395 RID: 917
	[Attribute2(164)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct295
	{
		// Token: 0x04001D0D RID: 7437
		public const int int_0 = 164;

		// Token: 0x04001D0E RID: 7438
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
		public string string_0;
	}
}
