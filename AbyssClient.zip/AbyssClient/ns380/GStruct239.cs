﻿using System;
using System.Runtime.InteropServices;
using ns417;
using ns54;

namespace ns380
{
	// Token: 0x020002E6 RID: 742
	[Attribute2(333)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct239
	{
		// Token: 0x0400185A RID: 6234
		public const int int_0 = 333;

		// Token: 0x0400185B RID: 6235
		public GStruct22 gstruct22_0;

		// Token: 0x0400185C RID: 6236
		public GStruct22 gstruct22_1;
	}
}
