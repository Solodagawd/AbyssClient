﻿using System;
using System.Runtime.InteropServices;
using ns151;
using ns417;
using ns54;

namespace ns500
{
	// Token: 0x02000363 RID: 867
	[Attribute2(336)]
	[StructLayout(LayoutKind.Sequential, Pack = 4)]
	public struct GStruct273
	{
		// Token: 0x04001BDC RID: 7132
		public const int int_0 = 336;

		// Token: 0x04001BDD RID: 7133
		public GStruct22 gstruct22_0;

		// Token: 0x04001BDE RID: 7134
		public GStruct66 gstruct66_0;
	}
}
