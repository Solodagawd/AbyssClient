﻿using System;
using System.Runtime.InteropServices;
using ns417;

namespace ns150
{
	// Token: 0x020000FC RID: 252
	[Attribute2(117)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct65
	{
		// Token: 0x04000652 RID: 1618
		public const int int_0 = 117;

		// Token: 0x04000653 RID: 1619
		public byte byte_0;
	}
}
