﻿using System;
using System.Runtime.InteropServices;
using ns417;
using ns554;

namespace ns497
{
	// Token: 0x02000360 RID: 864
	[Attribute2(1106)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct271
	{
		// Token: 0x04001BCC RID: 7116
		public const int int_0 = 1106;

		// Token: 0x04001BCD RID: 7117
		public byte byte_0;

		// Token: 0x04001BCE RID: 7118
		public GStruct305 gstruct305_0;

		// Token: 0x04001BCF RID: 7119
		public int int_1;

		// Token: 0x04001BD0 RID: 7120
		public byte byte_1;

		// Token: 0x04001BD1 RID: 7121
		public int int_2;

		// Token: 0x04001BD2 RID: 7122
		public int int_3;
	}
}
