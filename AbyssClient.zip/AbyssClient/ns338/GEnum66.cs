﻿using System;

namespace ns338
{
	// Token: 0x020002A6 RID: 678
	public enum GEnum66
	{
		// Token: 0x0400123C RID: 4668
		const_0,
		// Token: 0x0400123D RID: 4669
		const_1 = 0,
		// Token: 0x0400123E RID: 4670
		const_2,
		// Token: 0x0400123F RID: 4671
		const_3,
		// Token: 0x04001240 RID: 4672
		const_4,
		// Token: 0x04001241 RID: 4673
		const_5,
		// Token: 0x04001242 RID: 4674
		const_6,
		// Token: 0x04001243 RID: 4675
		const_7,
		// Token: 0x04001244 RID: 4676
		const_8,
		// Token: 0x04001245 RID: 4677
		const_9,
		// Token: 0x04001246 RID: 4678
		const_10,
		// Token: 0x04001247 RID: 4679
		const_11,
		// Token: 0x04001248 RID: 4680
		const_12,
		// Token: 0x04001249 RID: 4681
		const_13,
		// Token: 0x0400124A RID: 4682
		const_14,
		// Token: 0x0400124B RID: 4683
		const_15,
		// Token: 0x0400124C RID: 4684
		const_16,
		// Token: 0x0400124D RID: 4685
		const_17
	}
}
