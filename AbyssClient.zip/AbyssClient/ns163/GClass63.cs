﻿using System;
using ns75;

namespace ns163
{
	// Token: 0x0200010C RID: 268
	public class GClass63
	{
		// Token: 0x0600086B RID: 2155 RVA: 0x00022398 File Offset: 0x00020598
		internal static void smethod_0(GClass40 gclass40_0)
		{
			GClass63.smethod_2(gclass40_0);
		}

		// Token: 0x0600086C RID: 2156 RVA: 0x000223AC File Offset: 0x000205AC
		internal static void smethod_1(GClass40 gclass40_0)
		{
			GClass63.smethod_0(gclass40_0);
		}

		// Token: 0x0600086F RID: 2159 RVA: 0x000223C0 File Offset: 0x000205C0
		internal static void smethod_2(GClass40 gclass40_0)
		{
			if (gclass40_0 != null)
			{
				gclass40_0.bool_0 = true;
				gclass40_0.bool_1 = true;
				gclass40_0.bool_2 = false;
				gclass40_0.bool_3 = true;
				gclass40_0.bool_4 = false;
				gclass40_0.bool_5 = false;
				gclass40_0.bool_6 = false;
				gclass40_0.bool_7 = true;
				gclass40_0.bool_8 = true;
				gclass40_0.bool_9 = false;
				gclass40_0.bool_10 = true;
				gclass40_0.bool_11 = false;
				gclass40_0.bool_12 = true;
				gclass40_0.bool_13 = true;
				gclass40_0.bool_14 = false;
				gclass40_0.bool_15 = false;
				gclass40_0.bool_16 = true;
				gclass40_0.bool_17 = false;
				gclass40_0.bool_18 = false;
				gclass40_0.bool_19 = true;
				gclass40_0.bool_20 = false;
				gclass40_0.bool_21 = false;
				gclass40_0.bool_22 = false;
				gclass40_0.bool_23 = true;
				gclass40_0.bool_24 = true;
				gclass40_0.bool_25 = true;
				gclass40_0.bool_26 = false;
				gclass40_0.bool_27 = true;
				gclass40_0.bool_28 = true;
				gclass40_0.bool_29 = true;
				gclass40_0.bool_30 = false;
				gclass40_0.bool_31 = false;
				gclass40_0.bool_32 = true;
				gclass40_0.bool_33 = true;
				gclass40_0.bool_34 = true;
				gclass40_0.bool_35 = true;
				gclass40_0.bool_36 = true;
				gclass40_0.bool_37 = false;
				gclass40_0.bool_38 = false;
				gclass40_0.bool_39 = false;
				gclass40_0.bool_40 = false;
				gclass40_0.bool_41 = true;
				gclass40_0.bool_42 = false;
				gclass40_0.bool_43 = true;
				gclass40_0.bool_44 = false;
				gclass40_0.bool_45 = false;
				gclass40_0.bool_46 = true;
				gclass40_0.bool_47 = false;
				gclass40_0.bool_48 = true;
				gclass40_0.bool_49 = false;
				gclass40_0.bool_50 = false;
				gclass40_0.bool_51 = true;
				gclass40_0.bool_52 = false;
				gclass40_0.bool_53 = false;
				gclass40_0.bool_54 = true;
				gclass40_0.bool_55 = false;
				gclass40_0.bool_56 = false;
				gclass40_0.bool_57 = true;
				gclass40_0.bool_58 = false;
				gclass40_0.int_0 = 500;
				gclass40_0.bool_59 = true;
				gclass40_0.bool_60 = false;
				gclass40_0.bool_61 = false;
				gclass40_0.bool_62 = true;
				gclass40_0.bool_63 = false;
				gclass40_0.bool_64 = true;
				gclass40_0.bool_65 = false;
				gclass40_0.bool_66 = false;
				gclass40_0.bool_67 = true;
				gclass40_0.bool_68 = false;
				gclass40_0.bool_69 = false;
				gclass40_0.bool_70 = true;
				gclass40_0.bool_71 = false;
				gclass40_0.bool_72 = false;
				gclass40_0.bool_73 = true;
				gclass40_0.bool_74 = false;
				gclass40_0.bool_75 = true;
				gclass40_0.bool_76 = false;
				gclass40_0.bool_77 = false;
				gclass40_0.bool_78 = true;
				gclass40_0.bool_79 = false;
				gclass40_0.bool_80 = true;
				gclass40_0.bool_81 = false;
				gclass40_0.bool_82 = false;
				gclass40_0.bool_83 = true;
				gclass40_0.bool_84 = false;
				gclass40_0.bool_85 = true;
				gclass40_0.bool_86 = false;
				gclass40_0.bool_87 = false;
				gclass40_0.bool_88 = true;
				gclass40_0.bool_89 = false;
				gclass40_0.bool_90 = true;
				gclass40_0.bool_91 = false;
				gclass40_0.bool_92 = false;
				gclass40_0.bool_93 = true;
				gclass40_0.bool_94 = false;
				gclass40_0.bool_95 = true;
				gclass40_0.bool_96 = false;
				gclass40_0.bool_97 = false;
				gclass40_0.bool_98 = true;
				gclass40_0.bool_99 = false;
				gclass40_0.bool_100 = true;
				gclass40_0.bool_101 = false;
				gclass40_0.bool_102 = false;
				gclass40_0.bool_103 = true;
				gclass40_0.bool_104 = false;
				gclass40_0.bool_105 = true;
				gclass40_0.bool_106 = false;
				gclass40_0.bool_107 = false;
				gclass40_0.bool_108 = true;
				gclass40_0.bool_109 = false;
				gclass40_0.int_1 = 3000;
				gclass40_0.bool_110 = true;
				gclass40_0.bool_111 = true;
				gclass40_0.bool_112 = GClass63.bool_0;
				gclass40_0.bool_113 = false;
			}
		}

		// Token: 0x04000697 RID: 1687
		internal static bool bool_0;
	}
}
