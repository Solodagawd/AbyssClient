﻿using System;
using System.Runtime.InteropServices;
using ns118;
using ns417;

namespace ns351
{
	// Token: 0x020002B8 RID: 696
	[Attribute2(4525)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct228
	{
		// Token: 0x04001293 RID: 4755
		public const int int_0 = 4525;

		// Token: 0x04001294 RID: 4756
		public GStruct43 gstruct43_0;

		// Token: 0x04001295 RID: 4757
		public string string_0;
	}
}
