﻿using System;
using System.Runtime.InteropServices;
using ns291;
using ns417;
using ns54;

namespace ns529
{
	// Token: 0x02000390 RID: 912
	[Attribute2(211)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct291
	{
		// Token: 0x04001CF4 RID: 7412
		public const int int_0 = 211;

		// Token: 0x04001CF5 RID: 7413
		public GEnum54 genum54_0;

		// Token: 0x04001CF6 RID: 7414
		public int int_1;

		// Token: 0x04001CF7 RID: 7415
		public int int_2;

		// Token: 0x04001CF8 RID: 7416
		public int int_3;

		// Token: 0x04001CF9 RID: 7417
		public GStruct22 gstruct22_0;
	}
}
