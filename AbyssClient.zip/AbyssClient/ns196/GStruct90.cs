﻿using System;
using System.Runtime.InteropServices;
using ns378;
using ns417;

namespace ns196
{
	// Token: 0x0200013D RID: 317
	[Attribute2(304)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct90
	{
		// Token: 0x040008AF RID: 2223
		public const int int_0 = 304;

		// Token: 0x040008B0 RID: 2224
		public ulong ulong_0;

		// Token: 0x040008B1 RID: 2225
		public GEnum72 genum72_0;
	}
}
