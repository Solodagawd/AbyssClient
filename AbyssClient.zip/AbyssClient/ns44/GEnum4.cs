﻿using System;

namespace ns44
{
	// Token: 0x02000035 RID: 53
	public enum GEnum4
	{
		// Token: 0x040000C1 RID: 193
		const_0,
		// Token: 0x040000C2 RID: 194
		const_1,
		// Token: 0x040000C3 RID: 195
		const_2,
		// Token: 0x040000C4 RID: 196
		const_3,
		// Token: 0x040000C5 RID: 197
		const_4,
		// Token: 0x040000C6 RID: 198
		const_5,
		// Token: 0x040000C7 RID: 199
		const_6,
		// Token: 0x040000C8 RID: 200
		const_7,
		// Token: 0x040000C9 RID: 201
		const_8,
		// Token: 0x040000CA RID: 202
		const_9,
		// Token: 0x040000CB RID: 203
		const_10,
		// Token: 0x040000CC RID: 204
		const_11,
		// Token: 0x040000CD RID: 205
		const_12,
		// Token: 0x040000CE RID: 206
		const_13,
		// Token: 0x040000CF RID: 207
		const_14
	}
}
