﻿using System;
using System.Runtime.InteropServices;
using ns169;
using ns291;
using ns417;

namespace ns517
{
	// Token: 0x02000384 RID: 900
	[Attribute2(3413)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct287
	{
		// Token: 0x04001CAB RID: 7339
		public const int int_0 = 3413;

		// Token: 0x04001CAC RID: 7340
		public GEnum54 genum54_0;

		// Token: 0x04001CAD RID: 7341
		public GStruct78 gstruct78_0;

		// Token: 0x04001CAE RID: 7342
		public GStruct78 gstruct78_1;
	}
}
