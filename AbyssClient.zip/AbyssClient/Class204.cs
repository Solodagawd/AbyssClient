﻿using System;

// Token: 0x02000357 RID: 855
internal class Class204
{
}
