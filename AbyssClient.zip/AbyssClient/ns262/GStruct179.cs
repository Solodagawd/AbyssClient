﻿using System;
using System.Runtime.InteropServices;
using ns118;
using ns417;

namespace ns262
{
	// Token: 0x02000225 RID: 549
	[Attribute2(4523)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct179
	{
		// Token: 0x04000EB7 RID: 3767
		public const int int_0 = 4523;

		// Token: 0x04000EB8 RID: 3768
		public GStruct43 gstruct43_0;

		// Token: 0x04000EB9 RID: 3769
		public string string_0;
	}
}
