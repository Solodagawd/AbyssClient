﻿using System;

namespace ns530
{
	// Token: 0x02000391 RID: 913
	public enum GEnum90
	{
		// Token: 0x04001CFB RID: 7419
		const_0,
		// Token: 0x04001CFC RID: 7420
		const_1,
		// Token: 0x04001CFD RID: 7421
		const_2,
		// Token: 0x04001CFE RID: 7422
		const_3,
		// Token: 0x04001CFF RID: 7423
		const_4,
		// Token: 0x04001D00 RID: 7424
		const_5,
		// Token: 0x04001D01 RID: 7425
		const_6
	}
}
