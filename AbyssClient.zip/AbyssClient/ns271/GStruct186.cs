﻿using System;
using System.Runtime.InteropServices;
using ns118;
using ns417;

namespace ns271
{
	// Token: 0x0200022E RID: 558
	[Attribute2(4524)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct186
	{
		// Token: 0x04000ED6 RID: 3798
		public const int int_0 = 4524;

		// Token: 0x04000ED7 RID: 3799
		public GStruct43 gstruct43_0;

		// Token: 0x04000ED8 RID: 3800
		public string string_0;
	}
}
