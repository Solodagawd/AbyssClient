﻿using System;

namespace ns195
{
	// Token: 0x0200013C RID: 316
	public enum GEnum33
	{
		// Token: 0x040007EA RID: 2026
		const_0,
		// Token: 0x040007EB RID: 2027
		const_1,
		// Token: 0x040007EC RID: 2028
		const_2,
		// Token: 0x040007ED RID: 2029
		const_3,
		// Token: 0x040007EE RID: 2030
		const_4,
		// Token: 0x040007EF RID: 2031
		const_5,
		// Token: 0x040007F0 RID: 2032
		const_6,
		// Token: 0x040007F1 RID: 2033
		const_7,
		// Token: 0x040007F2 RID: 2034
		const_8,
		// Token: 0x040007F3 RID: 2035
		const_9,
		// Token: 0x040007F4 RID: 2036
		const_10,
		// Token: 0x040007F5 RID: 2037
		const_11,
		// Token: 0x040007F6 RID: 2038
		const_12,
		// Token: 0x040007F7 RID: 2039
		const_13,
		// Token: 0x040007F8 RID: 2040
		const_14,
		// Token: 0x040007F9 RID: 2041
		const_15,
		// Token: 0x040007FA RID: 2042
		const_16,
		// Token: 0x040007FB RID: 2043
		const_17,
		// Token: 0x040007FC RID: 2044
		const_18,
		// Token: 0x040007FD RID: 2045
		const_19,
		// Token: 0x040007FE RID: 2046
		const_20,
		// Token: 0x040007FF RID: 2047
		const_21,
		// Token: 0x04000800 RID: 2048
		const_22,
		// Token: 0x04000801 RID: 2049
		const_23,
		// Token: 0x04000802 RID: 2050
		const_24,
		// Token: 0x04000803 RID: 2051
		const_25,
		// Token: 0x04000804 RID: 2052
		const_26,
		// Token: 0x04000805 RID: 2053
		const_27,
		// Token: 0x04000806 RID: 2054
		const_28,
		// Token: 0x04000807 RID: 2055
		const_29,
		// Token: 0x04000808 RID: 2056
		const_30,
		// Token: 0x04000809 RID: 2057
		const_31,
		// Token: 0x0400080A RID: 2058
		const_32,
		// Token: 0x0400080B RID: 2059
		const_33,
		// Token: 0x0400080C RID: 2060
		const_34,
		// Token: 0x0400080D RID: 2061
		const_35,
		// Token: 0x0400080E RID: 2062
		const_36,
		// Token: 0x0400080F RID: 2063
		const_37,
		// Token: 0x04000810 RID: 2064
		const_38,
		// Token: 0x04000811 RID: 2065
		const_39,
		// Token: 0x04000812 RID: 2066
		const_40,
		// Token: 0x04000813 RID: 2067
		const_41,
		// Token: 0x04000814 RID: 2068
		const_42,
		// Token: 0x04000815 RID: 2069
		const_43,
		// Token: 0x04000816 RID: 2070
		const_44,
		// Token: 0x04000817 RID: 2071
		const_45,
		// Token: 0x04000818 RID: 2072
		const_46,
		// Token: 0x04000819 RID: 2073
		const_47,
		// Token: 0x0400081A RID: 2074
		const_48,
		// Token: 0x0400081B RID: 2075
		const_49,
		// Token: 0x0400081C RID: 2076
		const_50,
		// Token: 0x0400081D RID: 2077
		const_51,
		// Token: 0x0400081E RID: 2078
		const_52,
		// Token: 0x0400081F RID: 2079
		const_53,
		// Token: 0x04000820 RID: 2080
		const_54,
		// Token: 0x04000821 RID: 2081
		const_55,
		// Token: 0x04000822 RID: 2082
		const_56,
		// Token: 0x04000823 RID: 2083
		const_57,
		// Token: 0x04000824 RID: 2084
		const_58,
		// Token: 0x04000825 RID: 2085
		const_59,
		// Token: 0x04000826 RID: 2086
		const_60,
		// Token: 0x04000827 RID: 2087
		const_61,
		// Token: 0x04000828 RID: 2088
		const_62,
		// Token: 0x04000829 RID: 2089
		const_63,
		// Token: 0x0400082A RID: 2090
		const_64,
		// Token: 0x0400082B RID: 2091
		const_65,
		// Token: 0x0400082C RID: 2092
		const_66,
		// Token: 0x0400082D RID: 2093
		const_67,
		// Token: 0x0400082E RID: 2094
		const_68,
		// Token: 0x0400082F RID: 2095
		const_69,
		// Token: 0x04000830 RID: 2096
		const_70,
		// Token: 0x04000831 RID: 2097
		const_71,
		// Token: 0x04000832 RID: 2098
		const_72,
		// Token: 0x04000833 RID: 2099
		const_73,
		// Token: 0x04000834 RID: 2100
		const_74,
		// Token: 0x04000835 RID: 2101
		const_75,
		// Token: 0x04000836 RID: 2102
		const_76,
		// Token: 0x04000837 RID: 2103
		const_77,
		// Token: 0x04000838 RID: 2104
		const_78,
		// Token: 0x04000839 RID: 2105
		const_79,
		// Token: 0x0400083A RID: 2106
		const_80,
		// Token: 0x0400083B RID: 2107
		const_81,
		// Token: 0x0400083C RID: 2108
		const_82,
		// Token: 0x0400083D RID: 2109
		const_83,
		// Token: 0x0400083E RID: 2110
		const_84,
		// Token: 0x0400083F RID: 2111
		const_85,
		// Token: 0x04000840 RID: 2112
		const_86,
		// Token: 0x04000841 RID: 2113
		const_87,
		// Token: 0x04000842 RID: 2114
		const_88,
		// Token: 0x04000843 RID: 2115
		const_89,
		// Token: 0x04000844 RID: 2116
		const_90,
		// Token: 0x04000845 RID: 2117
		const_91,
		// Token: 0x04000846 RID: 2118
		const_92,
		// Token: 0x04000847 RID: 2119
		const_93,
		// Token: 0x04000848 RID: 2120
		const_94,
		// Token: 0x04000849 RID: 2121
		const_95,
		// Token: 0x0400084A RID: 2122
		const_96,
		// Token: 0x0400084B RID: 2123
		const_97,
		// Token: 0x0400084C RID: 2124
		const_98,
		// Token: 0x0400084D RID: 2125
		const_99,
		// Token: 0x0400084E RID: 2126
		const_100,
		// Token: 0x0400084F RID: 2127
		const_101,
		// Token: 0x04000850 RID: 2128
		const_102,
		// Token: 0x04000851 RID: 2129
		const_103,
		// Token: 0x04000852 RID: 2130
		const_104,
		// Token: 0x04000853 RID: 2131
		const_105,
		// Token: 0x04000854 RID: 2132
		const_106,
		// Token: 0x04000855 RID: 2133
		const_107,
		// Token: 0x04000856 RID: 2134
		const_108,
		// Token: 0x04000857 RID: 2135
		const_109,
		// Token: 0x04000858 RID: 2136
		const_110,
		// Token: 0x04000859 RID: 2137
		const_111,
		// Token: 0x0400085A RID: 2138
		const_112,
		// Token: 0x0400085B RID: 2139
		const_113,
		// Token: 0x0400085C RID: 2140
		const_114,
		// Token: 0x0400085D RID: 2141
		const_115,
		// Token: 0x0400085E RID: 2142
		const_116,
		// Token: 0x0400085F RID: 2143
		const_117,
		// Token: 0x04000860 RID: 2144
		const_118,
		// Token: 0x04000861 RID: 2145
		const_119,
		// Token: 0x04000862 RID: 2146
		const_120,
		// Token: 0x04000863 RID: 2147
		const_121,
		// Token: 0x04000864 RID: 2148
		const_122,
		// Token: 0x04000865 RID: 2149
		const_123,
		// Token: 0x04000866 RID: 2150
		const_124,
		// Token: 0x04000867 RID: 2151
		const_125,
		// Token: 0x04000868 RID: 2152
		const_126,
		// Token: 0x04000869 RID: 2153
		const_127,
		// Token: 0x0400086A RID: 2154
		const_128,
		// Token: 0x0400086B RID: 2155
		const_129,
		// Token: 0x0400086C RID: 2156
		const_130,
		// Token: 0x0400086D RID: 2157
		const_131,
		// Token: 0x0400086E RID: 2158
		const_132,
		// Token: 0x0400086F RID: 2159
		const_133,
		// Token: 0x04000870 RID: 2160
		const_134,
		// Token: 0x04000871 RID: 2161
		const_135,
		// Token: 0x04000872 RID: 2162
		const_136,
		// Token: 0x04000873 RID: 2163
		const_137,
		// Token: 0x04000874 RID: 2164
		const_138,
		// Token: 0x04000875 RID: 2165
		const_139,
		// Token: 0x04000876 RID: 2166
		const_140,
		// Token: 0x04000877 RID: 2167
		const_141,
		// Token: 0x04000878 RID: 2168
		const_142,
		// Token: 0x04000879 RID: 2169
		const_143,
		// Token: 0x0400087A RID: 2170
		const_144,
		// Token: 0x0400087B RID: 2171
		const_145,
		// Token: 0x0400087C RID: 2172
		const_146,
		// Token: 0x0400087D RID: 2173
		const_147,
		// Token: 0x0400087E RID: 2174
		const_148,
		// Token: 0x0400087F RID: 2175
		const_149,
		// Token: 0x04000880 RID: 2176
		const_150,
		// Token: 0x04000881 RID: 2177
		const_151,
		// Token: 0x04000882 RID: 2178
		const_152,
		// Token: 0x04000883 RID: 2179
		const_153,
		// Token: 0x04000884 RID: 2180
		const_154,
		// Token: 0x04000885 RID: 2181
		const_155,
		// Token: 0x04000886 RID: 2182
		const_156,
		// Token: 0x04000887 RID: 2183
		const_157,
		// Token: 0x04000888 RID: 2184
		const_158,
		// Token: 0x04000889 RID: 2185
		const_159,
		// Token: 0x0400088A RID: 2186
		const_160,
		// Token: 0x0400088B RID: 2187
		const_161,
		// Token: 0x0400088C RID: 2188
		const_162,
		// Token: 0x0400088D RID: 2189
		const_163,
		// Token: 0x0400088E RID: 2190
		const_164,
		// Token: 0x0400088F RID: 2191
		const_165,
		// Token: 0x04000890 RID: 2192
		const_166,
		// Token: 0x04000891 RID: 2193
		const_167,
		// Token: 0x04000892 RID: 2194
		const_168,
		// Token: 0x04000893 RID: 2195
		const_169,
		// Token: 0x04000894 RID: 2196
		const_170,
		// Token: 0x04000895 RID: 2197
		const_171,
		// Token: 0x04000896 RID: 2198
		const_172,
		// Token: 0x04000897 RID: 2199
		const_173,
		// Token: 0x04000898 RID: 2200
		const_174,
		// Token: 0x04000899 RID: 2201
		const_175,
		// Token: 0x0400089A RID: 2202
		const_176,
		// Token: 0x0400089B RID: 2203
		const_177,
		// Token: 0x0400089C RID: 2204
		const_178,
		// Token: 0x0400089D RID: 2205
		const_179,
		// Token: 0x0400089E RID: 2206
		const_180,
		// Token: 0x0400089F RID: 2207
		const_181,
		// Token: 0x040008A0 RID: 2208
		const_182,
		// Token: 0x040008A1 RID: 2209
		const_183,
		// Token: 0x040008A2 RID: 2210
		const_184,
		// Token: 0x040008A3 RID: 2211
		const_185,
		// Token: 0x040008A4 RID: 2212
		const_186,
		// Token: 0x040008A5 RID: 2213
		const_187,
		// Token: 0x040008A6 RID: 2214
		const_188,
		// Token: 0x040008A7 RID: 2215
		const_189,
		// Token: 0x040008A8 RID: 2216
		const_190,
		// Token: 0x040008A9 RID: 2217
		const_191,
		// Token: 0x040008AA RID: 2218
		const_192,
		// Token: 0x040008AB RID: 2219
		const_193,
		// Token: 0x040008AC RID: 2220
		const_194,
		// Token: 0x040008AD RID: 2221
		const_195,
		// Token: 0x040008AE RID: 2222
		const_196
	}
}
