﻿using System;
using System.Runtime.InteropServices;
using ns417;
using ns554;

namespace ns265
{
	// Token: 0x02000228 RID: 552
	[Attribute2(1104)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct182
	{
		// Token: 0x04000EC5 RID: 3781
		public const int int_0 = 1104;

		// Token: 0x04000EC6 RID: 3782
		public GStruct305 gstruct305_0;

		// Token: 0x04000EC7 RID: 3783
		public byte byte_0;
	}
}
