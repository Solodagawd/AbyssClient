﻿using System;
using System.Runtime.InteropServices;
using ns203;
using ns54;

namespace ns52
{
	// Token: 0x02000044 RID: 68
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct21
	{
		// Token: 0x040000EE RID: 238
		public GStruct22 gstruct22_0;

		// Token: 0x040000EF RID: 239
		public int int_0;

		// Token: 0x040000F0 RID: 240
		public int int_1;

		// Token: 0x040000F1 RID: 241
		public int int_2;

		// Token: 0x040000F2 RID: 242
		public GStruct96 gstruct96_0;
	}
}
