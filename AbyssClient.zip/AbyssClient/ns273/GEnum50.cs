﻿using System;

namespace ns273
{
	// Token: 0x02000230 RID: 560
	public enum GEnum50
	{
		// Token: 0x04000EDE RID: 3806
		const_0,
		// Token: 0x04000EDF RID: 3807
		const_1,
		// Token: 0x04000EE0 RID: 3808
		const_2,
		// Token: 0x04000EE1 RID: 3809
		const_3,
		// Token: 0x04000EE2 RID: 3810
		const_4,
		// Token: 0x04000EE3 RID: 3811
		const_5,
		// Token: 0x04000EE4 RID: 3812
		const_6,
		// Token: 0x04000EE5 RID: 3813
		const_7,
		// Token: 0x04000EE6 RID: 3814
		const_8,
		// Token: 0x04000EE7 RID: 3815
		const_9,
		// Token: 0x04000EE8 RID: 3816
		const_10,
		// Token: 0x04000EE9 RID: 3817
		const_11,
		// Token: 0x04000EEA RID: 3818
		const_12
	}
}
