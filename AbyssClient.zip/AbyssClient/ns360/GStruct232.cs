﻿using System;
using System.Runtime.InteropServices;
using ns118;
using ns417;

namespace ns360
{
	// Token: 0x020002C2 RID: 706
	[Attribute2(4501)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct232
	{
		// Token: 0x040012AB RID: 4779
		public const int int_0 = 4501;

		// Token: 0x040012AC RID: 4780
		public GStruct43 gstruct43_0;
	}
}
