﻿using System;
using System.Runtime.InteropServices;
using ns66;

namespace ns3
{
	// Token: 0x02000007 RID: 7
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public struct GStruct1
	{
		// Token: 0x04000032 RID: 50
		public GEnum5 genum5_0;

		// Token: 0x04000033 RID: 51
		public float float_0;

		// Token: 0x04000034 RID: 52
		public float float_1;

		// Token: 0x04000035 RID: 53
		public byte byte_0;
	}
}
