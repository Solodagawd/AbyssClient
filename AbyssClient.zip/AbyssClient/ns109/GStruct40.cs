﻿using System;
using System.Runtime.InteropServices;
using ns118;
using ns417;

namespace ns109
{
	// Token: 0x02000093 RID: 147
	[Attribute2(4506)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct40
	{
		// Token: 0x04000319 RID: 793
		public const int int_0 = 4506;

		// Token: 0x0400031A RID: 794
		public GStruct43 gstruct43_0;

		// Token: 0x0400031B RID: 795
		public string string_0;

		// Token: 0x0400031C RID: 796
		public string string_1;
	}
}
