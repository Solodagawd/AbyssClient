﻿using System;
using System.Runtime.InteropServices;
using ns417;
using ns90;

namespace ns334
{
	// Token: 0x020002A0 RID: 672
	[Attribute2(4605)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct220
	{
		// Token: 0x0400121D RID: 4637
		public const int int_0 = 4605;

		// Token: 0x0400121E RID: 4638
		public GEnum10 genum10_0;
	}
}
