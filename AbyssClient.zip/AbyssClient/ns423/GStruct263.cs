﻿using System;
using System.Runtime.InteropServices;
using ns169;
using ns291;
using ns417;

namespace ns423
{
	// Token: 0x02000335 RID: 821
	[Attribute2(3408)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct263
	{
		// Token: 0x04001AB0 RID: 6832
		public const int int_0 = 3408;

		// Token: 0x04001AB1 RID: 6833
		public GStruct78 gstruct78_0;

		// Token: 0x04001AB2 RID: 6834
		public GEnum54 genum54_0;

		// Token: 0x04001AB3 RID: 6835
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_0;
	}
}
