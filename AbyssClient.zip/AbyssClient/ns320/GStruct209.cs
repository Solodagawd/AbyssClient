﻿using System;
using System.Runtime.InteropServices;
using ns417;
using ns54;

namespace ns320
{
	// Token: 0x0200027F RID: 639
	[Attribute2(339)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct209
	{
		// Token: 0x0400118F RID: 4495
		public const int int_0 = 339;

		// Token: 0x04001190 RID: 4496
		public GStruct22 gstruct22_0;

		// Token: 0x04001191 RID: 4497
		public GStruct22 gstruct22_1;
	}
}
