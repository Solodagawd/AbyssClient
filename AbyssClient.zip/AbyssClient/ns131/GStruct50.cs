﻿using System;
using ns417;

namespace ns131
{
	// Token: 0x020000C9 RID: 201
	[Attribute2(125)]
	public struct GStruct50
	{
		// Token: 0x04000501 RID: 1281
		public const int int_0 = 125;
	}
}
