﻿using System;
using System.Runtime.InteropServices;
using ns151;
using ns169;
using ns417;

namespace ns310
{
	// Token: 0x02000274 RID: 628
	[Attribute2(1323)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct206
	{
		// Token: 0x0400110D RID: 4365
		public const int int_0 = 1323;

		// Token: 0x0400110E RID: 4366
		public GStruct78 gstruct78_0;

		// Token: 0x0400110F RID: 4367
		public GStruct66 gstruct66_0;
	}
}
