﻿using System;

namespace ns173
{
	// Token: 0x02000118 RID: 280
	public enum GEnum27
	{
		// Token: 0x040006B6 RID: 1718
		const_0,
		// Token: 0x040006B7 RID: 1719
		const_1,
		// Token: 0x040006B8 RID: 1720
		const_2
	}
}
