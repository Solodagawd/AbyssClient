﻿using System;

namespace ns400
{
	// Token: 0x02000307 RID: 775
	public enum GEnum76
	{
		// Token: 0x040018F1 RID: 6385
		const_0,
		// Token: 0x040018F2 RID: 6386
		const_1
	}
}
