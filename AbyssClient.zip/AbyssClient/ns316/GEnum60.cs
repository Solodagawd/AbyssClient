﻿using System;

namespace ns316
{
	// Token: 0x0200027A RID: 634
	public enum GEnum60
	{
		// Token: 0x04001129 RID: 4393
		const_0,
		// Token: 0x0400112A RID: 4394
		const_1 = 100,
		// Token: 0x0400112B RID: 4395
		const_2,
		// Token: 0x0400112C RID: 4396
		const_3 = 200,
		// Token: 0x0400112D RID: 4397
		const_4,
		// Token: 0x0400112E RID: 4398
		const_5,
		// Token: 0x0400112F RID: 4399
		const_6,
		// Token: 0x04001130 RID: 4400
		const_7,
		// Token: 0x04001131 RID: 4401
		const_8,
		// Token: 0x04001132 RID: 4402
		const_9,
		// Token: 0x04001133 RID: 4403
		const_10 = 300,
		// Token: 0x04001134 RID: 4404
		const_11,
		// Token: 0x04001135 RID: 4405
		const_12,
		// Token: 0x04001136 RID: 4406
		const_13,
		// Token: 0x04001137 RID: 4407
		const_14,
		// Token: 0x04001138 RID: 4408
		const_15,
		// Token: 0x04001139 RID: 4409
		const_16 = 307,
		// Token: 0x0400113A RID: 4410
		const_17 = 400,
		// Token: 0x0400113B RID: 4411
		const_18,
		// Token: 0x0400113C RID: 4412
		const_19,
		// Token: 0x0400113D RID: 4413
		const_20,
		// Token: 0x0400113E RID: 4414
		const_21,
		// Token: 0x0400113F RID: 4415
		const_22,
		// Token: 0x04001140 RID: 4416
		const_23,
		// Token: 0x04001141 RID: 4417
		const_24,
		// Token: 0x04001142 RID: 4418
		const_25,
		// Token: 0x04001143 RID: 4419
		const_26,
		// Token: 0x04001144 RID: 4420
		const_27,
		// Token: 0x04001145 RID: 4421
		const_28,
		// Token: 0x04001146 RID: 4422
		const_29,
		// Token: 0x04001147 RID: 4423
		const_30,
		// Token: 0x04001148 RID: 4424
		const_31,
		// Token: 0x04001149 RID: 4425
		const_32,
		// Token: 0x0400114A RID: 4426
		const_33,
		// Token: 0x0400114B RID: 4427
		const_34,
		// Token: 0x0400114C RID: 4428
		const_35,
		// Token: 0x0400114D RID: 4429
		const_36 = 429,
		// Token: 0x0400114E RID: 4430
		const_37 = 500,
		// Token: 0x0400114F RID: 4431
		const_38,
		// Token: 0x04001150 RID: 4432
		const_39,
		// Token: 0x04001151 RID: 4433
		const_40,
		// Token: 0x04001152 RID: 4434
		const_41,
		// Token: 0x04001153 RID: 4435
		const_42,
		// Token: 0x04001154 RID: 4436
		const_43 = 599
	}
}
