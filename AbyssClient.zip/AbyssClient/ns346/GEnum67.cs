﻿using System;

namespace ns346
{
	// Token: 0x020002B3 RID: 691
	public enum GEnum67
	{
		// Token: 0x0400127F RID: 4735
		const_0,
		// Token: 0x04001280 RID: 4736
		const_1,
		// Token: 0x04001281 RID: 4737
		const_2,
		// Token: 0x04001282 RID: 4738
		const_3,
		// Token: 0x04001283 RID: 4739
		const_4,
		// Token: 0x04001284 RID: 4740
		const_5,
		// Token: 0x04001285 RID: 4741
		const_6,
		// Token: 0x04001286 RID: 4742
		const_7,
		// Token: 0x04001287 RID: 4743
		const_8,
		// Token: 0x04001288 RID: 4744
		const_9
	}
}
