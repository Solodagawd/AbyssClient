﻿using System;

namespace ns223
{
	// Token: 0x0200019D RID: 413
	public enum GEnum44
	{
		// Token: 0x04000BA1 RID: 2977
		const_0,
		// Token: 0x04000BA2 RID: 2978
		const_1,
		// Token: 0x04000BA3 RID: 2979
		const_2,
		// Token: 0x04000BA4 RID: 2980
		const_3,
		// Token: 0x04000BA5 RID: 2981
		const_4,
		// Token: 0x04000BA6 RID: 2982
		const_5
	}
}
