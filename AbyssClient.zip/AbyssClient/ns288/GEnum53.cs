﻿using System;

namespace ns288
{
	// Token: 0x02000250 RID: 592
	public enum GEnum53
	{
		// Token: 0x04000FB4 RID: 4020
		const_0,
		// Token: 0x04000FB5 RID: 4021
		const_1
	}
}
