﻿using System;

namespace ns39
{
	// Token: 0x0200002B RID: 43
	[Flags]
	public enum GEnum2
	{
		// Token: 0x0400009F RID: 159
		flag_0 = 0,
		// Token: 0x040000A0 RID: 160
		flag_1 = 1,
		// Token: 0x040000A1 RID: 161
		flag_2 = 2,
		// Token: 0x040000A2 RID: 162
		flag_3 = 4,
		// Token: 0x040000A3 RID: 163
		flag_4 = 8,
		// Token: 0x040000A4 RID: 164
		flag_5 = 16,
		// Token: 0x040000A5 RID: 165
		flag_6 = -1
	}
}
