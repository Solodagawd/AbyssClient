﻿using System;
using System.Runtime.InteropServices;
using ns118;
using ns417;

namespace ns144
{
	// Token: 0x020000DD RID: 221
	[Attribute2(4509)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct61
	{
		// Token: 0x04000551 RID: 1361
		public const int int_0 = 4509;

		// Token: 0x04000552 RID: 1362
		public GStruct43 gstruct43_0;

		// Token: 0x04000553 RID: 1363
		public uint uint_0;

		// Token: 0x04000554 RID: 1364
		public uint uint_1;
	}
}
