﻿using System;
using System.Runtime.InteropServices;
using ns169;
using ns291;
using ns417;

namespace ns32
{
	// Token: 0x02000024 RID: 36
	[Attribute2(3403)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct14
	{
		// Token: 0x04000086 RID: 134
		public const int int_0 = 3403;

		// Token: 0x04000087 RID: 135
		public GEnum54 genum54_0;

		// Token: 0x04000088 RID: 136
		public GStruct78 gstruct78_0;

		// Token: 0x04000089 RID: 137
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_0;
	}
}
