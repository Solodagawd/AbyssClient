﻿using System;
using System.Runtime.InteropServices;
using ns243;
using ns291;
using ns417;

namespace ns502
{
	// Token: 0x0200036A RID: 874
	[Attribute2(163)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct274
	{
		// Token: 0x04001BE8 RID: 7144
		public const int int_0 = 163;

		// Token: 0x04001BE9 RID: 7145
		public GStruct176 gstruct176_0;

		// Token: 0x04001BEA RID: 7146
		public GEnum54 genum54_0;
	}
}
