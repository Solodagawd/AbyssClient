﻿using System;
using System.Runtime.InteropServices;
using ns118;
using ns417;

namespace ns404
{
	// Token: 0x0200030B RID: 779
	[Attribute2(4527)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct250
	{
		// Token: 0x04001905 RID: 6405
		public const int int_0 = 4527;

		// Token: 0x04001906 RID: 6406
		public GStruct43 gstruct43_0;

		// Token: 0x04001907 RID: 6407
		public GStruct43 gstruct43_1;
	}
}
