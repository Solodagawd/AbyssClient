﻿using System;
using ns417;

namespace ns128
{
	// Token: 0x020000C6 RID: 198
	[Attribute2(704)]
	public struct GStruct47
	{
		// Token: 0x040004F7 RID: 1271
		public const int int_0 = 704;
	}
}
