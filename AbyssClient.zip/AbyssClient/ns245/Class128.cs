﻿using System;

namespace ns245
{
	// Token: 0x02000222 RID: 546
	internal abstract class Class128
	{
		// Token: 0x060018C3 RID: 6339
		internal abstract object vmethod_0();
	}
}
