﻿using System;
using System.Runtime.InteropServices;
using ns417;
using ns549;

namespace ns34
{
	// Token: 0x02000026 RID: 38
	[Attribute2(3402)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct15
	{
		// Token: 0x04000096 RID: 150
		public const int int_0 = 3402;

		// Token: 0x04000097 RID: 151
		public GStruct303 gstruct303_0;

		// Token: 0x04000098 RID: 152
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_0;
	}
}
