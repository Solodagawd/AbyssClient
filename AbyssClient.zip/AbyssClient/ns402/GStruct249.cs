﻿using System;
using System.Runtime.InteropServices;
using ns319;
using ns353;
using ns417;
using ns54;

namespace ns402
{
	// Token: 0x02000309 RID: 777
	[Attribute2(1201)]
	[StructLayout(LayoutKind.Sequential, Pack = 4)]
	public struct GStruct249
	{
		// Token: 0x040018F9 RID: 6393
		public const int int_0 = 1201;

		// Token: 0x040018FA RID: 6394
		public GStruct208 gstruct208_0;

		// Token: 0x040018FB RID: 6395
		public GStruct229 gstruct229_0;

		// Token: 0x040018FC RID: 6396
		public GStruct22 gstruct22_0;

		// Token: 0x040018FD RID: 6397
		public int int_1;
	}
}
