﻿using System;
using System.Runtime.InteropServices;
using ns291;
using ns417;

namespace ns294
{
	// Token: 0x0200025E RID: 606
	[Attribute2(3411)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct197
	{
		// Token: 0x0400107B RID: 4219
		public const int int_0 = 3411;

		// Token: 0x0400107C RID: 4220
		public GEnum54 genum54_0;
	}
}
