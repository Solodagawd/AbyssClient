﻿using System;
using System.Runtime.InteropServices;
using ns151;
using ns291;
using ns417;

namespace ns369
{
	// Token: 0x020002D9 RID: 729
	[Attribute2(1305)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct234
	{
		// Token: 0x04001342 RID: 4930
		public const int int_0 = 1305;

		// Token: 0x04001343 RID: 4931
		public GStruct66 gstruct66_0;

		// Token: 0x04001344 RID: 4932
		public GEnum54 genum54_0;
	}
}
