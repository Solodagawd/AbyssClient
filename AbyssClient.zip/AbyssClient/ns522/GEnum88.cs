﻿using System;

namespace ns522
{
	// Token: 0x02000389 RID: 905
	public enum GEnum88
	{
		// Token: 0x04001CBA RID: 7354
		const_0 = 1,
		// Token: 0x04001CBB RID: 7355
		const_1,
		// Token: 0x04001CBC RID: 7356
		const_2,
		// Token: 0x04001CBD RID: 7357
		const_3,
		// Token: 0x04001CBE RID: 7358
		const_4,
		// Token: 0x04001CBF RID: 7359
		const_5,
		// Token: 0x04001CC0 RID: 7360
		const_6,
		// Token: 0x04001CC1 RID: 7361
		const_7,
		// Token: 0x04001CC2 RID: 7362
		const_8,
		// Token: 0x04001CC3 RID: 7363
		const_9,
		// Token: 0x04001CC4 RID: 7364
		const_10,
		// Token: 0x04001CC5 RID: 7365
		const_11 = 15
	}
}
