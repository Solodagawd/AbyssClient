﻿using System;
using System.Runtime.InteropServices;
using ns118;
using ns417;

namespace ns485
{
	// Token: 0x0200033C RID: 828
	[Attribute2(4511)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct265
	{
		// Token: 0x04001AD9 RID: 6873
		public const int int_0 = 4511;

		// Token: 0x04001ADA RID: 6874
		public GStruct43 gstruct43_0;

		// Token: 0x04001ADB RID: 6875
		public uint uint_0;

		// Token: 0x04001ADC RID: 6876
		public uint uint_1;

		// Token: 0x04001ADD RID: 6877
		public float float_0;

		// Token: 0x04001ADE RID: 6878
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_0;

		// Token: 0x04001ADF RID: 6879
		public uint uint_2;
	}
}
