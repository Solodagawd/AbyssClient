﻿using System;
using System.Runtime.InteropServices;
using ns417;

namespace ns177
{
	// Token: 0x0200011F RID: 287
	[Attribute2(714)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct82
	{
		// Token: 0x04000728 RID: 1832
		public const int int_0 = 714;

		// Token: 0x04000729 RID: 1833
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_0;

		// Token: 0x0400072A RID: 1834
		public uint uint_0;
	}
}
