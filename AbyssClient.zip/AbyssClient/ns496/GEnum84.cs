﻿using System;

namespace ns496
{
	// Token: 0x0200035F RID: 863
	public enum GEnum84
	{
		// Token: 0x04001BC7 RID: 7111
		const_0,
		// Token: 0x04001BC8 RID: 7112
		const_1,
		// Token: 0x04001BC9 RID: 7113
		const_2,
		// Token: 0x04001BCA RID: 7114
		const_3,
		// Token: 0x04001BCB RID: 7115
		const_4
	}
}
