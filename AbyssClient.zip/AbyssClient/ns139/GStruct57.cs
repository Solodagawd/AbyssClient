﻿using System;
using System.Runtime.InteropServices;
using ns417;

namespace ns139
{
	// Token: 0x020000D8 RID: 216
	[Attribute2(509)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct57
	{
		// Token: 0x0400053E RID: 1342
		public const int int_0 = 509;

		// Token: 0x0400053F RID: 1343
		public ulong ulong_0;

		// Token: 0x04000540 RID: 1344
		public ulong ulong_1;

		// Token: 0x04000541 RID: 1345
		public uint uint_0;

		// Token: 0x04000542 RID: 1346
		public ushort ushort_0;
	}
}
