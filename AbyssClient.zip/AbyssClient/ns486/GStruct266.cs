﻿using System;
using System.Runtime.InteropServices;
using ns274;
using ns316;
using ns417;

namespace ns486
{
	// Token: 0x0200033D RID: 829
	[Attribute2(2101)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct266
	{
		// Token: 0x04001AE0 RID: 6880
		public const int int_0 = 2101;

		// Token: 0x04001AE1 RID: 6881
		public GStruct188 gstruct188_0;

		// Token: 0x04001AE2 RID: 6882
		public ulong ulong_0;

		// Token: 0x04001AE3 RID: 6883
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_0;

		// Token: 0x04001AE4 RID: 6884
		public GEnum60 genum60_0;

		// Token: 0x04001AE5 RID: 6885
		public uint uint_0;
	}
}
