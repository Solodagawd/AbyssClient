﻿using System;
using System.Runtime.InteropServices;
using ns291;
using ns417;

namespace ns422
{
	// Token: 0x02000334 RID: 820
	[Attribute2(1110)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct262
	{
		// Token: 0x04001AAD RID: 6829
		public const int int_0 = 1110;

		// Token: 0x04001AAE RID: 6830
		public ulong ulong_0;

		// Token: 0x04001AAF RID: 6831
		public GEnum54 genum54_0;
	}
}
