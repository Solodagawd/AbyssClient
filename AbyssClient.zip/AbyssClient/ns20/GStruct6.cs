﻿using System;
using System.Runtime.InteropServices;
using ns291;
using ns417;

namespace ns20
{
	// Token: 0x02000018 RID: 24
	[Attribute2(513)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct6
	{
		// Token: 0x04000069 RID: 105
		public const int int_0 = 513;

		// Token: 0x0400006A RID: 106
		public GEnum54 genum54_0;

		// Token: 0x0400006B RID: 107
		public ulong ulong_0;
	}
}
