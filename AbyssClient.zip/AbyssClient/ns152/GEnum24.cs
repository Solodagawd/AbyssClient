﻿using System;

namespace ns152
{
	// Token: 0x020000FE RID: 254
	public enum GEnum24
	{
		// Token: 0x04000657 RID: 1623
		const_0,
		// Token: 0x04000658 RID: 1624
		const_1,
		// Token: 0x04000659 RID: 1625
		const_2,
		// Token: 0x0400065A RID: 1626
		const_3
	}
}
