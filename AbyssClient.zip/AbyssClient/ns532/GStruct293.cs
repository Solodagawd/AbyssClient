﻿using System;
using System.Runtime.InteropServices;
using ns118;
using ns417;

namespace ns532
{
	// Token: 0x02000393 RID: 915
	[Attribute2(4505)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct293
	{
		// Token: 0x04001D03 RID: 7427
		public const int int_0 = 4505;

		// Token: 0x04001D04 RID: 7428
		public GStruct43 gstruct43_0;

		// Token: 0x04001D05 RID: 7429
		public string string_0;

		// Token: 0x04001D06 RID: 7430
		public string string_1;

		// Token: 0x04001D07 RID: 7431
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_0;

		// Token: 0x04001D08 RID: 7432
		public string string_2;

		// Token: 0x04001D09 RID: 7433
		[MarshalAs(UnmanagedType.I1)]
		public bool bool_1;
	}
}
