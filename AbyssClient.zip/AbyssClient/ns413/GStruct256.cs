﻿using System;
using System.Runtime.InteropServices;
using ns417;

namespace ns413
{
	// Token: 0x02000319 RID: 793
	[Attribute2(1701)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct256
	{
		// Token: 0x04001934 RID: 6452
		public const int int_0 = 1701;

		// Token: 0x04001935 RID: 6453
		public uint uint_0;
	}
}
