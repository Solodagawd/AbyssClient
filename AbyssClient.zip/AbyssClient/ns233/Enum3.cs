﻿using System;

namespace ns233
{
	// Token: 0x020001AB RID: 427
	internal enum Enum3 : byte
	{
		// Token: 0x04000BD9 RID: 3033
		const_0,
		// Token: 0x04000BDA RID: 3034
		const_1,
		// Token: 0x04000BDB RID: 3035
		const_2
	}
}
