﻿using System;
using System.Runtime.InteropServices;
using ns291;
using ns417;
using ns506;

namespace ns202
{
	// Token: 0x02000148 RID: 328
	[Attribute2(2301)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct95
	{
		// Token: 0x040008E3 RID: 2275
		public const int int_0 = 2301;

		// Token: 0x040008E4 RID: 2276
		public GStruct277 gstruct277_0;

		// Token: 0x040008E5 RID: 2277
		public GEnum54 genum54_0;
	}
}
