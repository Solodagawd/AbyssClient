﻿using System;
using ns417;

namespace ns160
{
	// Token: 0x02000109 RID: 265
	[Attribute2(1702)]
	public struct GStruct74
	{
		// Token: 0x0400067F RID: 1663
		public const int int_0 = 1702;
	}
}
