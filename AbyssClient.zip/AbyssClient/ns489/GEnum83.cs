﻿using System;

namespace ns489
{
	// Token: 0x0200034F RID: 847
	public enum GEnum83
	{
		// Token: 0x04001B82 RID: 7042
		const_0,
		// Token: 0x04001B83 RID: 7043
		const_1,
		// Token: 0x04001B84 RID: 7044
		const_2
	}
}
