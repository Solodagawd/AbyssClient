﻿using System;
using ns417;

namespace ns340
{
	// Token: 0x020002AA RID: 682
	[Attribute2(4107)]
	public struct GStruct224
	{
		// Token: 0x04001254 RID: 4692
		public const int int_0 = 4107;
	}
}
