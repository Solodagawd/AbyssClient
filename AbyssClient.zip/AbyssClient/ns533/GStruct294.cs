﻿using System;
using System.Runtime.InteropServices;
using ns274;
using ns417;

namespace ns533
{
	// Token: 0x02000394 RID: 916
	[Attribute2(2102)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct294
	{
		// Token: 0x04001D0A RID: 7434
		public const int int_0 = 2102;

		// Token: 0x04001D0B RID: 7435
		public GStruct188 gstruct188_0;

		// Token: 0x04001D0C RID: 7436
		public ulong ulong_0;
	}
}
