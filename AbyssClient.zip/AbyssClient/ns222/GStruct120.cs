﻿using System;
using System.Runtime.InteropServices;
using ns417;

namespace ns222
{
	// Token: 0x0200019C RID: 412
	[Attribute2(152)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct120
	{
		// Token: 0x04000B9C RID: 2972
		public const int int_0 = 152;

		// Token: 0x04000B9D RID: 2973
		public uint uint_0;

		// Token: 0x04000B9E RID: 2974
		public ulong ulong_0;

		// Token: 0x04000B9F RID: 2975
		public byte byte_0;
	}
}
