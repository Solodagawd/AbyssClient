﻿using System;

namespace ns297
{
	// Token: 0x02000265 RID: 613
	public enum GEnum55
	{
		// Token: 0x040010B7 RID: 4279
		const_0 = -2,
		// Token: 0x040010B8 RID: 4280
		const_1,
		// Token: 0x040010B9 RID: 4281
		const_2,
		// Token: 0x040010BA RID: 4282
		const_3,
		// Token: 0x040010BB RID: 4283
		const_4,
		// Token: 0x040010BC RID: 4284
		const_5
	}
}
