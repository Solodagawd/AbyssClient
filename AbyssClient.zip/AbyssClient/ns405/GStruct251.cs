﻿using System;
using System.Runtime.InteropServices;
using ns118;
using ns417;

namespace ns405
{
	// Token: 0x0200030C RID: 780
	[Attribute2(4515)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct251
	{
		// Token: 0x04001908 RID: 6408
		public const int int_0 = 4515;

		// Token: 0x04001909 RID: 6409
		public GStruct43 gstruct43_0;

		// Token: 0x0400190A RID: 6410
		public string string_0;
	}
}
