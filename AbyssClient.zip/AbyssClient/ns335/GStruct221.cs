﻿using System;
using System.Runtime.InteropServices;
using ns417;
using ns522;
using ns54;

namespace ns335
{
	// Token: 0x020002A2 RID: 674
	[Attribute2(342)]
	[StructLayout(LayoutKind.Sequential, Pack = 4)]
	public struct GStruct221
	{
		// Token: 0x0400121F RID: 4639
		public const int int_0 = 342;

		// Token: 0x04001220 RID: 4640
		public GStruct22 gstruct22_0;

		// Token: 0x04001221 RID: 4641
		public GEnum88 genum88_0;
	}
}
