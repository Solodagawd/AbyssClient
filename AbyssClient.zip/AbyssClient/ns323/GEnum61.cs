﻿using System;

namespace ns323
{
	// Token: 0x02000283 RID: 643
	public enum GEnum61
	{
		// Token: 0x040011A3 RID: 4515
		const_0,
		// Token: 0x040011A4 RID: 4516
		const_1,
		// Token: 0x040011A5 RID: 4517
		const_2
	}
}
