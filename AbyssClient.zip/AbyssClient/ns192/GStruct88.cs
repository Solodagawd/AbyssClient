﻿using System;
using ns417;

namespace ns192
{
	// Token: 0x02000138 RID: 312
	[Attribute2(701)]
	public struct GStruct88
	{
		// Token: 0x040007DF RID: 2015
		public const int int_0 = 701;
	}
}
