﻿using System;

namespace ns212
{
	// Token: 0x02000184 RID: 388
	public enum GEnum38
	{
		// Token: 0x04000AE0 RID: 2784
		const_0,
		// Token: 0x04000AE1 RID: 2785
		const_1
	}
}
