﻿using System;
using ns241;
using ns466;

namespace ns473
{
	// Token: 0x02000366 RID: 870
	public class GClass176 : GClass169
	{
		// Token: 0x0600481F RID: 18463 RVA: 0x00021C48 File Offset: 0x0001FE48
		internal void method_8(int int_0)
		{
			base.vmethod_27(int_0);
		}

		// Token: 0x06004820 RID: 18464 RVA: 0x001109B8 File Offset: 0x0010EBB8
		internal void method_9()
		{
			this.method_25();
		}

		// Token: 0x06004821 RID: 18465 RVA: 0x00021E40 File Offset: 0x00020040
		internal void method_10()
		{
			base.vmethod_9();
		}

		// Token: 0x06004822 RID: 18466 RVA: 0x00021BA8 File Offset: 0x0001FDA8
		internal void method_11()
		{
			base.vmethod_28();
		}

		// Token: 0x06004823 RID: 18467 RVA: 0x001109CC File Offset: 0x0010EBCC
		internal void method_12()
		{
			this.method_37();
		}

		// Token: 0x1700006F RID: 111
		// (get) Token: 0x06004824 RID: 18468 RVA: 0x001109E0 File Offset: 0x0010EBE0
		internal float Single_0
		{
			get
			{
				return (float)GClass84.smethod_841() / 1000f;
			}
		}

		// Token: 0x06004825 RID: 18469 RVA: 0x001109FC File Offset: 0x0010EBFC
		internal void method_13()
		{
			this.method_35();
		}

		// Token: 0x06004826 RID: 18470 RVA: 0x00021CC8 File Offset: 0x0001FEC8
		internal void method_14()
		{
			base.vmethod_15();
		}

		// Token: 0x06004827 RID: 18471 RVA: 0x00110A10 File Offset: 0x0010EC10
		public override void vmethod_15()
		{
			this.method_15();
		}

		// Token: 0x06004828 RID: 18472 RVA: 0x00110A24 File Offset: 0x0010EC24
		internal void method_15()
		{
			this.method_14();
		}

		// Token: 0x06004829 RID: 18473 RVA: 0x00110A38 File Offset: 0x0010EC38
		public override void vmethod_22()
		{
			this.method_28();
		}

		// Token: 0x0600482B RID: 18475 RVA: 0x00021DF0 File Offset: 0x0001FFF0
		internal void method_16()
		{
			base.vmethod_26();
		}

		// Token: 0x0600482C RID: 18476 RVA: 0x00110A60 File Offset: 0x0010EC60
		public override void vmethod_23()
		{
			this.method_12();
		}

		// Token: 0x0600482D RID: 18477 RVA: 0x00110A74 File Offset: 0x0010EC74
		internal void method_17()
		{
			this.method_21();
		}

		// Token: 0x0600482E RID: 18478 RVA: 0x00021DA0 File Offset: 0x0001FFA0
		internal void method_18()
		{
			base.vmethod_24();
		}

		// Token: 0x0600482F RID: 18479 RVA: 0x00110A88 File Offset: 0x0010EC88
		internal void method_19()
		{
			this.method_10();
		}

		// Token: 0x06004830 RID: 18480 RVA: 0x00110A9C File Offset: 0x0010EC9C
		internal void method_20()
		{
			this.method_11();
		}

		// Token: 0x06004831 RID: 18481 RVA: 0x00021E7C File Offset: 0x0002007C
		internal void method_21()
		{
			base.vmethod_25();
		}

		// Token: 0x06004832 RID: 18482 RVA: 0x00110AB0 File Offset: 0x0010ECB0
		internal void method_22()
		{
			this.method_26();
		}

		// Token: 0x06004833 RID: 18483 RVA: 0x00110AC4 File Offset: 0x0010ECC4
		internal void method_23(int int_0)
		{
			this.method_36(int_0);
		}

		// Token: 0x06004834 RID: 18484 RVA: 0x00021E04 File Offset: 0x00020004
		internal void method_24()
		{
			base.vmethod_12();
		}

		// Token: 0x06004835 RID: 18485 RVA: 0x00021C84 File Offset: 0x0001FE84
		internal void method_25()
		{
			base.vmethod_31();
		}

		// Token: 0x06004836 RID: 18486 RVA: 0x00021E2C File Offset: 0x0002002C
		internal void method_26()
		{
			base.vmethod_19();
		}

		// Token: 0x06004837 RID: 18487 RVA: 0x00110AD8 File Offset: 0x0010ECD8
		public override void vmethod_12()
		{
			this.method_33();
		}

		// Token: 0x06004838 RID: 18488 RVA: 0x00110AEC File Offset: 0x0010ECEC
		internal void method_27()
		{
			this.method_30();
		}

		// Token: 0x06004839 RID: 18489 RVA: 0x00110B00 File Offset: 0x0010ED00
		internal void method_28()
		{
			this.method_29();
		}

		// Token: 0x0600483A RID: 18490 RVA: 0x00110B14 File Offset: 0x0010ED14
		public override void vmethod_27(int int_0)
		{
			this.method_31(int_0);
		}

		// Token: 0x0600483B RID: 18491 RVA: 0x00110B28 File Offset: 0x0010ED28
		public override void vmethod_25()
		{
			this.method_17();
		}

		// Token: 0x0600483C RID: 18492 RVA: 0x00110B3C File Offset: 0x0010ED3C
		public override void vmethod_9()
		{
			this.method_19();
		}

		// Token: 0x0600483D RID: 18493 RVA: 0x00021B94 File Offset: 0x0001FD94
		internal void method_29()
		{
			base.vmethod_22();
		}

		// Token: 0x0600483E RID: 18494 RVA: 0x00021AB8 File Offset: 0x0001FCB8
		internal void method_30()
		{
			base.vmethod_10();
		}

		// Token: 0x0600483F RID: 18495 RVA: 0x00110B50 File Offset: 0x0010ED50
		public override void vmethod_11()
		{
			this.method_13();
		}

		// Token: 0x06004840 RID: 18496 RVA: 0x00110B64 File Offset: 0x0010ED64
		public override void vmethod_31()
		{
			this.method_9();
		}

		// Token: 0x06004841 RID: 18497 RVA: 0x00110B78 File Offset: 0x0010ED78
		internal void method_31(int int_0)
		{
			this.method_8(int_0);
		}

		// Token: 0x06004842 RID: 18498 RVA: 0x00110B8C File Offset: 0x0010ED8C
		public override void vmethod_10()
		{
			this.method_27();
		}

		// Token: 0x06004843 RID: 18499 RVA: 0x00110BA0 File Offset: 0x0010EDA0
		public override void vmethod_19()
		{
			this.method_22();
		}

		// Token: 0x06004844 RID: 18500 RVA: 0x00110BB4 File Offset: 0x0010EDB4
		internal void method_32()
		{
			this.method_18();
		}

		// Token: 0x06004845 RID: 18501 RVA: 0x00110BC8 File Offset: 0x0010EDC8
		internal void method_33()
		{
			this.method_24();
		}

		// Token: 0x06004846 RID: 18502 RVA: 0x00110BDC File Offset: 0x0010EDDC
		internal void method_34()
		{
			this.method_16();
		}

		// Token: 0x06004847 RID: 18503 RVA: 0x00110BF0 File Offset: 0x0010EDF0
		public override void vmethod_28()
		{
			this.method_20();
		}

		// Token: 0x06004848 RID: 18504 RVA: 0x00110C04 File Offset: 0x0010EE04
		public override void vmethod_8(int int_0)
		{
			this.method_23(int_0);
		}

		// Token: 0x06004849 RID: 18505 RVA: 0x00021E68 File Offset: 0x00020068
		internal void method_35()
		{
			base.vmethod_11();
		}

		// Token: 0x0600484A RID: 18506 RVA: 0x00021B80 File Offset: 0x0001FD80
		internal void method_36(int int_0)
		{
			base.vmethod_8(int_0);
		}

		// Token: 0x0600484B RID: 18507 RVA: 0x00110C18 File Offset: 0x0010EE18
		public override void vmethod_26()
		{
			this.method_34();
		}

		// Token: 0x0600484C RID: 18508 RVA: 0x00110C2C File Offset: 0x0010EE2C
		public override void vmethod_24()
		{
			this.method_32();
		}

		// Token: 0x0600484D RID: 18509 RVA: 0x0002CA38 File Offset: 0x0002AC38
		internal void method_37()
		{
			base.vmethod_23();
		}
	}
}
