﻿using System;
using ns417;

namespace ns199
{
	// Token: 0x02000140 RID: 320
	[Attribute2(4105)]
	public struct GStruct92
	{
		// Token: 0x040008B7 RID: 2231
		public const int int_0 = 4105;
	}
}
