﻿using System;
using System.Runtime.InteropServices;
using ns118;
using ns417;

namespace ns104
{
	// Token: 0x0200008E RID: 142
	[Attribute2(4522)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct37
	{
		// Token: 0x04000303 RID: 771
		public const int int_0 = 4522;

		// Token: 0x04000304 RID: 772
		public GStruct43 gstruct43_0;

		// Token: 0x04000305 RID: 773
		public uint uint_0;
	}
}
