﻿using System;
using ns466;
using ns467;

namespace ns469
{
	// Token: 0x0200012B RID: 299
	public class GClass172 : GClass169
	{
		// Token: 0x06000A9C RID: 2716 RVA: 0x0002C588 File Offset: 0x0002A788
		internal void method_8()
		{
			this.method_40();
		}

		// Token: 0x06000A9D RID: 2717 RVA: 0x0002C59C File Offset: 0x0002A79C
		public override void vmethod_22()
		{
			this.method_15();
		}

		// Token: 0x06000A9E RID: 2718 RVA: 0x0002C5B0 File Offset: 0x0002A7B0
		internal void method_9()
		{
			this.method_28();
		}

		// Token: 0x06000A9F RID: 2719 RVA: 0x0002C5C4 File Offset: 0x0002A7C4
		internal void method_10()
		{
			this.method_39();
		}

		// Token: 0x06000AA0 RID: 2720 RVA: 0x0002C5D8 File Offset: 0x0002A7D8
		public override void vmethod_28()
		{
			this.method_26();
		}

		// Token: 0x06000AA1 RID: 2721 RVA: 0x00021C48 File Offset: 0x0001FE48
		internal void method_11(int int_3)
		{
			base.vmethod_27(int_3);
		}

		// Token: 0x06000AA2 RID: 2722 RVA: 0x0002C5EC File Offset: 0x0002A7EC
		public virtual void vmethod_33(int int_3, GClass169 gclass169_0)
		{
			this.method_18(int_3, gclass169_0);
		}

		// Token: 0x06000AA3 RID: 2723 RVA: 0x00021E40 File Offset: 0x00020040
		internal void method_12()
		{
			base.vmethod_9();
		}

		// Token: 0x06000AA4 RID: 2724 RVA: 0x00021E2C File Offset: 0x0002002C
		internal void method_13()
		{
			base.vmethod_19();
		}

		// Token: 0x06000AA5 RID: 2725 RVA: 0x00021E04 File Offset: 0x00020004
		internal void method_14()
		{
			base.vmethod_12();
		}

		// Token: 0x06000AA6 RID: 2726 RVA: 0x0002C604 File Offset: 0x0002A804
		public override void vmethod_9()
		{
			this.method_25();
		}

		// Token: 0x06000AA7 RID: 2727 RVA: 0x0002C618 File Offset: 0x0002A818
		public override void vmethod_31()
		{
			this.method_31();
		}

		// Token: 0x06000AA8 RID: 2728 RVA: 0x0002C62C File Offset: 0x0002A82C
		public override void vmethod_26()
		{
			this.method_32();
		}

		// Token: 0x06000AA9 RID: 2729 RVA: 0x0002C640 File Offset: 0x0002A840
		public override void vmethod_8(int int_3)
		{
			this.method_33(int_3);
		}

		// Token: 0x06000AAA RID: 2730 RVA: 0x0002C654 File Offset: 0x0002A854
		public override void vmethod_25()
		{
			this.method_36();
		}

		// Token: 0x06000AAB RID: 2731 RVA: 0x0002C668 File Offset: 0x0002A868
		internal void method_15()
		{
			this.method_24();
		}

		// Token: 0x06000AAC RID: 2732 RVA: 0x0002C67C File Offset: 0x0002A87C
		internal void method_16()
		{
			this.method_45();
		}

		// Token: 0x06000AAD RID: 2733 RVA: 0x0002C690 File Offset: 0x0002A890
		internal void method_17()
		{
			this.method_14();
		}

		// Token: 0x06000AAE RID: 2734 RVA: 0x0002C6A4 File Offset: 0x0002A8A4
		internal void method_18(int int_3, GClass169 gclass169_0)
		{
			this.method_35(int_3, gclass169_0);
		}

		// Token: 0x06000AAF RID: 2735 RVA: 0x0002C6BC File Offset: 0x0002A8BC
		internal void method_19()
		{
			this.method_13();
		}

		// Token: 0x06000AB0 RID: 2736 RVA: 0x00021CC8 File Offset: 0x0001FEC8
		internal void method_20()
		{
			base.vmethod_15();
		}

		// Token: 0x06000AB1 RID: 2737 RVA: 0x00021BA8 File Offset: 0x0001FDA8
		internal void method_21()
		{
			base.vmethod_28();
		}

		// Token: 0x06000AB2 RID: 2738 RVA: 0x0002C6D0 File Offset: 0x0002A8D0
		public override void vmethod_19()
		{
			this.method_19();
		}

		// Token: 0x06000AB4 RID: 2740 RVA: 0x0002C720 File Offset: 0x0002A920
		internal void method_22()
		{
			this.method_34();
		}

		// Token: 0x06000AB5 RID: 2741 RVA: 0x0002C734 File Offset: 0x0002A934
		public override void vmethod_10()
		{
			this.method_27();
		}

		// Token: 0x06000AB6 RID: 2742 RVA: 0x0002C748 File Offset: 0x0002A948
		internal void method_23()
		{
			this.int_2 = 0;
			if (this.gclass170_0 != null)
			{
				this.gclass170_0.vmethod_33(this);
			}
		}

		// Token: 0x06000AB7 RID: 2743 RVA: 0x0002C774 File Offset: 0x0002A974
		public override void vmethod_12()
		{
			this.method_17();
		}

		// Token: 0x06000AB8 RID: 2744 RVA: 0x00021B94 File Offset: 0x0001FD94
		internal void method_24()
		{
			base.vmethod_22();
		}

		// Token: 0x06000AB9 RID: 2745 RVA: 0x0002C788 File Offset: 0x0002A988
		internal void method_25()
		{
			this.method_12();
		}

		// Token: 0x06000ABA RID: 2746 RVA: 0x0002C79C File Offset: 0x0002A99C
		internal void method_26()
		{
			this.method_21();
		}

		// Token: 0x06000ABB RID: 2747 RVA: 0x0002C7B0 File Offset: 0x0002A9B0
		internal void method_27()
		{
			this.method_30();
		}

		// Token: 0x06000ABC RID: 2748 RVA: 0x00021E68 File Offset: 0x00020068
		internal void method_28()
		{
			base.vmethod_11();
		}

		// Token: 0x06000ABD RID: 2749 RVA: 0x00021B80 File Offset: 0x0001FD80
		internal void method_29(int int_3)
		{
			base.vmethod_8(int_3);
		}

		// Token: 0x06000ABE RID: 2750 RVA: 0x00021AB8 File Offset: 0x0001FCB8
		internal void method_30()
		{
			base.vmethod_10();
		}

		// Token: 0x06000ABF RID: 2751 RVA: 0x0002C7C4 File Offset: 0x0002A9C4
		internal void method_31()
		{
			this.method_42();
		}

		// Token: 0x06000AC0 RID: 2752 RVA: 0x0002C7D8 File Offset: 0x0002A9D8
		internal void method_32()
		{
			this.method_44();
		}

		// Token: 0x06000AC1 RID: 2753 RVA: 0x0002C7EC File Offset: 0x0002A9EC
		internal void method_33(int int_3)
		{
			this.method_29(int_3);
		}

		// Token: 0x06000AC2 RID: 2754 RVA: 0x0002C800 File Offset: 0x0002AA00
		public override void vmethod_29()
		{
			this.method_8();
		}

		// Token: 0x06000AC3 RID: 2755 RVA: 0x00021DA0 File Offset: 0x0001FFA0
		internal void method_34()
		{
			base.vmethod_24();
		}

		// Token: 0x06000AC4 RID: 2756 RVA: 0x0002C814 File Offset: 0x0002AA14
		public override void vmethod_15()
		{
			this.method_41();
		}

		// Token: 0x06000AC5 RID: 2757 RVA: 0x0002C828 File Offset: 0x0002AA28
		internal void method_35(int int_3, GClass169 gclass169_0)
		{
			if (this.int_2 > 0)
			{
				int_3 = this.vmethod_36(int_3);
				this.int_2 -= int_3;
				if (this.int_2 <= 0)
				{
					this.vmethod_35();
				}
			}
		}

		// Token: 0x06000AC6 RID: 2758 RVA: 0x0002C870 File Offset: 0x0002AA70
		internal void method_36()
		{
			this.method_37();
		}

		// Token: 0x06000AC7 RID: 2759 RVA: 0x00021E7C File Offset: 0x0002007C
		internal void method_37()
		{
			base.vmethod_25();
		}

		// Token: 0x06000AC8 RID: 2760 RVA: 0x0002C884 File Offset: 0x0002AA84
		internal void method_38(int int_3)
		{
			this.method_11(int_3);
		}

		// Token: 0x06000AC9 RID: 2761 RVA: 0x0002C898 File Offset: 0x0002AA98
		public override void vmethod_24()
		{
			this.method_22();
		}

		// Token: 0x06000ACA RID: 2762 RVA: 0x0002C8AC File Offset: 0x0002AAAC
		public override void vmethod_27(int int_3)
		{
			this.method_38(int_3);
		}

		// Token: 0x06000ACB RID: 2763 RVA: 0x0002C8C0 File Offset: 0x0002AAC0
		public override void vmethod_23()
		{
			this.method_16();
		}

		// Token: 0x06000ACC RID: 2764 RVA: 0x0002C8D4 File Offset: 0x0002AAD4
		public override void vmethod_11()
		{
			this.method_9();
		}

		// Token: 0x06000ACD RID: 2765 RVA: 0x0002C8E8 File Offset: 0x0002AAE8
		public virtual void vmethod_34()
		{
			this.method_10();
		}

		// Token: 0x06000ACE RID: 2766 RVA: 0x0002C8FC File Offset: 0x0002AAFC
		public virtual void vmethod_35()
		{
			this.method_43();
		}

		// Token: 0x06000ACF RID: 2767 RVA: 0x0002C910 File Offset: 0x0002AB10
		internal void method_39()
		{
			if (this.gameObject_0)
			{
				this.vector3_1 = this.gameObject_0.transform.position;
			}
			else
			{
				this.vector3_1.x = 0f;
				this.vector3_1.y = 0f;
				this.vector3_1.z = 0f;
			}
		}

		// Token: 0x06000AD0 RID: 2768 RVA: 0x0002C974 File Offset: 0x0002AB74
		internal void method_40()
		{
			base.vmethod_29();
			this.int_2 = 100;
			this.int_0 = 100;
			this.int_1 = 199;
		}

		// Token: 0x06000AD1 RID: 2769 RVA: 0x0002C9A4 File Offset: 0x0002ABA4
		internal void method_41()
		{
			this.method_20();
		}

		// Token: 0x06000AD2 RID: 2770 RVA: 0x00021C84 File Offset: 0x0001FE84
		internal void method_42()
		{
			base.vmethod_31();
		}

		// Token: 0x06000AD3 RID: 2771 RVA: 0x0002C9B8 File Offset: 0x0002ABB8
		internal void method_43()
		{
			this.method_23();
		}

		// Token: 0x06000AD4 RID: 2772 RVA: 0x00021DF0 File Offset: 0x0001FFF0
		internal void method_44()
		{
			base.vmethod_26();
		}

		// Token: 0x06000AD5 RID: 2773 RVA: 0x0002C9CC File Offset: 0x0002ABCC
		public virtual int vmethod_36(int int_3)
		{
			int result;
			if (this.float_1 == 0f)
			{
				result = int_3;
			}
			else if ((float)int_3 > this.float_1)
			{
				float num = (float)int_3 - this.float_1;
				this.float_1 = 0f;
				result = (int)(num + ((float)int_3 - num) * 0.25f);
			}
			else
			{
				this.float_1 -= (float)int_3;
				result = (int)((float)int_3 * 0.25f);
			}
			return result;
		}

		// Token: 0x06000AD6 RID: 2774 RVA: 0x0002CA38 File Offset: 0x0002AC38
		internal void method_45()
		{
			base.vmethod_23();
		}

		// Token: 0x0400077E RID: 1918
		internal GClass170 gclass170_0 = null;

		// Token: 0x0400077F RID: 1919
		internal int int_0 = 0;

		// Token: 0x04000780 RID: 1920
		internal int int_1 = 0;

		// Token: 0x04000781 RID: 1921
		internal int int_2 = 0;

		// Token: 0x04000782 RID: 1922
		internal float float_1 = 0f;
	}
}
