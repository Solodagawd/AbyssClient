﻿using System;
using System.Runtime.InteropServices;
using ns417;

namespace ns388
{
	// Token: 0x020002EF RID: 751
	[Attribute2(4011)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct242
	{
		// Token: 0x040018A9 RID: 6313
		public const int int_0 = 4011;

		// Token: 0x040018AA RID: 6314
		public float float_0;
	}
}
