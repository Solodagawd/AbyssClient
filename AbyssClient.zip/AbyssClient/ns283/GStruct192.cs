﻿using System;
using System.Runtime.InteropServices;
using ns169;
using ns291;
using ns417;

namespace ns283
{
	// Token: 0x02000243 RID: 579
	[Attribute2(1313)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct192
	{
		// Token: 0x04000F6D RID: 3949
		public const int int_0 = 1313;

		// Token: 0x04000F6E RID: 3950
		public GEnum54 genum54_0;

		// Token: 0x04000F6F RID: 3951
		public GStruct78 gstruct78_0;
	}
}
