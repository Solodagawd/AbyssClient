﻿using System;
using System.Runtime.InteropServices;
using ns417;
using ns54;

namespace ns124
{
	// Token: 0x020000C1 RID: 193
	[Attribute2(334)]
	[StructLayout(LayoutKind.Sequential, Pack = 4)]
	public struct GStruct46
	{
		// Token: 0x040004D1 RID: 1233
		public const int int_0 = 334;

		// Token: 0x040004D2 RID: 1234
		public GStruct22 gstruct22_0;

		// Token: 0x040004D3 RID: 1235
		public int int_1;

		// Token: 0x040004D4 RID: 1236
		public int int_2;

		// Token: 0x040004D5 RID: 1237
		public int int_3;
	}
}
