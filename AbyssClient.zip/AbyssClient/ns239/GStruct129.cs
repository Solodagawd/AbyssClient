﻿using System;
using System.Runtime.InteropServices;

namespace ns239
{
	// Token: 0x020001BE RID: 446
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct129
	{
		// Token: 0x04000C4E RID: 3150
		public int int_0;

		// Token: 0x04000C4F RID: 3151
		public int int_1;

		// Token: 0x04000C50 RID: 3152
		public IntPtr intptr_0;

		// Token: 0x04000C51 RID: 3153
		public int int_2;
	}
}
