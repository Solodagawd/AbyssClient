﻿using System;

namespace ns207
{
	// Token: 0x0200014D RID: 333
	public enum GEnum37
	{
		// Token: 0x040008FE RID: 2302
		const_0,
		// Token: 0x040008FF RID: 2303
		const_1,
		// Token: 0x04000900 RID: 2304
		const_2,
		// Token: 0x04000901 RID: 2305
		const_3,
		// Token: 0x04000902 RID: 2306
		const_4,
		// Token: 0x04000903 RID: 2307
		const_5
	}
}
