﻿using System;
using System.Runtime.InteropServices;
using ns151;
using ns169;
using ns291;
using ns417;

namespace ns171
{
	// Token: 0x02000116 RID: 278
	[Attribute2(3414)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct79
	{
		// Token: 0x040006AF RID: 1711
		public const int int_0 = 3414;

		// Token: 0x040006B0 RID: 1712
		public GEnum54 genum54_0;

		// Token: 0x040006B1 RID: 1713
		public GStruct78 gstruct78_0;

		// Token: 0x040006B2 RID: 1714
		public GStruct66 gstruct66_0;
	}
}
