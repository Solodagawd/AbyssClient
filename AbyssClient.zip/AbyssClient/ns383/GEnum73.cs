﻿using System;

namespace ns383
{
	// Token: 0x020002E9 RID: 745
	public enum GEnum73
	{
		// Token: 0x04001870 RID: 6256
		const_0,
		// Token: 0x04001871 RID: 6257
		const_1,
		// Token: 0x04001872 RID: 6258
		const_2,
		// Token: 0x04001873 RID: 6259
		const_3
	}
}
