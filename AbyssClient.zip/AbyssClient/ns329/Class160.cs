﻿using System;

namespace ns329
{
	// Token: 0x02000289 RID: 649
	internal static class Class160
	{
	}
}
