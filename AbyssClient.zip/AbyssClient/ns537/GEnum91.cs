﻿using System;

namespace ns537
{
	// Token: 0x02000398 RID: 920
	public enum GEnum91
	{
		// Token: 0x04001D16 RID: 7446
		const_0,
		// Token: 0x04001D17 RID: 7447
		const_1,
		// Token: 0x04001D18 RID: 7448
		const_2,
		// Token: 0x04001D19 RID: 7449
		const_3
	}
}
