﻿using System;

namespace ns419
{
	// Token: 0x0200032A RID: 810
	public enum GEnum81
	{
		// Token: 0x040019A2 RID: 6562
		const_0 = -1,
		// Token: 0x040019A3 RID: 6563
		const_1,
		// Token: 0x040019A4 RID: 6564
		const_2,
		// Token: 0x040019A5 RID: 6565
		const_3,
		// Token: 0x040019A6 RID: 6566
		const_4
	}
}
