﻿using System;

namespace ns546
{
	// Token: 0x020003A3 RID: 931
	[Flags]
	public enum GEnum92
	{
		// Token: 0x04001D63 RID: 7523
		flag_0 = 0,
		// Token: 0x04001D64 RID: 7524
		flag_1 = 1,
		// Token: 0x04001D65 RID: 7525
		flag_2 = 2,
		// Token: 0x04001D66 RID: 7526
		flag_3 = 4,
		// Token: 0x04001D67 RID: 7527
		flag_4 = 8,
		// Token: 0x04001D68 RID: 7528
		flag_5 = 16,
		// Token: 0x04001D69 RID: 7529
		flag_6 = 32
	}
}
