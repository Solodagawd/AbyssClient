﻿using System;
using System.Runtime.InteropServices;
using ns151;
using ns169;
using ns291;
using ns417;

namespace ns102
{
	// Token: 0x02000089 RID: 137
	[Attribute2(3415)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct35
	{
		// Token: 0x040002E9 RID: 745
		public const int int_0 = 3415;

		// Token: 0x040002EA RID: 746
		public GEnum54 genum54_0;

		// Token: 0x040002EB RID: 747
		public GStruct78 gstruct78_0;

		// Token: 0x040002EC RID: 748
		public GStruct66 gstruct66_0;
	}
}
