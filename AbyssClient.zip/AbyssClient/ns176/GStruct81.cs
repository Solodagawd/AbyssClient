﻿using System;
using System.Runtime.InteropServices;
using ns417;
using ns54;

namespace ns176
{
	// Token: 0x0200011E RID: 286
	[Attribute2(338)]
	[StructLayout(LayoutKind.Sequential, Pack = 4)]
	public struct GStruct81
	{
		// Token: 0x04000724 RID: 1828
		public const int int_0 = 338;

		// Token: 0x04000725 RID: 1829
		public GStruct22 gstruct22_0;

		// Token: 0x04000726 RID: 1830
		public GStruct22 gstruct22_1;

		// Token: 0x04000727 RID: 1831
		public int int_1;
	}
}
