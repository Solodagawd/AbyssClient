﻿using System;

namespace ns385
{
	// Token: 0x020002EB RID: 747
	internal class Class182
	{
		// Token: 0x04001876 RID: 6262
		internal bool bool_0;

		// Token: 0x04001877 RID: 6263
		internal int int_0;

		// Token: 0x04001878 RID: 6264
		internal string string_0;

		// Token: 0x04001879 RID: 6265
		internal string string_1;

		// Token: 0x0400187A RID: 6266
		internal int int_1;

		// Token: 0x0400187B RID: 6267
		internal bool bool_1;
	}
}
