﻿using System;

namespace ns308
{
	// Token: 0x02000272 RID: 626
	[Flags]
	public enum GEnum57
	{
		// Token: 0x04001106 RID: 4358
		flag_0 = 1,
		// Token: 0x04001107 RID: 4359
		flag_1 = 2,
		// Token: 0x04001108 RID: 4360
		flag_2 = 4,
		// Token: 0x04001109 RID: 4361
		flag_3 = 8,
		// Token: 0x0400110A RID: 4362
		flag_4 = 16
	}
}
