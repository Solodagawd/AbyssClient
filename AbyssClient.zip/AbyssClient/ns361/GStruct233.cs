﻿using System;
using System.Runtime.InteropServices;
using ns286;
using ns417;
using ns554;

namespace ns361
{
	// Token: 0x020002C3 RID: 707
	[Attribute2(1105)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct233
	{
		// Token: 0x040012AD RID: 4781
		public const int int_0 = 1105;

		// Token: 0x040012AE RID: 4782
		public GStruct305 gstruct305_0;

		// Token: 0x040012AF RID: 4783
		public GStruct193 gstruct193_0;

		// Token: 0x040012B0 RID: 4784
		public int int_1;
	}
}
