﻿using System;

namespace ns382
{
	// Token: 0x020002E8 RID: 744
	internal class Class181
	{
		// Token: 0x04001866 RID: 6246
		internal string string_0;

		// Token: 0x04001867 RID: 6247
		internal string string_1;

		// Token: 0x04001868 RID: 6248
		internal byte byte_0;

		// Token: 0x04001869 RID: 6249
		internal string string_2;

		// Token: 0x0400186A RID: 6250
		internal bool bool_0;

		// Token: 0x0400186B RID: 6251
		internal string string_3;

		// Token: 0x0400186C RID: 6252
		internal string string_4;

		// Token: 0x0400186D RID: 6253
		internal string string_5;

		// Token: 0x0400186E RID: 6254
		internal byte byte_1;
	}
}
