﻿using System;

namespace ns523
{
	// Token: 0x0200038A RID: 906
	public static class GClass193
	{
		// Token: 0x04001CC6 RID: 7366
		internal static char[] char_0 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();

		// Token: 0x04001CC7 RID: 7367
		internal static char[] char_1 = "abcdefghijklmnopqrstuvwxyz".ToCharArray();

		// Token: 0x04001CC8 RID: 7368
		internal static char[] char_2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();

		// Token: 0x04001CC9 RID: 7369
		internal static char[] char_3 = "1234567890".ToCharArray();

		// Token: 0x04001CCA RID: 7370
		internal static char[] char_4 = "0123456789".ToCharArray();

		// Token: 0x04001CCB RID: 7371
		internal static char[] char_5 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890".ToCharArray();

		// Token: 0x04001CCC RID: 7372
		internal static char[] char_6 = "abcdefghijklmnopqrstuvwxyz1234567890".ToCharArray();

		// Token: 0x04001CCD RID: 7373
		internal static char[] char_7 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890".ToCharArray();

		// Token: 0x04001CCE RID: 7374
		internal static char[] char_8 = "`?\\=)(/{][}&%$§!".ToCharArray();

		// Token: 0x04001CCF RID: 7375
		internal static char[] char_9 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890`?\\=)(/{][}&%$§!".ToCharArray();

		// Token: 0x04001CD0 RID: 7376
		internal static char[] char_10 = "1234567890abcdef".ToCharArray();

		// Token: 0x04001CD1 RID: 7377
		internal static string string_0 = "Cube".ToLower();

		// Token: 0x04001CD2 RID: 7378
		internal static string string_1 = "Capsule".ToLower();

		// Token: 0x04001CD3 RID: 7379
		internal static string string_2 = "Cylinder".ToLower();

		// Token: 0x04001CD4 RID: 7380
		internal static string string_3 = "Plane".ToLower();

		// Token: 0x04001CD5 RID: 7381
		internal static string string_4 = "Sphere".ToLower();

		// Token: 0x04001CD6 RID: 7382
		internal static string string_5 = "Quad".ToLower();
	}
}
