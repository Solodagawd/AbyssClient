﻿using System;

namespace ns403
{
	// Token: 0x0200030A RID: 778
	public enum GEnum77
	{
		// Token: 0x040018FF RID: 6399
		const_0,
		// Token: 0x04001900 RID: 6400
		const_1,
		// Token: 0x04001901 RID: 6401
		const_2,
		// Token: 0x04001902 RID: 6402
		const_3,
		// Token: 0x04001903 RID: 6403
		const_4,
		// Token: 0x04001904 RID: 6404
		const_5
	}
}
