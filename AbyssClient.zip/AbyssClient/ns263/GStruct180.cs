﻿using System;
using System.Runtime.InteropServices;
using ns417;

namespace ns263
{
	// Token: 0x02000226 RID: 550
	[Attribute2(506)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct180
	{
		// Token: 0x04000EBA RID: 3770
		public const int int_0 = 506;

		// Token: 0x04000EBB RID: 3771
		public ulong ulong_0;

		// Token: 0x04000EBC RID: 3772
		public ulong ulong_1;

		// Token: 0x04000EBD RID: 3773
		public ulong ulong_2;

		// Token: 0x04000EBE RID: 3774
		public uint uint_0;
	}
}
