﻿using System;
using System.Runtime.InteropServices;
using ns291;
using ns417;

namespace ns298
{
	// Token: 0x02000266 RID: 614
	[Attribute2(4704)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct199
	{
		// Token: 0x040010BD RID: 4285
		public const int int_0 = 4704;

		// Token: 0x040010BE RID: 4286
		public GEnum54 genum54_0;

		// Token: 0x040010BF RID: 4287
		public ulong ulong_0;

		// Token: 0x040010C0 RID: 4288
		public ulong ulong_1;
	}
}
