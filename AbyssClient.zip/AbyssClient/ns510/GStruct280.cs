﻿using System;
using System.Runtime.InteropServices;
using ns291;
using ns417;

namespace ns510
{
	// Token: 0x02000375 RID: 885
	[Attribute2(210)]
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct280
	{
		// Token: 0x04001C30 RID: 7216
		public const int int_0 = 210;

		// Token: 0x04001C31 RID: 7217
		public GEnum54 genum54_0;
	}
}
