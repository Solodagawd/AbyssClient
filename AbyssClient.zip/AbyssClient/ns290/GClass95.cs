﻿using System;
using System.Runtime.CompilerServices;
using ns12;
using ns174;
using ns205;
using ns237;
using ns241;
using ns49;
using ns559;
using UnityEngine;
using UnityEngine.UI;

namespace ns290
{
	// Token: 0x02000252 RID: 594
	public class GClass95
	{
		// Token: 0x06001B68 RID: 7016 RVA: 0x0008AE94 File Offset: 0x00089094
		internal void method_0(float float_0, float float_1, float float_2, float float_3, string string_3, string string_4, Color? nullable_0 = null, Color? nullable_1 = null, Color? nullable_2 = null, Color? nullable_3 = null, Texture texture_0 = null, bool bool_0 = false)
		{
			this.method_11(float_0, float_1, float_2, float_3, string_3, string_4, nullable_0, nullable_1, nullable_2, nullable_3, texture_0, bool_0);
		}

		// Token: 0x06001B69 RID: 7017 RVA: 0x0008AED0 File Offset: 0x000890D0
		public GClass95(GClass66 gclass66_0, float float_0, float float_1, float float_2, float float_3, string string_3, string string_4, Color? nullable_0 = null, Color? nullable_1 = null, Color? nullable_2 = null, Color? nullable_3 = null, Texture texture_0 = null, bool bool_0 = false)
		{
			this.string_1 = gclass66_0.method_8();
			this.method_0(float_0, float_1, float_2, float_3, string_3, string_4, nullable_0, nullable_1, nullable_2, nullable_3, texture_0, bool_0);
		}

		// Token: 0x06001B6A RID: 7018 RVA: 0x0008AF0C File Offset: 0x0008910C
		internal void method_1()
		{
			this.method_14();
		}

		// Token: 0x06001B6B RID: 7019 RVA: 0x0008AF20 File Offset: 0x00089120
		[CompilerGenerated]
		private void method_2()
		{
			this.method_12();
		}

		// Token: 0x06001B6C RID: 7020 RVA: 0x0008AF34 File Offset: 0x00089134
		internal string method_3()
		{
			return this.method_6();
		}

		// Token: 0x06001B6D RID: 7021 RVA: 0x0008AF48 File Offset: 0x00089148
		internal void method_4()
		{
			this.gclass6_0.method_9();
		}

		// Token: 0x06001B6E RID: 7022 RVA: 0x0008AF60 File Offset: 0x00089160
		public GClass95(GClass24 gclass24_0, float float_0, float float_1, float float_2, float float_3, string string_3, string string_4, Color? nullable_0 = null, Color? nullable_1 = null, Color? nullable_2 = null, Color? nullable_3 = null, Texture texture_0 = null, bool bool_0 = false)
		{
			this.string_1 = gclass24_0.method_7();
			this.method_0(float_0, float_1, float_2, float_3, string_3, string_4, nullable_0, nullable_1, nullable_2, nullable_3, texture_0, bool_0);
		}

		// Token: 0x06001B6F RID: 7023 RVA: 0x0008AF9C File Offset: 0x0008919C
		internal string method_5()
		{
			return this.string_1;
		}

		// Token: 0x06001B70 RID: 7024 RVA: 0x0008AFB4 File Offset: 0x000891B4
		internal string method_6()
		{
			return this.string_0;
		}

		// Token: 0x06001B71 RID: 7025 RVA: 0x0008AFCC File Offset: 0x000891CC
		internal string method_7()
		{
			return this.method_10();
		}

		// Token: 0x06001B72 RID: 7026 RVA: 0x0008AFE0 File Offset: 0x000891E0
		private void method_8()
		{
			GClass73.smethod_1(this.string_0);
		}

		// Token: 0x06001B73 RID: 7027 RVA: 0x0008AFF8 File Offset: 0x000891F8
		internal string method_9()
		{
			return this.method_3();
		}

		// Token: 0x06001B74 RID: 7028 RVA: 0x0008B00C File Offset: 0x0008920C
		internal string method_10()
		{
			return this.method_5();
		}

		// Token: 0x06001B75 RID: 7029 RVA: 0x0008B020 File Offset: 0x00089220
		public GClass95(GClass24 gclass24_0, float float_0, float float_1, string string_3, string string_4, Color? nullable_0 = null, Color? nullable_1 = null, Color? nullable_2 = null, Color? nullable_3 = null, Texture texture_0 = null, bool bool_0 = false)
		{
			this.string_1 = gclass24_0.method_7();
			this.method_0(float_0, float_1, 1f, 1f, string_3, string_4, nullable_0, nullable_1, nullable_2, nullable_3, texture_0, bool_0);
		}

		// Token: 0x06001B76 RID: 7030 RVA: 0x0008B064 File Offset: 0x00089264
		public GClass95(GClass66 gclass66_0, float float_0, float float_1, string string_3, string string_4, Color? nullable_0 = null, Color? nullable_1 = null, Color? nullable_2 = null, Color? nullable_3 = null, Texture texture_0 = null, bool bool_0 = false)
		{
			this.string_1 = gclass66_0.method_8();
			this.method_0(float_0, float_1, 1f, 1f, string_3, string_4, nullable_0, nullable_1, nullable_2, nullable_3, texture_0, bool_0);
		}

		// Token: 0x06001B77 RID: 7031 RVA: 0x0008B0A8 File Offset: 0x000892A8
		public GClass95(GClass95 gclass95_0, float float_0, float float_1, float float_2, float float_3, string string_3, string string_4, Color? nullable_0 = null, Color? nullable_1 = null, Color? nullable_2 = null, Color? nullable_3 = null, Texture texture_0 = null, bool bool_0 = false)
		{
			this.string_1 = gclass95_0.method_9();
			this.method_0(float_0, float_1, float_2, float_3, string_3, string_4, nullable_0, nullable_1, nullable_2, nullable_3, texture_0, bool_0);
		}

		// Token: 0x06001B78 RID: 7032 RVA: 0x0008B0E4 File Offset: 0x000892E4
		public GClass95(string string_3, float float_0, float float_1, string string_4, string string_5, Color? nullable_0 = null, Color? nullable_1 = null, Color? nullable_2 = null, Color? nullable_3 = null, Texture texture_0 = null, bool bool_0 = false)
		{
			this.string_1 = string_3;
			this.method_0(float_0, float_1, 1f, 1f, string_4, string_5, nullable_0, nullable_1, nullable_2, nullable_3, texture_0, bool_0);
		}

		// Token: 0x06001B79 RID: 7033 RVA: 0x0008B120 File Offset: 0x00089320
		public GClass95(GClass95 gclass95_0, float float_0, float float_1, string string_3, string string_4, Color? nullable_0 = null, Color? nullable_1 = null, Color? nullable_2 = null, Color? nullable_3 = null, Texture texture_0 = null, bool bool_0 = false)
		{
			this.string_1 = gclass95_0.method_9();
			this.method_0(float_0, float_1, 1f, 1f, string_3, string_4, nullable_0, nullable_1, nullable_2, nullable_3, texture_0, bool_0);
		}

		// Token: 0x06001B7A RID: 7034 RVA: 0x0008B164 File Offset: 0x00089364
		internal void method_11(float float_0, float float_1, float float_2, float float_3, string string_3, string string_4, Color? nullable_0, Color? nullable_1, Color? nullable_2, Color? nullable_3, Texture texture_0, bool bool_0)
		{
			this.method_15(float_0, float_1, float_2, float_3, string_3, string_4, nullable_0, nullable_1, nullable_2, nullable_3, texture_0, bool_0);
		}

		// Token: 0x06001B7B RID: 7035 RVA: 0x0008B1A0 File Offset: 0x000893A0
		public GClass95(string string_3, float float_0, float float_1, float float_2, float float_3, string string_4, string string_5, Color? nullable_0 = null, Color? nullable_1 = null, Color? nullable_2 = null, Color? nullable_3 = null, Texture texture_0 = null, bool bool_0 = false)
		{
			this.string_1 = string_3;
			this.method_0(float_0, float_1, float_2, float_3, string_4, string_5, nullable_0, nullable_1, nullable_2, nullable_3, texture_0, bool_0);
		}

		// Token: 0x06001B7C RID: 7036 RVA: 0x0008B1D8 File Offset: 0x000893D8
		private void method_12()
		{
			this.method_8();
		}

		// Token: 0x06001B7D RID: 7037 RVA: 0x0008B1EC File Offset: 0x000893EC
		internal GClass6 method_13()
		{
			return this.gclass6_0;
		}

		// Token: 0x06001B7E RID: 7038 RVA: 0x0008B204 File Offset: 0x00089404
		internal void method_14()
		{
			this.method_4();
		}

		// Token: 0x06001B7F RID: 7039 RVA: 0x0008B218 File Offset: 0x00089418
		internal void method_15(float float_0, float float_1, float float_2, float float_3, string string_3, string string_4, Color? nullable_0, Color? nullable_1, Color? nullable_2, Color? nullable_3, Texture texture_0, bool bool_0)
		{
			this.string_2 = "NestedButton";
			this.string_0 = GClass73.smethod_17(this.string_1 + string_3, float_0, float_1);
			new GClass83(this.string_0, string_3, this.string_1, true, false, false, null, "", null, false, bool_0);
			this.gclass6_0 = new GClass6(this.string_1, float_0, float_1, float_2, float_3, string_3, null, string_4, nullable_0, nullable_1, texture_0);
			GClass84.smethod_243(this.gclass6_0.method_12().GetComponent<Button>(), new Action(this.method_2));
			if (nullable_3 == null)
			{
				nullable_3 = new Color?(Color.yellow);
			}
			GClass199.list_11.Add(this);
		}

		// Token: 0x04000FBB RID: 4027
		protected GClass6 gclass6_0;

		// Token: 0x04000FBC RID: 4028
		protected string string_0;

		// Token: 0x04000FBD RID: 4029
		protected string string_1;

		// Token: 0x04000FBE RID: 4030
		protected string string_2;
	}
}
