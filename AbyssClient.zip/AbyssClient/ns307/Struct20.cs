﻿using System;
using System.Runtime.InteropServices;

namespace ns307
{
	// Token: 0x02000271 RID: 625
	[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
	internal struct Struct20
	{
		// Token: 0x040010EE RID: 4334
		internal int int_0;

		// Token: 0x040010EF RID: 4335
		internal IntPtr intptr_0;

		// Token: 0x040010F0 RID: 4336
		internal IntPtr intptr_1;

		// Token: 0x040010F1 RID: 4337
		internal string string_0;

		// Token: 0x040010F2 RID: 4338
		internal string string_1;

		// Token: 0x040010F3 RID: 4339
		internal int int_1;

		// Token: 0x040010F4 RID: 4340
		internal int int_2;

		// Token: 0x040010F5 RID: 4341
		internal string string_2;

		// Token: 0x040010F6 RID: 4342
		internal int int_3;

		// Token: 0x040010F7 RID: 4343
		internal string string_3;

		// Token: 0x040010F8 RID: 4344
		internal int int_4;

		// Token: 0x040010F9 RID: 4345
		internal string string_4;

		// Token: 0x040010FA RID: 4346
		internal string string_5;

		// Token: 0x040010FB RID: 4347
		internal int int_5;

		// Token: 0x040010FC RID: 4348
		internal short short_0;

		// Token: 0x040010FD RID: 4349
		internal short short_1;

		// Token: 0x040010FE RID: 4350
		internal string string_6;

		// Token: 0x040010FF RID: 4351
		internal IntPtr intptr_2;

		// Token: 0x04001100 RID: 4352
		internal IntPtr intptr_3;

		// Token: 0x04001101 RID: 4353
		internal string string_7;

		// Token: 0x04001102 RID: 4354
		internal IntPtr intptr_4;

		// Token: 0x04001103 RID: 4355
		internal int int_6;

		// Token: 0x04001104 RID: 4356
		internal int int_7;
	}
}
