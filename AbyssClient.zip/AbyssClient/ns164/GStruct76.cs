﻿using System;
using ns417;

namespace ns164
{
	// Token: 0x0200010E RID: 270
	[Attribute2(1014)]
	public struct GStruct76
	{
		// Token: 0x04000699 RID: 1689
		public const int int_0 = 1014;
	}
}
