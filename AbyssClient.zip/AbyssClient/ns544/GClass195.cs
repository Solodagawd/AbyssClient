﻿using System;

namespace ns544
{
	// Token: 0x020003A0 RID: 928
	public class GClass195
	{
	}
}
