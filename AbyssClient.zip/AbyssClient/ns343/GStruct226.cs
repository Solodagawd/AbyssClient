﻿using System;
using System.Runtime.InteropServices;
using ns103;
using ns22;

namespace ns343
{
	// Token: 0x020002AE RID: 686
	[StructLayout(LayoutKind.Sequential, Pack = 8)]
	public struct GStruct226
	{
		// Token: 0x0400126A RID: 4714
		public GStruct7 gstruct7_0;

		// Token: 0x0400126B RID: 4715
		public GStruct36 gstruct36_0;

		// Token: 0x0400126C RID: 4716
		public ushort ushort_0;

		// Token: 0x0400126D RID: 4717
		public ushort ushort_1;
	}
}
